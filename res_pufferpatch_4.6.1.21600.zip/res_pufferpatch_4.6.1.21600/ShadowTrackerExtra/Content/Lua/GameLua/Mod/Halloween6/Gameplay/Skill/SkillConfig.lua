-- 设置已启用自动解析化
-- TELEGRAM:@RJTOOL @BYRJ6
-- 解包层数: 0；移除诱饵行: 0；还原字符串: 0

local SkillCDDefine = require("GameLua.Mod.Library.GamePlay.Skill.SkillCD.SkillCDDefine")
local ESkillIconStatus = import("ESkillIconStatus")
local Config = {
  SyncDisableSkillIDs = {4605002, 4605006},
  [4602007] = {
    SkillCDParams = {
      [1] = {
        SkillCDClass = "GameLua.Mod.Library.GamePlay.Skill.SkillCD.SkillCD_Time",
        Params = {nCD = 0.5}
      }
    },
    SkillWidgetParams = {
      UseCountIndex = 1,
      bShowUseCountCD = true,
      AutoFireTime = 0.6,
      FireCD = 0.6,
      SkillNameTextID = 0,
      WidgetPath = "/Game/Mod/Halloween6/BluePrints/UI/SkillButton/ShurikenButton_UIBP.ShurikenButton_UIBP",
      WidgetClass = "GameLua.Mod.Halloween6.Client.UI.SkillButton.ShurikenSkillButton",
      MountData = {
        MountName = "CanvasPanel_SkillSlot2"
      },
      SkillIcon = {
        [ESkillIconStatus.IconBtnNormal] = "/Game/Library/Res/Vehicles/Scorpion/Art/UI/Atlas/Frames/ZD_icon_Scorpion_png.ZD_icon_Scorpion_png",
        [ESkillIconStatus.IconBtnInCD] = "/Game/Library/Res/Vehicles/Scorpion/Art/UI/Atlas/Frames/ZD_icon_Scorpion_png.ZD_icon_Scorpion_png",
        [ESkillIconStatus.IconBtnActive] = "/Game/Library/Res/Vehicles/Scorpion/Art/UI/Atlas/Frames/ZD_icon_Scorpion_png.ZD_icon_Scorpion_png"
      }
    }
  },
  [4602008] = {
    SkillCDParams = {
      [1] = {
        SkillCDClass = "GameLua.Mod.Library.GamePlay.Skill.SkillCD.SkillCD_Time",
        Params = {nCD = 0.5}
      }
    },
    SkillWidgetParams = {
      ActiveCDIndex = 1,
      CanvasVisibleConfigKey = "SkillBtnShowConfig",
      CDType = SkillCDDefine.ECDType.CDT_Timer,
      CDTypeStr = "%.f",
      WidgetPath = "/Game/Library/Res/SkillsCommon/UICommon/BluePrints/UI/SkillButton/CommonSkillButton_UIBP.CommonSkillButton_UIBP",
      WidgetClass = "GameLua.Mod.Halloween6.Client.UI.SkillButton.ShadowBatSkillButton",
      MountData = {
        MountName = "CanvasPanel_SkillSlot1"
      },
      SkillIcon = {
        [ESkillIconStatus.IconBtnNormal] = "/Game/Library/Res/Vehicles/Scorpion/Art/UI/Atlas/Frames/ZD_icon_Scorpion_png.ZD_icon_Scorpion_png",
        [ESkillIconStatus.IconBtnInCD] = "/Game/Library/Res/Vehicles/Scorpion/Art/UI/Atlas/Frames/ZD_icon_Scorpion_png.ZD_icon_Scorpion_png",
        [ESkillIconStatus.IconBtnActive] = "/Game/Library/Res/Vehicles/Scorpion/Art/UI/Atlas/Frames/ZD_icon_Scorpion_png.ZD_icon_Scorpion_png"
      }
    }
  },
  [4602027] = {
    SkillCDParams = {
      [1] = {
        SkillCDClass = "GameLua.Mod.Library.GamePlay.Skill.SkillCD.SkillCD_Time",
        Params = {nCD = 0}
      }
    },
    SkillWidgetParams = {
      ActiveCDIndex = 1,
      CDType = SkillCDDefine.ECDType.CDT_Timer,
      CDTypeStr = "%.f",
      WidgetPath = "/Game/Library/Res/SkillsCommon/UICommon/BluePrints/UI/SkillButton/CommonSkillButton_UIBP.CommonSkillButton_UIBP",
      WidgetClass = "GameLua.GameCore.Module.Skill.SkillUI.SkillUIWidgetTemplate",
      MountData = {
        MountName = "CanvasPanel_SkillSlot3"
      },
      SkillIcon = {
        [ESkillIconStatus.IconBtnNormal] = "/Game/Library/Res/Vehicles/Scorpion/Art/UI/Atlas/Frames/ZD_icon_Scorpion_png.ZD_icon_Scorpion_png",
        [ESkillIconStatus.IconBtnInCD] = "/Game/Library/Res/Vehicles/Scorpion/Art/UI/Atlas/Frames/ZD_icon_Scorpion_png.ZD_icon_Scorpion_png",
        [ESkillIconStatus.IconBtnActive] = "/Game/Library/Res/Vehicles/Scorpion/Art/UI/Atlas/Frames/ZD_icon_Scorpion_png.ZD_icon_Scorpion_png"
      }
    }
  },
  [4602029] = {
    SkillCDParams = {
      [1] = {
        SkillCDClass = "GameLua.Mod.Library.GamePlay.Skill.SkillCD.SkillCD_Time",
        Params = {nCD = 8}
      }
    },
    SkillWidgetParams = {
      ActiveCDIndex = 1,
      CDType = SkillCDDefine.ECDType.CDT_Timer,
      CDTypeStr = "%.f",
      WidgetPath = "/Game/Library/Res/SkillsCommon/UICommon/BluePrints/UI/SkillButton/CommonSkillButton_UIBP.CommonSkillButton_UIBP",
      WidgetClass = "GameLua.GameCore.Module.Skill.SkillUI.SkillUIWidgetTemplate",
      MountData = {
        MountName = "CanvasPanel_SkillSlot3"
      },
      SkillIcon = {
        [ESkillIconStatus.IconBtnNormal] = "/Game/Library/Res/Vehicles/Scorpion/Art/UI/Atlas/Frames/ZD_icon_Scorpion_png.ZD_icon_Scorpion_png",
        [ESkillIconStatus.IconBtnInCD] = "/Game/Library/Res/Vehicles/Scorpion/Art/UI/Atlas/Frames/ZD_icon_Scorpion_png.ZD_icon_Scorpion_png",
        [ESkillIconStatus.IconBtnActive] = "/Game/Library/Res/Vehicles/Scorpion/Art/UI/Atlas/Frames/ZD_icon_Scorpion_png.ZD_icon_Scorpion_png"
      }
    }
  },
  [4602030] = {
    SkillCDParams = {
      [1] = {
        SkillCDClass = "GameLua.Mod.Library.GamePlay.Skill.SkillCD.SkillCD_Time",
        Params = {nCD = 0}
      }
    },
    SkillWidgetParams = {
      ActiveCDIndex = 1,
      CDType = SkillCDDefine.ECDType.CDT_Timer,
      CDTypeStr = "%.f",
      WidgetPath = "/Game/Library/Res/SkillsCommon/UICommon/BluePrints/UI/SkillButton/CommonSkillButton_UIBP.CommonSkillButton_UIBP",
      WidgetClass = "GameLua.GameCore.Module.Skill.SkillUI.SkillUIWidgetTemplate",
      MountData = {
        ModMountPanel = "NightWatchBatSwarmControlUI",
        MountName = "CanvasPanel_SkillSlot3"
      },
      SkillIcon = {
        [ESkillIconStatus.IconBtnNormal] = "/Game/Library/Res/Vehicles/Scorpion/Art/UI/Atlas/Frames/ZD_icon_Scorpion_png.ZD_icon_Scorpion_png",
        [ESkillIconStatus.IconBtnInCD] = "/Game/Library/Res/Vehicles/Scorpion/Art/UI/Atlas/Frames/ZD_icon_Scorpion_png.ZD_icon_Scorpion_png",
        [ESkillIconStatus.IconBtnActive] = "/Game/Library/Res/Vehicles/Scorpion/Art/UI/Atlas/Frames/ZD_icon_Scorpion_png.ZD_icon_Scorpion_png"
      }
    }
  },
  [4603101] = {
    SkillCDParams = {
      [1] = {
        SkillCDClass = "GameLua.Mod.Library.GamePlay.Skill.SkillCD.SkillCD_Time",
        Params = {nCD = 0.5}
      }
    },
    SkillWidgetParams = {
      ActiveCDIndex = 1,
      CDType = SkillCDDefine.ECDType.CDT_Timer,
      CDTypeStr = "%.f",
      WidgetPath = "/Game/Library/Res/SkillsCommon/UICommon/BluePrints/UI/SkillButton/CommonSkillButton_UIBP.CommonSkillButton_UIBP",
      WidgetClass = "GameLua.GameCore.Module.Skill.SkillUI.SkillUIWidgetTemplate",
      MountData = {
        ModMountPanel = "NightWatchBatSwarmControlUI",
        MountName = "CanvasPanel_SkillSlot3"
      },
      SkillIcon = {
        [ESkillIconStatus.IconBtnNormal] = "/Game/Library/Res/Vehicles/Scorpion/Art/UI/Atlas/Frames/ZD_icon_Scorpion_png.ZD_icon_Scorpion_png",
        [ESkillIconStatus.IconBtnInCD] = "/Game/Library/Res/Vehicles/Scorpion/Art/UI/Atlas/Frames/ZD_icon_Scorpion_png.ZD_icon_Scorpion_png",
        [ESkillIconStatus.IconBtnActive] = "/Game/Library/Res/Vehicles/Scorpion/Art/UI/Atlas/Frames/ZD_icon_Scorpion_png.ZD_icon_Scorpion_png"
      }
    }
  },
  [4605002] = {
    SkillCDParams = {
      [1] = {
        SkillCDClass = "GameLua.Mod.Library.GamePlay.Skill.SkillCD.SkillCD_Time",
        Params = {nCD = 10}
      }
    },
    KillInfoIcon = "/Game/Mod/Halloween6/Arts/UI/Atlas/Halloween6/Frames/ZD_Icon_Perception.ZD_Icon_Perception",
    SkillWidgetParams = {
      CDIndex = 1,
      ActiveCDIndex = 0,
      CDType = SkillCDDefine.ECDType.CDT_Timer,
      CDTypeStr = "%.f",
      bRefreshCDProcessAnticlockwise = false,
      WidgetPath = "/Game/Library/Res/SkillsCommon/UICommon/BluePrints/UI/SkillButton/CommonSkillButton_UIBP.CommonSkillButton_UIBP",
      WidgetClass = "GameLua.GameCore.Module.Skill.SkillUI.SkillUIWidgetTemplate",
      MountData = {
        MarginData = {
          Left = 0.0,
          Top = 0.0,
          Right = 0.0,
          Bottom = 0.0
        },
        AnchorsData = {
          Minimum = {0.0, 0.0},
          Maximum = {1.0, 1.0}
        },
        Alignment = {0.0, 0.0},
        MountName = "CanvasPanel_SkillSlot1"
      },
      SkillIcon = {
        [ESkillIconStatus.IconBtnNormal] = "/Game/Mod/Halloween6/Arts/UI/Atlas/Halloween6/Frames/ZD_Icon_Perception.ZD_Icon_Perception",
        [ESkillIconStatus.IconBtnInCD] = "/Game/Mod/Halloween6/Arts/UI/Atlas/Halloween6/Frames/ZD_Icon_Perception.ZD_Icon_Perception",
        [ESkillIconStatus.IconBtnActive] = "/Game/Mod/Halloween6/Arts/UI/Atlas/Halloween6/Frames/ZD_Icon_Perception.ZD_Icon_Perception"
      }
    }
  },
  [4605006] = {
    SkillCDParams = {
      [1] = {
        SkillCDClass = "GameLua.Mod.Library.GamePlay.Skill.SkillCD.SkillCD_Time",
        Params = {nCD = 20}
      },
      [2] = {
        SkillCDClass = "GameLua.Mod.Library.GamePlay.Skill.SkillCD.SkillCD_Time",
        Params = {nCD = 12.2}
      }
    },
    SkillWidgetParams = {
      CDIndex = 1,
      ActiveCDIndex = 2,
      CDType = SkillCDDefine.ECDType.CDT_Timer,
      CDTypeStr = "%.f",
      bRefreshCDProcessAnticlockwise = false,
      WidgetPath = "/Game/Library/Res/SkillsCommon/UICommon/BluePrints/UI/SkillButton/CommonSkillButton_UIBP.CommonSkillButton_UIBP",
      WidgetClass = "GameLua.GameCore.Module.Skill.SkillUI.SkillUIWidgetTemplate",
      MountData = {
        MarginData = {
          Left = 0.0,
          Top = 0.0,
          Right = 0.0,
          Bottom = 0.0
        },
        AnchorsData = {
          Minimum = {0.0, 0.0},
          Maximum = {1.0, 1.0}
        },
        Alignment = {0.0, 0.0},
        MountName = "CanvasPanel_SkillSlot3"
      },
      SkillIcon = {
        [ESkillIconStatus.IconBtnNormal] = "/Game/Mod/Halloween6/Arts/UI/Atlas/Halloween6/Frames/ZD_Icon_BloodPool.ZD_Icon_BloodPool",
        [ESkillIconStatus.IconBtnInCD] = "/Game/Mod/Halloween6/Arts/UI/Atlas/Halloween6/Frames/ZD_Icon_BloodPool.ZD_Icon_BloodPool",
        [ESkillIconStatus.IconBtnActive] = "/Game/Mod/Halloween6/Arts/UI/Atlas/Halloween6/Frames/ZD_Icon_BloodPool.ZD_Icon_BloodPool"
      }
    }
  },
  [4605003] = {
    KillInfoIcon = "/Game/Arts/UI/NoAtlas/KillInfoTypeIcon/killfeed_cause_Contract.killfeed_cause_Contract"
  },
  [4605007] = {
    SkillCDParams = {
      [1] = {
        SkillCDClass = "GameLua.Mod.Library.GamePlay.Skill.SkillCD.SkillCD_Time",
        Params = {nCD = 1}
      }
    },
    SkillWidgetParams = {
      CDIndex = 1,
      ActiveCDIndex = 0,
      CDType = SkillCDDefine.ECDType.CDT_Timer,
      CDTypeStr = "%.f",
      bRefreshCDProcessAnticlockwise = false,
      WidgetPath = "/Game/Library/Res/SkillsCommon/UICommon/BluePrints/UI/SkillButton/CommonSkillButton_UIBP.CommonSkillButton_UIBP",
      WidgetClass = "GameLua.GameCore.Module.Skill.SkillUI.SkillUIWidgetTemplate",
      MountData = {
        MountName = "CanvasPanel_SkillSlot2"
      },
      SkillIcon = {
        [ESkillIconStatus.IconBtnNormal] = "/Game/Mod/Halloween6/Arts/UI/Atlas/Halloween6/Frames/ZD_Icon_ContractHealth_png.ZD_Icon_ContractHealth_png",
        [ESkillIconStatus.IconBtnInCD] = "/Game/Mod/Halloween6/Arts/UI/Atlas/Halloween6/Frames/ZD_Icon_ContractHealth_png.ZD_Icon_ContractHealth_png",
        [ESkillIconStatus.IconBtnActive] = "/Game/Mod/Halloween6/Arts/UI/Atlas/Halloween6/Frames/ZD_Icon_ContractHealth_png.ZD_Icon_ContractHealth_png"
      }
    }
  },
  [4605008] = {
    SkillCDParams = {
      [1] = {
        SkillCDClass = "GameLua.Mod.Library.GamePlay.Skill.SkillCD.SkillCD_Time",
        Params = {nCD = 8}
      }
    },
    SkillWidgetParams = {
      CDIndex = 1,
      ActiveCDIndex = 0,
      CDType = SkillCDDefine.ECDType.CDT_Timer,
      CDTypeStr = "%.f",
      bRefreshCDProcessAnticlockwise = false,
      WidgetPath = "/Game/Library/Res/SkillsCommon/UICommon/BluePrints/UI/SkillButton/CommonSkillButton_UIBP.CommonSkillButton_UIBP",
      WidgetClass = "GameLua.GameCore.Module.Skill.SkillUI.SkillUIWidgetTemplate",
      MountData = {
        MountName = "CanvasPanel_SkillSlot1"
      },
      SkillIcon = {
        [ESkillIconStatus.IconBtnNormal] = "/Game/Mod/Halloween6/Arts/UI/Atlas/Halloween6/Frames/ZD_Icon_ContractSummon_png.ZD_Icon_ContractSummon_png",
        [ESkillIconStatus.IconBtnInCD] = "/Game/Mod/Halloween6/Arts/UI/Atlas/Halloween6/Frames/ZD_Icon_ContractSummon_png.ZD_Icon_ContractSummon_png",
        [ESkillIconStatus.IconBtnActive] = "/Game/Mod/Halloween6/Arts/UI/Atlas/Halloween6/Frames/ZD_Icon_ContractSummon_png.ZD_Icon_ContractSummon_png"
      }
    }
  },
  [4611002] = {
    KillInfoIcon = "/Game/Arts/UI/NoAtlas/KillInfoTypeIcon/killfeed_cause_Centaur.killfeed_cause_Centaur"
  },
  [4602045] = {
    SkillCDParams = {
      [1] = {
        SkillCDClass = "GameLua.Mod.Library.GamePlay.Skill.SkillCD.SkillCD_Time",
        Params = {nCD = 0.5}
      }
    }
  }
}
Config[4602017] = Config[4602007]
Config[4602018] = Config[4602008]
return Config
