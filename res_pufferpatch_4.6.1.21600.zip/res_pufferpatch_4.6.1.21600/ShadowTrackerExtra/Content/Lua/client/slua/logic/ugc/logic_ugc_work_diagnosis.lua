-- 设置已启用自动解析化
-- TELEGRAM:@RJTOOL @BYRJ6
-- 解包层数: 0；移除诱饵行: 0；还原字符串: 0

local Util_UGC = require("client.slua.logic.ugc.util_ugc")
local LocUtil = require("common.loc_util")
local TimeUtil = require("client.common.time_util")
local LogicUGCWorkDiagnosis = {}
local REPORT_DIAG_SCORE_CD = 5
local P0_ISSUE_SCORE_MAX = 59

function LogicUGCWorkDiagnosis:OnInitialize()
end

function LogicUGCWorkDiagnosis:OnLogOut()
  self:ClearDiagnosisBenchmark()
  self.lastReportDiagScoreTime = nil
  self.diagResultCache = nil
end

local EDIT_TIME_SUFFICIENT_KEY
local GetEditTimeSufficientPrefType = function()
  if not EDIT_TIME_SUFFICIENT_KEY then
    local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
    EDIT_TIME_SUFFICIENT_KEY = PlayerPrefsSystem.ePlayerPrefsType.eUGCEditTimeSufficientClicked
  end
  return EDIT_TIME_SUFFICIENT_KEY
end

function LogicUGCWorkDiagnosis:IsEditTimeSufficientClicked(createTime)
  local uid = DataMgr.roleData.uid
  if not uid or not createTime then
    return false
  end
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  local data = PlayerPrefsSystem.LoadFileToTable_N(GetEditTimeSufficientPrefType()) or {}
  local uidData = data[tostring(uid)] or {}
  return uidData[tostring(createTime)] == true
end

function LogicUGCWorkDiagnosis:MarkEditTimeSufficientClicked(createTime)
  local uid = DataMgr.roleData.uid
  if not uid or not createTime then
    return
  end
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  local prefType = GetEditTimeSufficientPrefType()
  local data = PlayerPrefsSystem.LoadFileToTable_N(prefType) or {}
  data[tostring(uid)] = data[tostring(uid)] or {}
  if data[tostring(uid)][tostring(createTime)] ~= true then
    data[tostring(uid)][tostring(createTime)] = true
    PlayerPrefsSystem.SaveTableToFile_N(data, prefType)
  end
end

function LogicUGCWorkDiagnosis:IsOptimizeGuideShown(modId)
  if not modId then
    return false
  end
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  local Record = PlayerPrefsSystem.LoadFileToTable_N(PlayerPrefsSystem.ePlayerPrefsType.eUGCOptimizeGuideShown) or {}
  return Record[tostring(modId)] == true
end

function LogicUGCWorkDiagnosis:MarkOptimizeGuideShown(modId)
  if not modId then
    return
  end
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  local Record = PlayerPrefsSystem.LoadFileToTable_N(PlayerPrefsSystem.ePlayerPrefsType.eUGCOptimizeGuideShown) or {}
  if Record[tostring(modId)] ~= true then
    Record[tostring(modId)] = true
    PlayerPrefsSystem.SaveTableToFile_N(Record, PlayerPrefsSystem.ePlayerPrefsType.eUGCOptimizeGuideShown)
  end
end

local WORK_DIAGNOSIS_TAG = "[WorkDiagnosis]"
local ParseParam = function(value)
  if value == nil or value == "/" or value == "" then
    return nil
  end
  local num = tonumber(value)
  return num or value
end
local LoadDiagnosticConfig = function()
  local rawConfig = CDataTable.GetTable("UGCWorkInfoDiagnosisCfg")
  if not rawConfig then
    print(WORK_DIAGNOSIS_TAG .. " LoadDiagnosticConfig: UGCWorkInfoDiagnosisCfg not found")
    return {}
  end
  local result = {}
  for _, row in pairs(rawConfig) do
    local diagID = row.ID
    local item = {
      ID = diagID,
      Group = row.Group or 0,
      GroupMaxScore = row.GroupMaxScore or 0,
      GroupName = row.GroupName or "",
      TitleLocKey = row.TitleLocKey,
      SuggestionLocKey = row.SuggestionLocKey,
      Priority = row.Priority or 2,
      JumpTarget = row.JumpTarget or "",
      JumpTargetID = row.JumpTargetID or "",
      JumpSubTargetID = row.JumpSubTargetID or "",
      ConditionDesc = row.ConditionDesc or "",
      ParamX = ParseParam(row.ParamX),
      ParamY = ParseParam(row.ParamY),
      CheckFunc = ParseParam(row.CheckFunc),
      Score = ParseParam(row.Score)
    }
    table.insert(result, item)
  end
  return result
end
local LoadGroupScoreConfig = function()
  local config = LoadDiagnosticConfig()
  local groupScores = {}
  for _, item in ipairs(config) do
    if item.GroupMaxScore and item.GroupMaxScore > 0 then
      groupScores[item.Group] = item.GroupMaxScore
    end
  end
  return groupScores
end
local LoadTagPlayStyleReference = function()
  local rawConfig = CDataTable.GetTable("UGCTagDiagnosisMapping")
  if not rawConfig then
    print(WORK_DIAGNOSIS_TAG .. " LoadTagPlayStyleReference: UGCTagDiagnosisMapping not found")
    return {}
  end
  local result = {}
  for _, row in pairs(rawConfig) do
    result[row.TagID] = {
      name = row.TagName or "",
      minStartPlayerNum = row.MinStartPlayerNum or 0,
      needPlayTest = row.NeedPlayTest == 1,
      mlTagCategory = row.MLTagCategory or 0
    }
  end
  return result
end
local ResolvePrimaryTagID = function(tagList)
  if not tagList or #tagList == 0 then
    return nil
  end
  local Config_UGC = require("client.slua.logic.ugc.config_ugc")
  for _, tagID in ipairs(tagList) do
    local tagConfig = Config_UGC.GetTagConfigByID(tagID)
    if tagConfig and tagConfig.PrimaryType and tagConfig.PrimaryType ~= 0 then
      return tagID
    end
  end
  return nil
end
local GetPlayStyleReference = function(primaryTagID)
  if not primaryTagID then
    return nil
  end
  local reference = LoadTagPlayStyleReference()
  local ref = reference[primaryTagID]
  if not ref then
    return nil
  end
  return {
    name = ref.name,
    minStartPlayerNum = ref.minStartPlayerNum,
    needPlayTest = ref.needPlayTest,
    mlTagCategory = ref.mlTagCategory
  }
end
local CollectWorkData = function(modInfo)
  if not modInfo then
    return nil
  end
  local setting = modInfo.setting or {}
  local base = modInfo.base or {}
  local stat = modInfo.stat or {}
  local workData = {
    modInfo = modInfo,
    title = setting.name or "",
    desc = setting.desc or "",
    tagList = setting.tag_v2 or {},
    featureTagList = setting.features_2_tags or {},
    mainTagCheckProba = base.main_tag_check_proba,
    recommendPlayerNum = 0,
    minStartPlayerNum = 0,
    coverCount = 0,
    hasCover = false,
    editTime = (stat.EditTime or 0) / 60,
    hasPlayedCompleted = setting.has_played_completed or 0,
    gameResultAuthorFinishCnt = modInfo.game_result_author_finish_cnt or 0,
    isFirstPublish = not base.mod_id_rela or base.mod_id_rela == 0,
    publishState = setting.publish_state or 1,
    specThemeID = base.spec_theme_id,
    selectedSeasonActID = nil,
    primaryTagID = nil,
    primaryTagName = nil,
    refMinStartPlayerNum = nil,
    refNeedPlayTest = nil
  }
  if setting.team_size == -1 then
    workData.recommendPlayerNum = setting.max_num or 0
  else
    local minTeamSize = setting.team_min_size or setting.team_size
    if minTeamSize and setting.min_start_team_num then
      workData.recommendPlayerNum = minTeamSize * setting.min_start_team_num
    elseif minTeamSize then
      workData.recommendPlayerNum = minTeamSize
    end
  end
  workData.minStartPlayerNum = Util_UGC.GetMinPlayerCount(modInfo)
  local viewPicList = setting.view_pic_list or {}
  local albumList = setting.album or {}
  workData.coverCount = #viewPicList
  workData.hasCover = setting.thumb_index and 0 < setting.thumb_index or false
  local customPhotoCount = 0
  for _, albumIndex in ipairs(viewPicList) do
    local albumInfo = albumList[albumIndex]
    if albumInfo and albumInfo.custom_photo then
      customPhotoCount = customPhotoCount + 1
    end
  end
  workData.customPhotoCount = customPhotoCount
  workData.ingameScreenshotCount = workData.coverCount - customPhotoCount
  workData.primaryTagID = ResolvePrimaryTagID(workData.tagList)
  local ref = GetPlayStyleReference(workData.primaryTagID)
  if ref then
    workData.primaryTagName = ref.name
    workData.refMinStartPlayerNum = ref.minStartPlayerNum
    workData.refNeedPlayTest = ref.needPlayTest
  end
  return workData
end
local CheckFuncs = {
  TitleTooShort = function(workData, params)
    local titleLen = Util_UGC.GetTextLengthAndSubStr(workData.title)
    if 0 < titleLen and titleLen < (params and params.ParamX or 8) then
      return true
    end
    return false
  end,
  TitleTooLong = function(workData, params)
    local maxLen = params and params.ParamX or 35
    local titleLen = Util_UGC.GetTextLengthAndSubStr(workData.title)
    if maxLen < titleLen then
      return true, {
        ["0"] = tostring(maxLen)
      }
    end
    return false
  end,
  DescTooShort = function(workData, params)
    local descLen = Util_UGC.GetTextLengthAndSubStr(workData.desc)
    if descLen < (params and params.ParamX or 80) then
      return true
    end
    return false
  end,
  DescTooLong = function(workData, params)
    local descLen = Util_UGC.GetTextLengthAndSubStr(workData.desc)
    if descLen > (params and params.ParamX or 220) then
      return true
    end
    return false
  end,
  NoFeatureTag = function(workData, params)
    local tagList = workData.tagList or {}
    local Config_UGC = require("client.slua.logic.ugc.config_ugc")
    local featureCount = 0
    for _, tagID in ipairs(tagList) do
      if tagID and tagID ~= 0 then
        local tagCfg = Config_UGC.GetTagConfigByID(tagID)
        if tagCfg and (not tagCfg.PrimaryType or tagCfg.PrimaryType == 0) then
          featureCount = featureCount + 1
        end
      end
    end
    if featureCount == 0 then
      return true
    end
    return false
  end,
  MainTagMismatch = function(workData, params)
    if not workData.mainTagCheckProba then
      return false
    end
    local thresholdValue = params and params.ParamX or 0.3
    if thresholdValue > workData.mainTagCheckProba then
      return true
    end
    return false
  end,
  MinStartNumTooLow = function(workData, params)
    if not workData.refMinStartPlayerNum then
      return false
    end
    if workData.minStartPlayerNum < workData.refMinStartPlayerNum then
      return true
    end
    return false
  end,
  MinStartNumTooHigh = function(workData, params)
    if not workData.refMinStartPlayerNum then
      return false
    end
    if workData.minStartPlayerNum > workData.refMinStartPlayerNum then
      return true
    end
    return false
  end,
  CoverCountEquals = function(workData, params)
    if workData.coverCount == (params and params.ParamX or 0) then
      return true
    end
    return false
  end,
  CoverCountTooFew = function(workData, params)
    local threshold = params and params.ParamX or 3
    if workData.coverCount > 0 and threshold > workData.coverCount then
      return true
    end
    return false
  end,
  NoIngameScreenshot = function(workData, params)
    if workData.coverCount > 0 and workData.ingameScreenshotCount == 0 then
      return true
    end
    return false
  end,
  EditTimeTooShort = function(workData, params)
    if workData.editTime < (params and params.ParamX or 30) then
      return true
    end
    return false
  end,
  EditTimeMedium = function(workData, params)
    local minX = params and params.ParamX or 30
    local maxY = params and params.ParamY or 120
    if minX <= workData.editTime and maxY > workData.editTime then
      return true
    end
    return false
  end,
  EditTimeSufficient = function(workData, params)
    if workData.editTime < (params and params.ParamX or 120) then
      return false
    end
    local createTime = workData.modInfo and workData.modInfo.base and workData.modInfo.base.create_time
    if createTime and LogicUGCWorkDiagnosis:IsEditTimeSufficientClicked(createTime) then
      return false
    end
    return true
  end,
  PlayTestNotCompleted = function(workData, params)
    if not workData.refNeedPlayTest then
      return false
    end
    if workData.hasPlayedCompleted == 0 and workData.gameResultAuthorFinishCnt == 0 then
      return true
    end
    return false
  end,
  LowReadinessScore = function(workData, params, context)
    if not context or not context.score then
      return false
    end
    local threshold = params and params.ParamX or 60
    if threshold > context.score then
      return true
    end
    return false
  end,
  MeetEventRule = function(workData, params)
    if workData.selectedSeasonActID then
      return false
    end
    local Logic_UGC_SeasonTemplate = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_season_template)
    if not Logic_UGC_SeasonTemplate then
      return false
    end
    local seasonCfgs = Logic_UGC_SeasonTemplate:GetValidSeasonCfgData(false)
    if not seasonCfgs or not next(seasonCfgs) then
      return false
    end
    local TimeUtil = require("client.common.time_util")
    local serverTime = TimeUtil.GetServerTimeInSec()
    local config_ugc_season_template = require("client.slua.umg.ugc.SeasonTemplate.config_ugc_season_template")
    for _, actCfg in pairs(seasonCfgs) do
      local timeLine = actCfg.activity_info and actCfg.activity_info.time_line or {}
      for _, step in pairs(timeLine) do
        if step.type == config_ugc_season_template.C_EnumStep.CreationPeriod then
          local startTime = step.period and step.period[1]
          local endTime = step.period and step.period[2]
          if startTime and endTime and serverTime >= startTime and serverTime <= endTime then
            local nActID = actCfg.activity_info and actCfg.activity_info.game_manage_id
            local bCanSet = Logic_UGC_SeasonTemplate:CheckCanSetSeasonLabel(nActID, workData.modInfo)
            if bCanSet then
              return true
            end
          end
          break
        end
      end
    end
    return false
  end,
  MeetFeatureRule = function(workData, params)
    if workData.specThemeID then
      return false
    end
    local logic_ugc_album_theme = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_album_theme)
    if not logic_ugc_album_theme then
      return false
    end
    local validList = logic_ugc_album_theme:GetAlbumThemeLoopData()
    if validList and 0 < #validList then
      return true
    end
    return false
  end,
  FirstPublish = function(workData, params)
    local Config_UGC = require("client.slua.logic.ugc.config_ugc")
    if workData.isFirstPublish and workData.publishState ~= Config_UGC.E_ModPubState.Private then
      return true
    end
    return false
  end
}
local CalculateScore = function(allResults)
  local groupScoreConfig = LoadGroupScoreConfig()
  local groupScores = {}
  for groupID, maxScore in pairs(groupScoreConfig) do
    groupScores[groupID] = maxScore
  end
  for _, item in ipairs(allResults) do
    if item.bTriggered then
      local groupID = item.Group
      local maxScore = groupScoreConfig[groupID]
      local itemScore = item.Score
      if maxScore and itemScore ~= nil and itemScore < groupScores[groupID] then
        groupScores[groupID] = itemScore
      end
    end
  end
  local score = 0
  for _, groupScore in pairs(groupScores) do
    score = score + groupScore
  end
  if score < 0 then
    score = 0
  end
  return score, groupScores
end
local FillSuggestionTemplate = function(suggestion, extraData)
  if not extraData then
    return suggestion
  end
  local result = suggestion or ""
  for key, value in pairs(extraData) do
    local placeholder = "{" .. key .. "}"
    result = string.gsub(result, placeholder, tostring(value))
  end
  return result
end
local EvaluateItem = function(itemConfig, workData, params, context)
  local bTriggered = false
  local extraData
  if itemConfig.CheckFunc then
    local checkFunc = CheckFuncs[itemConfig.CheckFunc]
    if checkFunc then
      bTriggered, extraData = checkFunc(workData, params, context)
    end
  end
  return {
    ID = itemConfig.ID,
    Group = itemConfig.Group,
    GroupName = itemConfig.GroupName or "",
    Priority = itemConfig.Priority,
    Title = LocUtil.GetLocalizeResStr(itemConfig.TitleLocKey),
    Suggestion = FillSuggestionTemplate(LocUtil.GetLocalizeResStr(itemConfig.SuggestionLocKey), extraData),
    bTriggered = bTriggered,
    Score = itemConfig.Score,
    CheckFunc = itemConfig.CheckFunc or "",
    JumpTargetID = itemConfig.JumpTargetID or "",
    JumpSubTargetID = itemConfig.JumpSubTargetID or ""
  }
end

function LogicUGCWorkDiagnosis:RunPreCheck(modInfo, overrides)
  local workData = CollectWorkData(modInfo)
  if not workData then
    return nil
  end
  if overrides then
    if overrides.title ~= nil then
      workData.title = overrides.title
    end
    if overrides.desc ~= nil then
      workData.desc = overrides.desc
    end
    if overrides.tagList ~= nil then
      workData.tagList = overrides.tagList
      workData.primaryTagID = ResolvePrimaryTagID(workData.tagList)
      local ref = GetPlayStyleReference(workData.primaryTagID)
      if ref then
        workData.primaryTagName = ref.name
        workData.refMinStartPlayerNum = ref.minStartPlayerNum
        workData.refNeedPlayTest = ref.needPlayTest
      else
        workData.primaryTagName = nil
        workData.refMinStartPlayerNum = nil
        workData.refNeedPlayTest = nil
      end
    end
    if overrides.featureTagList ~= nil then
      workData.featureTagList = overrides.featureTagList
    end
    if overrides.selectedSeasonActID ~= nil then
      workData.selectedSeasonActID = overrides.selectedSeasonActID
    end
    if overrides.specThemeID ~= nil then
      workData.specThemeID = overrides.specThemeID
    end
    if overrides.editTime ~= nil then
      workData.editTime = overrides.editTime
    end
  end
  local config = LoadDiagnosticConfig()
  local triggeredItems = {}
  local allResults = {}
  local deferredItems = {}
  for _, itemConfig in ipairs(config) do
    if itemConfig.GroupMaxScore and itemConfig.GroupMaxScore > 0 then
      local params
      if itemConfig.ParamX ~= nil or itemConfig.ParamY ~= nil then
        params = {
          ParamX = itemConfig.ParamX,
          ParamY = itemConfig.ParamY
        }
      end
      local result = EvaluateItem(itemConfig, workData, params, nil)
      table.insert(allResults, result)
      if result.bTriggered then
        table.insert(triggeredItems, result)
      end
    else
      table.insert(deferredItems, itemConfig)
    end
  end
  local score, groupScores = CalculateScore(allResults)
  local context = {score = score, groupScores = groupScores}
  for _, itemConfig in ipairs(deferredItems) do
    local params
    if itemConfig.ParamX ~= nil or itemConfig.ParamY ~= nil then
      params = {
        ParamX = itemConfig.ParamX,
        ParamY = itemConfig.ParamY
      }
    end
    local result = EvaluateItem(itemConfig, workData, params, context)
    table.insert(allResults, result)
    if result.bTriggered then
      table.insert(triggeredItems, result)
    end
  end
  for _, item in ipairs(triggeredItems) do
    if item.Priority == 0 then
      if score > P0_ISSUE_SCORE_MAX then
        score = P0_ISSUE_SCORE_MAX
      end
      break
    end
  end
  local result = {
    score = score,
    groupScores = groupScores,
    triggeredItems = triggeredItems,
    allResults = allResults
  }
  local modId = modInfo and modInfo.base and modInfo.base.mod_id
  if modId then
    self.diagResultCache = self.diagResultCache or {}
    self.diagResultCache[modId] = result
  end
  return result
end

function LogicUGCWorkDiagnosis:HasP0Issue(modInfo, overrides)
  local result = self:RunPreCheck(modInfo, overrides)
  if not result or not result.triggeredItems then
    return false
  end
  for _, item in ipairs(result.triggeredItems) do
    if item.Priority == 0 then
      return true
    end
  end
  return false
end

function LogicUGCWorkDiagnosis:CheckBeforeUsePromotionCard(modId)
  local LogicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
  if not LogicUGC then
    return false
  end
  local modInfo = LogicUGC:GetModByAllCache(modId)
  if not modInfo or not modInfo.pub_mod_meta then
    return false
  end
  local result = self:RunPreCheck(modInfo.pub_mod_meta)
  if not result then
    return false
  end
  local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
  UGCTLogReport:ReportDelay(TLogEventDefine.UGC_WorkDiagnosis_Run, 2)
  local cfgTable = CDataTable.GetTable("ugc_llm_dia_param_cfg")
  local row = cfgTable and cfgTable.DiaPromoPopupScore
  local threshold = row and row.value or 0
  if threshold > result.score then
    UIManager.ShowUI(UIManager.UI_Config.UGC_PromotionReminder_Popup_UIBP, modId)
    return true
  end
  return false
end

local DIAG_SCORE_SOURCE = {Tab3Diagnosis = 1, PromotionPopup = 2}

function LogicUGCWorkDiagnosis:ReportDiagScore(result, source, bForce)
  if not result or not result.groupScores then
    return
  end
  local scoreMap = {}
  local count = 0
  for groupID, score in pairs(result.groupScores) do
    if type(groupID) == "number" and 0 < groupID and type(score) == "number" and 0 < score then
      scoreMap[groupID] = score
      count = count + 1
    end
  end
  if count == 0 or 50 < count then
    log_warning(WORK_DIAGNOSIS_TAG .. " ReportDiagScore invalid score_map count = " .. tostring(count))
    return
  end
  if not bForce then
    local TimeUtil = require("client.common.time_util")
    local curTime = TimeUtil.GetServerTimeInSec()
    if self.lastReportDiagScoreTime and curTime - self.lastReportDiagScoreTime < REPORT_DIAG_SCORE_CD then
      return
    end
    self.lastReportDiagScoreTime = curTime
  end
  local UGCModHandler = require("client.network.Protocol.UGCModHandler")
  UGCModHandler.send_ugc_report_diag_score_req(scoreMap, source)
end

function LogicUGCWorkDiagnosis:GetDiagResultByModId(modId)
  if not modId or not self.diagResultCache then
    return nil
  end
  return self.diagResultCache[modId]
end

local DiagBenchmarkCache = {}
local LoadDataCenterDiagConfig = function()
  local rawConfig = CDataTable.GetTable("UGCDataCenterDiagnosisCfg")
  if not rawConfig then
    print(WORK_DIAGNOSIS_TAG .. " LoadDataCenterDiagConfig: UGCDataCenterDiagnosisCfg not found")
    return {}
  end
  local result = {}
  for _, row in pairs(rawConfig) do
    local item = {
      ID = row.ID,
      MetricLocKey = row.MetricLocKey,
      MetricLogic = row.MetricLogic or "",
      ConditionDesc = row.ConditionDesc or "",
      ParamX = ParseParam(row.ParamX),
      ParamY = ParseParam(row.ParamY),
      TitleLocKey = row.TitleLocKey,
      SuggestionLocKey = row.SuggestionLocKey,
      Priority = row.Priority or 2,
      JumpTarget = row.JumpTarget or ""
    }
    table.insert(result, item)
  end
  return result
end
local DateStrToTimestamp = function(dateStr)
  if not dateStr or type(dateStr) ~= "string" or #dateStr < 8 then
    return nil
  end
  local year = tonumber(string.sub(dateStr, 1, 4))
  local month = tonumber(string.sub(dateStr, 5, 6))
  local day = tonumber(string.sub(dateStr, 7, 8))
  if not (year and month) or not day then
    return nil
  end
  return TimeUtil.UnixTimeToUnixstamp(year, month, day, 0, 0, 0, false)
end
local SumByWindow = function(data, startTs, endTsExclusive)
  if not data or not next(data) then
    return 0
  end
  local sum = 0
  for ts, value in pairs(data) do
    if startTs <= ts and ts < endTsExclusive then
      sum = sum + (value or 0)
    end
  end
  return sum
end
local SumIncrementByWindow = function(data, startTs, endTsExclusive)
  if not (data and next(data) and startTs) or not endTsExclusive then
    return nil
  end
  local sorted = {}
  for ts, value in pairs(data) do
    table.insert(sorted, {ts = ts, value = value})
  end
  table.sort(sorted, function(a, b)
    return a.ts < b.ts
  end)
  local sum = 0
  local previousValue
  local bSkippedPseudoDelta = false
  for _, item in ipairs(sorted) do
    if previousValue ~= nil and startTs <= item.ts and endTsExclusive > item.ts then
      local delta = item.value - previousValue
      if delta < 0 then
        delta = 0
      end
      if previousValue == 0 and item.value > 0 and not bSkippedPseudoDelta then
        bSkippedPseudoDelta = true
        delta = 0
      end
      sum = sum + delta
    end
    previousValue = item.value
  end
  return sum
end
local AvgByWindow = function(data, startTs, endTsExclusive)
  if not data or not next(data) then
    return 0
  end
  local sum = 0
  local count = 0
  for ts, value in pairs(data) do
    if startTs <= ts and ts < endTsExclusive then
      sum = sum + (value or 0)
      count = count + 1
    end
  end
  if 0 < count then
    return sum / count
  end
  return 0
end
local GetDiagWindow = function(meta)
  local modId = meta and meta.mod_id
  local benchmarkData = modId and DiagBenchmarkCache[modId] or nil
  local startTs = DateStrToTimestamp(benchmarkData and benchmarkData.window_start_date or nil)
  local endTs = DateStrToTimestamp(benchmarkData and benchmarkData.window_end_date or nil)
  endTs = endTs and endTs + 86400
  if startTs and endTs then
    return startTs, endTs
  end
  return nil, nil
end
local CollectDiagData = function(meta)
  if not meta then
    return nil
  end
  local modId = meta.mod_id
  local benchmarkData = modId and DiagBenchmarkCache[modId] or nil
  local Config_UGC_Center = require("client.slua.logic.ugc.center.config_ugc_center")
  local Logic_UGC_DataCenter = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_datacenter)
  local offlineStat = meta.offline_stat_data or {}
  local lineChartData = offlineStat.line_chart_data or {}
  local playTimeDist = offlineStat.play_time or {}
  local startTs, endTsExclusive = GetDiagWindow(meta)
  local bHasWindow = startTs and endTsExclusive and true or false
  local exposePvData = lineChartData[Config_UGC_Center.Config_DataCenter_OverviewType.expose_cnt]
  local clickPvData = lineChartData[Config_UGC_Center.Config_DataCenter_OverviewType.click_cnt]
  local playCntData = lineChartData[Config_UGC_Center.Config_DataCenter_OverviewType.play_cnt]
  local retentionData = lineChartData[Config_UGC_Center.tracking_point_chart_type.Subsistence]
  local exposureCnt, clickCnt, playCnt, retentionRate
  if bHasWindow then
    if exposePvData and next(exposePvData) then
      exposureCnt = SumByWindow(exposePvData, startTs, endTsExclusive)
    end
    if clickPvData and next(clickPvData) then
      clickCnt = SumByWindow(clickPvData, startTs, endTsExclusive)
    end
    if playCntData and next(playCntData) then
      playCnt = SumIncrementByWindow(playCntData, startTs, endTsExclusive)
    end
    if retentionData and next(retentionData) then
      retentionRate = AvgByWindow(retentionData, startTs, endTsExclusive)
    end
  end
  local clickRate
  if exposureCnt and clickCnt and 0 < exposureCnt then
    clickRate = clickCnt / exposureCnt
  end
  local startRate
  if clickCnt and 0 < clickCnt and playCnt then
    startRate = playCnt / clickCnt
  end
  local playTimeOne = playTimeDist.one or 0
  local playTimeOneFive = playTimeDist.one_five or 0
  local playTimeFiveTen = playTimeDist.five_ten or 0
  local playTimeTenFifteen = playTimeDist.ten_fifteen or 0
  local playTimeFifteen = playTimeDist.fifteen or 0
  local totalPlayTimeCnt = playTimeOne + playTimeOneFive + playTimeFiveTen + playTimeTenFifteen + playTimeFifteen
  local churnRate = 0
  if 0 < totalPlayTimeCnt then
    churnRate = playTimeOne / totalPlayTimeCnt
  end
  local validPlayRate = 0
  if 0 < totalPlayTimeCnt then
    validPlayRate = (playTimeFiveTen + playTimeTenFifteen + playTimeFifteen) / totalPlayTimeCnt
  end
  local deepPlayRate = 0
  if 0 < totalPlayTimeCnt then
    deepPlayRate = (playTimeTenFifteen + playTimeFifteen) / totalPlayTimeCnt
  end
  local diagData = {
    exposureCnt = exposureCnt,
    clickCnt = clickCnt,
    clickRate = clickRate,
    startCnt = playCnt,
    startRate = startRate,
    churnRate = churnRate,
    validPlayRate = validPlayRate,
    deepPlayRate = deepPlayRate,
    retentionRate = retentionRate,
    playCnt = playCnt,
    benchmarkClickRate = benchmarkData and benchmarkData.click_rate or 0,
    benchmarkStartRate = benchmarkData and benchmarkData.start_rate or 0,
    benchmarkChurnRate = benchmarkData and benchmarkData.start_loss_rate or 0,
    benchmarkValidPlayRate = benchmarkData and benchmarkData.valid_play_rate or 0,
    benchmarkDeepPlayRate = benchmarkData and benchmarkData.deep_play_rate or 0,
    benchmarkRetentionRate = benchmarkData and benchmarkData.replay_rate or 0,
    bHasBenchmark = benchmarkData ~= nil,
    bHasWindow = bHasWindow
  }
  return diagData
end
local DataCenterCheckFuncs = {
  LowExposure = function(diagData, params)
    if not diagData.exposureCnt then
      return nil
    end
    local threshold = params and params.ParamX or 1000
    if threshold > diagData.exposureCnt then
      return true
    end
    return false
  end,
  LowClickRate = function(diagData, params)
    if not diagData.clickRate or not diagData.exposureCnt then
      return nil
    end
    local exposureThreshold = params and params.ParamX or 1000
    local ratio = params and params.ParamY or 0.9
    if exposureThreshold >= diagData.exposureCnt then
      return nil
    end
    local benchmark = (diagData.benchmarkClickRate or 0) * ratio
    if benchmark > diagData.clickRate then
      return true
    end
    return false
  end,
  LowStartRate = function(diagData, params)
    if not diagData.clickCnt or not diagData.startRate then
      return nil
    end
    local clickThreshold = params and params.ParamX or 100
    local ratio = params and params.ParamY or 0.9
    if clickThreshold >= diagData.clickCnt then
      return nil
    end
    local benchmark = (diagData.benchmarkStartRate or 0) * ratio
    if benchmark > diagData.startRate then
      return true
    end
    return false
  end,
  HighChurnRate = function(diagData, params)
    if not diagData.playCnt then
      return nil
    end
    local playThreshold = params and params.ParamX or 50
    local ratio = params and params.ParamY or 1.1
    if playThreshold > diagData.playCnt then
      return nil
    end
    local benchmark = (diagData.benchmarkChurnRate or 0) * ratio
    if benchmark < diagData.churnRate then
      return true
    end
    return false
  end,
  LowValidPlayRate = function(diagData, params)
    if not diagData.playCnt then
      return nil
    end
    local playThreshold = params and params.ParamX or 50
    local ratio = params and params.ParamY or 0.9
    if playThreshold > diagData.playCnt then
      return nil
    end
    local benchmark = (diagData.benchmarkValidPlayRate or 0) * ratio
    if benchmark > diagData.validPlayRate then
      return true
    end
    return false
  end,
  LowDeepPlayRate = function(diagData, params)
    if not diagData.playCnt then
      return nil
    end
    local playThreshold = params and params.ParamX or 50
    local ratio = params and params.ParamY or 0.9
    if playThreshold > diagData.playCnt then
      return nil
    end
    local benchmark = (diagData.benchmarkDeepPlayRate or 0) * ratio
    if benchmark > diagData.deepPlayRate then
      return true
    end
    return false
  end,
  LowRetentionRate = function(diagData, params)
    if not diagData.playCnt or not diagData.retentionRate then
      return nil
    end
    local playThreshold = params and params.ParamX or 50
    local ratio = params and params.ParamY or 0.9
    if playThreshold > diagData.playCnt then
      return nil
    end
    local benchmark = (diagData.benchmarkRetentionRate or 0) * ratio
    if benchmark > diagData.retentionRate then
      return true
    end
    return false
  end
}
local DataCenterDiagID2Func = {
  [1] = DataCenterCheckFuncs.LowExposure,
  [2] = DataCenterCheckFuncs.LowClickRate,
  [3] = DataCenterCheckFuncs.LowStartRate,
  [4] = DataCenterCheckFuncs.HighChurnRate,
  [5] = DataCenterCheckFuncs.LowValidPlayRate,
  [6] = DataCenterCheckFuncs.LowDeepPlayRate,
  [7] = DataCenterCheckFuncs.LowRetentionRate
}
local GetDiagConfigByID = function(diagID)
  if not diagID then
    return nil
  end
  local config = LoadDataCenterDiagConfig()
  for _, itemConfig in ipairs(config) do
    if itemConfig.ID == diagID then
      return itemConfig
    end
  end
  return nil
end
local IsNormalByID = function(diagData, diagID)
  if not diagData or not DataCenterDiagID2Func[diagID] then
    return nil
  end
  if not diagData.bHasBenchmark then
    return nil
  end
  local itemConfig = GetDiagConfigByID(diagID)
  local params
  if itemConfig and (itemConfig.ParamX ~= nil or itemConfig.ParamY ~= nil) then
    params = {
      ParamX = itemConfig.ParamX,
      ParamY = itemConfig.ParamY
    }
  end
  local bTriggered = DataCenterDiagID2Func[diagID](diagData, params)
  if bTriggered == nil then
    return nil
  end
  return not bTriggered
end

function LogicUGCWorkDiagnosis:ReqDiagnosisBenchmark(modId)
  if not modId then
    return
  end
  if DiagBenchmarkCache[modId] then
    return
  end
  local UGCModHandler = require("client.network.Protocol.UGCModHandler")
  UGCModHandler.send_ugc_get_creator_care_bm_req(modId)
end

function LogicUGCWorkDiagnosis:SetDiagnosisBenchmark(modId, benchmarkData, mltag)
  if not modId or not benchmarkData then
    return
  end
  DiagBenchmarkCache[modId] = benchmarkData
end

function LogicUGCWorkDiagnosis:ClearDiagnosisBenchmark(modId)
  if modId then
    DiagBenchmarkCache[modId] = nil
  else
    DiagBenchmarkCache = {}
  end
end

function LogicUGCWorkDiagnosis:RunDataCenterCheck(meta)
  local diagData = CollectDiagData(meta)
  if not diagData then
    return nil
  end
  local config = LoadDataCenterDiagConfig()
  local triggeredItems = {}
  local allResults = {}
  for _, itemConfig in ipairs(config) do
    local params
    if itemConfig.ParamX ~= nil or itemConfig.ParamY ~= nil then
      params = {
        ParamX = itemConfig.ParamX,
        ParamY = itemConfig.ParamY
      }
    end
    local bTriggered, extraData
    local checkFunc = DataCenterDiagID2Func[itemConfig.ID]
    if checkFunc then
      bTriggered, extraData = checkFunc(diagData, params)
    end
    local result = {
      ID = itemConfig.ID,
      Priority = itemConfig.Priority,
      Title = LocUtil.GetLocalizeResStr(itemConfig.TitleLocKey),
      Suggestion = FillSuggestionTemplate(LocUtil.GetLocalizeResStr(itemConfig.SuggestionLocKey), extraData),
      JumpTarget = itemConfig.JumpTarget or "",
      bTriggered = bTriggered
    }
    table.insert(allResults, result)
    if bTriggered then
      table.insert(triggeredItems, result)
    end
  end
  table.sort(triggeredItems, function(a, b)
    return (a.Priority or 2) < (b.Priority or 2)
  end)
  return {
    triggeredItems = triggeredItems,
    allResults = allResults,
    bNoData = not diagData.bHasWindow or not diagData.exposureCnt or not diagData.clickCnt or not diagData.playCnt
  }
end

local CalcBNormal = function(value, benchmark)
  if value and benchmark then
    return benchmark <= value
  end
  return nil
end

function LogicUGCWorkDiagnosis:GetCheckItemComparison(meta)
  local modId = meta and meta.mod_id
  local benchmarkData = modId and DiagBenchmarkCache[modId] or nil
  local exposureValue = self:GetExposureCnt(meta)
  local exposureBenchmark = benchmarkData and benchmarkData.expose_cnt or nil
  local clickValue = self:GetClickCnt(meta)
  local clickBenchmark = benchmarkData and benchmarkData.click_cnt or nil
  local playCntValue = self:GetPlayCntInWindow(meta)
  local playCntBenchmark = benchmarkData and benchmarkData.play_cnt or nil
  local validPlayCntValue = self:GetValidPlayCntInWindow(meta)
  local validPlayCntBenchmark = benchmarkData and benchmarkData.valid_play_cnt or nil
  local diagData = CollectDiagData(meta)
  return {
    [1] = {
      value = exposureValue,
      benchmark = exposureBenchmark,
      bNormal = IsNormalByID(diagData, 1)
    },
    [2] = {
      value = clickValue,
      benchmark = clickBenchmark,
      bNormal = IsNormalByID(diagData, 2)
    },
    [3] = {
      value = playCntValue,
      benchmark = playCntBenchmark,
      bNormal = IsNormalByID(diagData, 3)
    },
    [4] = {
      value = validPlayCntValue,
      benchmark = validPlayCntBenchmark,
      bNormal = IsNormalByID(diagData, 4)
    }
  }
end

function LogicUGCWorkDiagnosis:GetExposureCnt(meta)
  if not (meta and meta.offline_stat_data) or not meta.offline_stat_data.line_chart_data then
    return nil
  end
  local Config_UGC_Center = require("client.slua.logic.ugc.center.config_ugc_center")
  local exposePvData = meta.offline_stat_data.line_chart_data[Config_UGC_Center.Config_DataCenter_OverviewType.expose_cnt]
  if not exposePvData or not next(exposePvData) then
    return nil
  end
  local startTs, endTsExclusive = GetDiagWindow(meta)
  if not startTs or not endTsExclusive then
    return nil
  end
  return SumByWindow(exposePvData, startTs, endTsExclusive)
end

function LogicUGCWorkDiagnosis:GetClickCnt(meta)
  if not (meta and meta.offline_stat_data) or not meta.offline_stat_data.line_chart_data then
    return nil
  end
  local Config_UGC_Center = require("client.slua.logic.ugc.center.config_ugc_center")
  local clickPvData = meta.offline_stat_data.line_chart_data[Config_UGC_Center.Config_DataCenter_OverviewType.click_cnt]
  if not clickPvData or not next(clickPvData) then
    return nil
  end
  local startTs, endTsExclusive = GetDiagWindow(meta)
  if not startTs or not endTsExclusive then
    return nil
  end
  return SumByWindow(clickPvData, startTs, endTsExclusive)
end

function LogicUGCWorkDiagnosis:GetPlayCntInWindow(meta)
  if not (meta and meta.offline_stat_data) or not meta.offline_stat_data.line_chart_data then
    return nil
  end
  local Config_UGC_Center = require("client.slua.logic.ugc.center.config_ugc_center")
  local playCntData = meta.offline_stat_data.line_chart_data[Config_UGC_Center.Config_DataCenter_OverviewType.play_cnt]
  if not playCntData or not next(playCntData) then
    return nil
  end
  local startTs, endTsExclusive = GetDiagWindow(meta)
  if not startTs or not endTsExclusive then
    return nil
  end
  return SumIncrementByWindow(playCntData, startTs, endTsExclusive)
end

function LogicUGCWorkDiagnosis:GetValidPlayCntInWindow(meta)
  local playCntValue = self:GetPlayCntInWindow(meta)
  if not playCntValue then
    return nil
  end
  local validPlayRate = self:GetValidPlayRate(meta)
  if not validPlayRate then
    return nil
  end
  return math.floor(playCntValue * validPlayRate)
end

function LogicUGCWorkDiagnosis:GetChurnRate(meta)
  if not (meta and meta.offline_stat_data) or not meta.offline_stat_data.play_time then
    return 0
  end
  local playTimeDist = meta.offline_stat_data.play_time
  local playTimeOne = playTimeDist.one or 0
  local playTimeOneFive = playTimeDist.one_five or 0
  local playTimeFiveTen = playTimeDist.five_ten or 0
  local playTimeTenFifteen = playTimeDist.ten_fifteen or 0
  local playTimeFifteen = playTimeDist.fifteen or 0
  local totalPlayTimeCnt = playTimeOne + playTimeOneFive + playTimeFiveTen + playTimeTenFifteen + playTimeFifteen
  if totalPlayTimeCnt <= 0 then
    return 0
  end
  return playTimeOne / totalPlayTimeCnt
end

function LogicUGCWorkDiagnosis:GetDeepPlayRate(meta)
  if not (meta and meta.offline_stat_data) or not meta.offline_stat_data.play_time then
    return 0
  end
  local playTimeDist = meta.offline_stat_data.play_time
  local playTimeOne = playTimeDist.one or 0
  local playTimeOneFive = playTimeDist.one_five or 0
  local playTimeFiveTen = playTimeDist.five_ten or 0
  local playTimeTenFifteen = playTimeDist.ten_fifteen or 0
  local playTimeFifteen = playTimeDist.fifteen or 0
  local totalPlayTimeCnt = playTimeOne + playTimeOneFive + playTimeFiveTen + playTimeTenFifteen + playTimeFifteen
  if totalPlayTimeCnt <= 0 then
    return 0
  end
  return (playTimeTenFifteen + playTimeFifteen) / totalPlayTimeCnt
end

function LogicUGCWorkDiagnosis:GetValidPlayRate(meta)
  if not (meta and meta.offline_stat_data) or not meta.offline_stat_data.play_time then
    return 0
  end
  local playTimeDist = meta.offline_stat_data.play_time
  local playTimeOne = playTimeDist.one or 0
  local playTimeOneFive = playTimeDist.one_five or 0
  local playTimeFiveTen = playTimeDist.five_ten or 0
  local playTimeTenFifteen = playTimeDist.ten_fifteen or 0
  local playTimeFifteen = playTimeDist.fifteen or 0
  local totalPlayTimeCnt = playTimeOne + playTimeOneFive + playTimeFiveTen + playTimeTenFifteen + playTimeFifteen
  if totalPlayTimeCnt <= 0 then
    return 0
  end
  return (playTimeFiveTen + playTimeTenFifteen + playTimeFifteen) / totalPlayTimeCnt
end

function LogicUGCWorkDiagnosis:GetRetentionRate(meta)
  if not (meta and meta.offline_stat_data) or not meta.offline_stat_data.line_chart_data then
    return 0
  end
  local Config_UGC_Center = require("client.slua.logic.ugc.center.config_ugc_center")
  local retentionData = meta.offline_stat_data.line_chart_data[Config_UGC_Center.tracking_point_chart_type.Subsistence]
  if not retentionData or not next(retentionData) then
    return 0
  end
  local startTs, endTsExclusive = GetDiagWindow(meta)
  if not startTs or not endTsExclusive then
    return 0
  end
  return AvgByWindow(retentionData, startTs, endTsExclusive)
end

local class = require("class")
local CModuleBase = require("client.module_framework.ModuleBase")
local CLogicUGCWorkDiagnosis = class(CModuleBase, nil, LogicUGCWorkDiagnosis)
return CLogicUGCWorkDiagnosis
