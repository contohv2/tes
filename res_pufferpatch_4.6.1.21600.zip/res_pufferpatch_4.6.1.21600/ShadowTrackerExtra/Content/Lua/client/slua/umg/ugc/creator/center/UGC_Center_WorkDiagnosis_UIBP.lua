-- 设置已启用自动解析化
-- TELEGRAM:@RJTOOL @BYRJ6
-- 解包层数: 0；移除诱饵行: 0；还原字符串: 0

local UGC_Center_WorkDiagnosis_UIBP = {}
local Config_UGC = require("client.slua.logic.ugc.config_ugc")
local StringUtil = require("common.string_util")
local TimeUtil = require("client.common.time_util")
local Util_UGC = require("client.slua.logic.ugc.util_ugc")

function UGC_Center_WorkDiagnosis_UIBP:ctor(_, modId)
  self.OpenTime = 0
  self.ModId = modId
  self.bDataReady = false
  self.bDiagResultShown = false
end

function UGC_Center_WorkDiagnosis_UIBP:OnInitialize()
  UGC_Center_WorkDiagnosis_UIBP.__super.OnInitialize(self)
  self.UIRoot.TextBlock_Title:SetText(LocUtil.GetLocalizeResStr(4600203))
  self.UIRoot.TextBlock_Churn:SetText(LocUtil.GetLocalizeResStr(4600209))
  self.UIRoot.TextBlock_Vivsit:SetText(LocUtil.GetLocalizeResStr(4600210))
  self.UIRoot.TextBlock_Retention:SetText(LocUtil.GetLocalizeResStr(4600211))
  self.UIRoot.TextBlock_Tips:SetText(LocUtil.GetLocalizeResStr(4600202))
  self.UIRoot.TextBlock_Suggestion:SetText(LocUtil.GetLocalizeResStr(4600213))
  self.UIRoot.TextBlock_Suggestion_01:SetText(LocUtil.GetLocalizeResStr(4600260))
  self.UIRoot.TextBlock_Tips_ing:SetText(LocUtil.GetLocalizeResStr(4600212))
  self.UIRoot.TextBlock_Dec:SetText(LocUtil.GetLocalizeResStr(4600269))
  self.CheckItems = {
    self.UIRoot.Check_Item_1,
    self.UIRoot.Check_Item_2,
    self.UIRoot.Check_Item_3,
    self.UIRoot.Check_Item_4
  }
  self:InitCheckItem(1, LocUtil.GetLocalizeResStr(4600204))
  self:InitCheckItem(2, LocUtil.GetLocalizeResStr(4600205))
  self:InitCheckItem(3, LocUtil.GetLocalizeResStr(4600206))
  self:InitCheckItem(4, LocUtil.GetLocalizeResStr(4600207))
  self.LoopScrollBox_Suggestion = self:InitScrollBox(self.UIRoot.LoopScrollBox_Suggestion)
  self.LoopScrollBox_Suggestion:SetRefreshItemCallback(self.OnRefreshSuggestionItem, self)
end

function UGC_Center_WorkDiagnosis_UIBP:RegistEvents()
  UGC_Center_WorkDiagnosis_UIBP.__super.RegistEvents(self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Close, self.OnClickClose, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_GET_MODDETAIL_DATA, self.OnRefreshDiagnosisData, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_CREATOR_CARE_DIAGNOSIS_BENCHMARK_RSP, self.OnDiagnosisBenchmarkRsp, self)
  self.LoopScrollBox_Suggestion:AddItemWidgetChildEvent("Button_Optimize", "OnClicked", self.OnClickOptimize, self)
  self:AddOnAnimationFinishedEvent("Anim_Loop", self.OnLoopAnimFinished, self)
end

function UGC_Center_WorkDiagnosis_UIBP:OnPostInitialize()
  UGC_Center_WorkDiagnosis_UIBP.__super.OnPostInitialize(self)
  self.OpenTime = TimeUtil.GetServerTimeInSec()
  self:SetSuggestionState(1)
  self:PlayUserWidgetAnimation(self.UIRoot.Anim_Robot, 0, 0, 0, 1)
  self.DiagDelayTimer = self:AddTimer(2, function()
    self.DiagDelayTimer = nil
    self:_TryShowDiagResult()
  end)
  self:RequestDiagnosisData()
end

function UGC_Center_WorkDiagnosis_UIBP:OnClose()
  if self.DiagDelayTimer then
    self:RemoveGameTimer(self.DiagDelayTimer)
    self.DiagDelayTimer = nil
  end
  self:ClearItemAnimTimers()
  self.UIRoot:StopAnimation(self.UIRoot.Anim_Robot)
  local UGCMacros = require("client.slua.logic.ugc.ugc_macros")
  local Logic_UGC_DataCenter = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_datacenter)
  Logic_UGC_DataCenter:ReportPanelStay(self.OpenTime, UGCMacros.ENU_UGC_TLOG_StayTime_TYPE.UGCCenterData_Mod)
end

function UGC_Center_WorkDiagnosis_UIBP:OnClickClose()
  self:PlayAudio(sound_config.close_v1)
  self:CloseSelf()
end

function UGC_Center_WorkDiagnosis_UIBP:OnDiagnosisBenchmarkRsp(_, _, modId, benchmarkData, mltag)
  if not benchmarkData then
    return
  end
  if not self.ModId then
    return
  end
  if tostring(self.ModId) ~= tostring(modId) then
    return
  end
  local Logic_UGC_DataCenter = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_datacenter)
  local MetaData = Logic_UGC_DataCenter.ModData and Logic_UGC_DataCenter.ModData[self.ModId]
  if MetaData then
    self:RefreshUI(MetaData)
  end
end

function UGC_Center_WorkDiagnosis_UIBP:OnRefreshDiagnosisData(_, _, meta)
  if not meta then
    return
  end
  if self.ModId and meta.mod_id and tostring(self.ModId) ~= tostring(meta.mod_id) then
    return
  end
  self:RefreshUI(meta)
end

function UGC_Center_WorkDiagnosis_UIBP:RequestDiagnosisData()
  if not self.ModId then
    return
  end
  local LogicUGCWorkDiagnosis = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_work_diagnosis)
  LogicUGCWorkDiagnosis:ReqDiagnosisBenchmark(self.ModId)
  local Logic_UGC_DataCenter = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_datacenter)
  local MetaData = Logic_UGC_DataCenter:ReqPubMate(self.ModId, "creation_center")
  if MetaData then
    self:RefreshUI(MetaData)
  end
end

function UGC_Center_WorkDiagnosis_UIBP:RefreshUI(meta)
  if not meta then
    return
  end
  local LogicUGCWorkDiagnosis = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_work_diagnosis)
  self.MetaData = meta
  Util_UGC.SetCoverImage(self, self.UIRoot.Image_MapBG, meta, false, true, nil, nil)
  self.UIRoot.TextBlock_MapName:SetText(meta.setting and meta.setting.name or "")
  if not meta.play_total_time or meta.play_total_time == 0 then
    self.UIRoot.TextBlock_Popularity:SetText("0")
  else
    self.UIRoot.TextBlock_Popularity:SetText(StringUtil.FormatNumATWill_KMB(meta.play_total_time / 3600, "%.1f"))
  end
  self.UIRoot.TextBlock_Visit:SetText(StringUtil.FormatNum_KMB(Util_UGC.GetModPlayCount(meta)))
  self.UIRoot.TextBlock_Like:SetText(StringUtil.FormatNum_KMB(meta.collect_cnt or 0))
  local checkComparison = LogicUGCWorkDiagnosis:GetCheckItemComparison(meta)
  local exposureCnt = LogicUGCWorkDiagnosis:GetExposureCnt(meta)
  local clickCnt = LogicUGCWorkDiagnosis:GetClickCnt(meta)
  local playCnt = LogicUGCWorkDiagnosis:GetPlayCntInWindow(meta)
  local validPlayCnt = LogicUGCWorkDiagnosis:GetValidPlayCntInWindow(meta)
  self:UpdateCheckItem(1, exposureCnt and StringUtil.FormatNum_KMB(exposureCnt) or "0", checkComparison[1], exposureCnt ~= nil)
  self:UpdateCheckItem(2, clickCnt and StringUtil.FormatNum_KMB(clickCnt) or "0", checkComparison[2], clickCnt ~= nil)
  self:UpdateCheckItem(3, playCnt and StringUtil.FormatNum_KMB(playCnt) or "0", checkComparison[3], playCnt ~= nil)
  self:UpdateCheckItem(4, validPlayCnt and StringUtil.FormatNum_KMB(validPlayCnt) or "0", checkComparison[4], validPlayCnt ~= nil)
  local churnRate = LogicUGCWorkDiagnosis:GetChurnRate(meta) * 100
  self.UIRoot.TextBlock_ChurnRate:SetText(LocUtil.LocalizeResFormat(8973143, string.format("%.2f", churnRate)))
  local deepPlayRate = LogicUGCWorkDiagnosis:GetDeepPlayRate(meta) * 100
  self.UIRoot.TextBlock_VivsitRate:SetText(LocUtil.LocalizeResFormat(8973143, string.format("%.2f", deepPlayRate)))
  local retentionRate = LogicUGCWorkDiagnosis:GetRetentionRate(meta) * 100
  self.UIRoot.TextBlock_RetentionRate:SetText(LocUtil.LocalizeResFormat(8973143, string.format("%.2f", retentionRate)))
  self.bDataReady = true
  self:_TryShowDiagResult()
end

function UGC_Center_WorkDiagnosis_UIBP:RunDiagnosis(meta)
  local LogicUGCWorkDiagnosis = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_work_diagnosis)
  local result = LogicUGCWorkDiagnosis:RunDataCenterCheck(meta)
  if not result then
    self:SetSuggestionState(0, true)
    return
  end
  local triggeredItems = result.triggeredItems
  if not triggeredItems or #triggeredItems == 0 then
    self:SetSuggestionState(0, result.bNoData)
    return
  end
  self:SetSuggestionState(2)
  self:RefreshProblemText(triggeredItems)
  self:RefreshSuggestionList(triggeredItems)
end

function UGC_Center_WorkDiagnosis_UIBP:RefreshProblemText(triggeredItems)
  local count = #triggeredItems
  local firstTitle = triggeredItems[1].Title or ""
  if count == 1 then
    self.UIRoot.TextBlock_Problem:SetText(LocUtil.LocalizeResFormat(4600214, firstTitle))
  else
    self.UIRoot.TextBlock_Problem:SetText(LocUtil.LocalizeResFormat(4600215, firstTitle, tostring(count)))
  end
end

function UGC_Center_WorkDiagnosis_UIBP:RefreshSuggestionList(triggeredItems)
  if not triggeredItems or not next(triggeredItems) then
    return
  end
  self:ClearItemAnimTimers()
  if self.LoopScrollBox_Suggestion:GetItemCount() > 0 then
    self.LoopScrollBox_Suggestion:RefreshAllItems(triggeredItems)
  else
    self.LoopScrollBox_Suggestion:SetData(triggeredItems)
    self.LoopScrollBox_Suggestion:RefreshAllItems()
  end
end

function UGC_Center_WorkDiagnosis_UIBP:OnRefreshSuggestionItem(widget, index)
  local itemData = self.LoopScrollBox_Suggestion:GetItemData(index)
  if not itemData then
    return
  end
  widget.WidgetSwitcher_BG:SetActiveWidgetIndex(itemData.Priority <= 2 and 0 or 1)
  widget.TextBlock_Optimize:SetText(LocUtil.GetLocalizeResStr(4600179))
  widget.TextBlock_Title:SetText(itemData.Title or "")
  widget.TextBlock_Content:SetText(itemData.Suggestion or "")
  self:_PlayItemAnim(widget, index)
end

function UGC_Center_WorkDiagnosis_UIBP:OnClickOptimize(widget, index)
  local itemData = self.LoopScrollBox_Suggestion:GetItemData(index)
  if not itemData then
    return
  end
  self:PlayAudio(sound_config.click_v1)
  local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
  UGCTLogReport:ReportDelay(TLogEventDefine.UGC_Click_WorkDiagnosis_Optimize_Button)
  if itemData.ID == 1 then
    UIManager.ShowUI(UIManager.UI_Config.UGC_PromotionalCard_UIBP)
  else
    if not self.MetaData then
      return
    end
    local extendedParams = {bShowOptimizeGuide = true}
    UIManager.ShowUI(UIManager.UI_Config.UGCDetailMainPanel, Config_UGC.Config_UGC_MinePubDetailTabs, self.MetaData, extendedParams)
    EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_SHOW_OPTIMIZE_GUIDE)
  end
end

function UGC_Center_WorkDiagnosis_UIBP:SetSuggestionState(state, bNoData)
  self.UIRoot.WidgetSwitcher_Suggestion:SetActiveWidgetIndex(state)
  if state == 0 then
    if bNoData then
      self.UIRoot.TextBlock_Suggestion:SetText(LocUtil.GetLocalizeResStr(4600116))
      self.UIRoot.TextBlock_Suggestion_01:SetText(LocUtil.GetLocalizeResStr(8801621))
    else
      self.UIRoot.TextBlock_Suggestion:SetText(LocUtil.GetLocalizeResStr(4600213))
      self.UIRoot.TextBlock_Suggestion_01:SetText(LocUtil.GetLocalizeResStr(4600260))
    end
  end
end

function UGC_Center_WorkDiagnosis_UIBP:InitCheckItem(index, title)
  local item = self.CheckItems[index]
  item.TextBlock_Title:SetText(title)
  item.TextBlock_Abnormality:SetText(LocUtil.GetLocalizeResStr(4600208))
end

function UGC_Center_WorkDiagnosis_UIBP:UpdateCheckItem(index, dataValue, comparison, bHasData)
  local item = self.CheckItems[index]
  item.UTRichTextBlock_Date:SetText(dataValue)
  if comparison then
    if not bHasData or comparison.bNormal == nil then
      item.SizeBoxReview:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      item.CanvasPanel_Abnormality:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    else
      local colorIndex = comparison.bNormal and 0 or 1
      item.SizeBoxReview:SetWidgetVisibility(UEnums.ESlateVisibility.Visible)
      item.TextBlock_Review:SetActiveColorIndex(colorIndex)
      item.TextBlock_Review:SetText(LocUtil.GetLocalizeResStr(comparison.bNormal and 4600258 or 4600259))
      item.CanvasPanel_Abnormality:SetWidgetVisibility(comparison.bNormal and UEnums.ESlateVisibility.Collapsed or UEnums.ESlateVisibility.Visible)
    end
  end
end

function UGC_Center_WorkDiagnosis_UIBP:_TryShowDiagResult()
  if not self.bDataReady or self.bDiagResultShown then
    return
  end
  if self.DiagDelayTimer then
    return
  end
  self.bDiagResultShown = true
  self.UIRoot:StopAnimation(self.UIRoot.Anim_Robot)
  self:PlayUserWidgetAnimation(self.UIRoot.Anim_Loop, 0, 1, 0, 1)
end

function UGC_Center_WorkDiagnosis_UIBP:OnLoopAnimFinished()
  if self.MetaData then
    self:RunDiagnosis(self.MetaData)
  end
end

function UGC_Center_WorkDiagnosis_UIBP:_PlayItemAnim(widget, index)
  widget:SetVisibility(UEnums.ESlateVisibility.Hidden)
  if not self.ItemAnimTimers then
    self.ItemAnimTimers = {}
  end
  local delay = (index - 1) * 0.5
  local timerHandle = self:AddTimer(delay, function()
    widget:SetVisibility(UEnums.ESlateVisibility.Visible)
    self:PlayWidgetAnimation(widget, widget.Anim_in, 0, 1, 0, 1)
  end)
  table.insert(self.ItemAnimTimers, timerHandle)
end

function UGC_Center_WorkDiagnosis_UIBP:ClearItemAnimTimers()
  if not self.ItemAnimTimers then
    return
  end
  for _, timerHandle in ipairs(self.ItemAnimTimers) do
    self:RemoveGameTimer(timerHandle)
  end
  self.ItemAnimTimers = nil
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
local CUGC_Center_WorkDiagnosis_UIBP = class(ui_base, nil, UGC_Center_WorkDiagnosis_UIBP)
return CUGC_Center_WorkDiagnosis_UIBP
