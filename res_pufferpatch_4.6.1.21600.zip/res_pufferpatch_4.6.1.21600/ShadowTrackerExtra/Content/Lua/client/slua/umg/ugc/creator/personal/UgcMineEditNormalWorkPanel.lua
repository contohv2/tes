-- 设置已启用自动解析化
-- TELEGRAM:@RJTOOL @BYRJ6
-- 解包层数: 0；移除诱饵行: 0；还原字符串: 0

local UI_UGC_Mine_Edit_Normal_Work = {}
local Config_UGC = require("client.slua.logic.ugc.config_ugc")
local config_ugc_season_template = require("client.slua.umg.ugc.SeasonTemplate.config_ugc_season_template")
local C_TagWidgetName = "UGC_Tag_Item"
local Share_friendCircle = 0
local tlog_report_utils = require("client.slua.config.tlog.tlog_report_utils")
local E_EditTab = {
  Tab1 = 1,
  Tab2 = 2,
  Tab3 = 3
}
local EditTabConfig = {
  [E_EditTab.Tab1] = {
    tabControl = "Tab_1",
    contentIndex = 0,
    tab1Tab2SwitcherIndex = 0,
    textID = 4600155,
    ID = 1
  },
  [E_EditTab.Tab2] = {
    tabControl = "Tab_2",
    contentIndex = 0,
    tab1Tab2SwitcherIndex = 1,
    textID = 4600156,
    ID = 2
  },
  [E_EditTab.Tab3] = {
    tabControl = "Tab_3",
    contentIndex = 1,
    textID = 4600157,
    ID = 3
  }
}
local EditTabTlogMap = {
  [E_EditTab.Tab1] = TLogEventDefine.UGC_Click_EditTab_Info,
  [E_EditTab.Tab2] = TLogEventDefine.UGC_Click_EditTab_Setting,
  [E_EditTab.Tab3] = TLogEventDefine.UGC_Click_EditTab_Publish
}
local DIAG_GUIDE_TARGET_WIDGET = {
  Title = "CanvasPanel_Name",
  Desc = "CanvasPanel_Desc",
  Tag = "CanvasPanel_Tag",
  Event = "CanvasPanel_Event",
  SpecialEdition = "Canvas_Panel_SpecialEdition",
  PubState = "CanvasPanel_PrivateBtn"
}

function UI_UGC_Mine_Edit_Normal_Work:ctor(_, slot, isFromRelate, bOpenCoAuthor)
  local LogicUgcFilterTag = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUgcFilterTag)
  LogicUgcFilterTag:SetAllTagList()
  self.nSlot = slot or 0
  self.bIsFromRelate = isFromRelate
  self.cantPublishReasonTips = nil
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  self.modInfo = LogicUGCCRUD:GetModeBySlot(self.nSlot)
  self:RefreshDelayPublishStatus()
  self:RefreshExpiredTimeStatus()
  self.bOpenCoAuthor = bOpenCoAuthor
  self.bUpdateResetLeaderboard = 0
  self.bUpdateResetVar = 0
  self.LocName = self.modInfo and self.modInfo.setting and self.modInfo.setting.name or nil
  self.LocDesc = self.modInfo and self.modInfo.setting and self.modInfo.setting.desc or nil
  self.LocTag_v2 = self.modInfo and self.modInfo.setting and self.modInfo.setting.tag_v2 or nil
  self.LocUpdateLog = self.modInfo and self.modInfo.setting and self.modInfo.setting.update_log or ""
  self.bHasOldTagsOnEnter = false
  self.use_ai_photo = self.modInfo and self.modInfo.setting and self.modInfo.setting.use_ai_photo or 0
  self.bChange = false
  self.valid_act = {}
  self.template_id = self.modInfo and self.modInfo.base and self.modInfo.base.template_id
  self.Album_theme_id = self.modInfo and self.modInfo.base and self.modInfo.base.spec_theme_id
  self.AcceptFeedback = not self.modInfo or not self.modInfo.setting or self.modInfo.setting.feedback_switch ~= 0
  self.downloader_ui = nil
  self.archive_downloader_ui = nil
  self.archiveDownloadToken = 0
  self.nSelectSaveType = nil
  self.nSelectSaveSlot = nil
  self.curEditTab = E_EditTab.Tab1
end

function UI_UGC_Mine_Edit_Normal_Work:GetOldTagGuideRecord()
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  local data = PlayerPrefsSystem.LoadFileToTable_N(PlayerPrefsSystem.ePlayerPrefsType.eUGCMineEditOldTagGuide)
  data = data or {}
  return data
end

function UI_UGC_Mine_Edit_Normal_Work:HasHandledOldTagGuide()
  local data = self:GetOldTagGuideRecord()
  return data.bHasHandledOldTagGuide == true
end

function UI_UGC_Mine_Edit_Normal_Work:MarkOldTagGuideHandled()
  log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:MarkOldTagGuideHandled")
  local data = self:GetOldTagGuideRecord()
  data.bHasHandledOldTagGuide = true
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  PlayerPrefsSystem.SaveTableToFile_N(data, PlayerPrefsSystem.ePlayerPrefsType.eUGCMineEditOldTagGuide)
end

function UI_UGC_Mine_Edit_Normal_Work:SetOldTagGuideVisible(bVisible)
  if not self.UIRoot or not self.UIRoot.CanvasPanel_LabelTips then
    return
  end
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_LabelTips, bVisible)
  if bVisible then
    self.UIRoot.TextBlock_Label:SetText(LocUtil.GetLocalizeResStr(8801503))
  end
end

function UI_UGC_Mine_Edit_Normal_Work:ShouldShowOldTagGuide()
  return self.bHasOldTagsOnEnter and not self:HasHandledOldTagGuide()
end

function UI_UGC_Mine_Edit_Normal_Work:RefreshOldTagGuideVisible()
  self:SetOldTagGuideVisible(self:ShouldShowOldTagGuide())
end

function UI_UGC_Mine_Edit_Normal_Work:HideOldTagGuideAndRecord()
  self:SetOldTagGuideVisible(false)
  if self.bHasOldTagsOnEnter and not self:HasHandledOldTagGuide() then
    self:MarkOldTagGuideHandled()
  end
end

function UI_UGC_Mine_Edit_Normal_Work:ShowDebugPanel()
  return not (Client and Client.IsDevelopment()) or gShowDebugInfo or IsEditor
end

function UI_UGC_Mine_Edit_Normal_Work:OnInitialize()
  UI_UGC_Mine_Edit_Normal_Work.__super.OnInitialize(self)
  local ReleaseItemUIClass = require("client.slua.umg.ugc.creator.center.item.UGC_Center_Release_Item_UIBP")
  self.releaseItemUI = ReleaseItemUIClass()
  self.releaseItemUI:InitWithParentWidget(self, self.UIRoot.UGC_Center_Release_Item_UIBP)
  self.ComboBox_Update = self:InitCommonComboBoxNew(self.UIRoot.ComboBox_Update)
  local LogicUGCAuthorNotice = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_author_notice)
  self.updateTypeList = LogicUGCAuthorNotice:GetUpdateTypeList()
  self.ComboBox_Update:SetData(self.updateTypeList)
  self.updateType = self.updateTypeList[1] and self.updateTypeList[1].value or 1
  self.ComboBox_Update:SelectIndex(1)
  self.coverWidgetList = self:InitScrollBox(self.UIRoot.LoopScrollGrid_Covers)
  self.UIRoot.TextBlock_RuleDesc:SetText(LocUtil.GetLocalizeResStr(64224))
  self.UIRoot.TextBlock_Rule:SetText(LocUtil.GetLocalizeResStr(64223))
  self.UIRoot.TextBlock_12:SetText(LocUtil.GetLocalizeResStr(72001))
  self.UIRoot.TextBlock_Feedback:SetText(LocUtil.GetLocalizeResStr(10120027))
  self.UIRoot.TextBlock_ShareCreateMod:SetText(LocUtil.GetLocalizeResStr(99020019))
  self.UIRoot.TextBlock_Archive:SetText(LocUtil.GetLocalizeResStr(8889366))
  self.UIRoot.TextBlock_AllowSharing:SetText(LocUtil.GetLocalizeResStr(99020020))
  self.UIRoot.TextBlock_Edit:SetText(LocUtil.GetLocalizeResStr(4600162))
  self.UIRoot.TextBlock_34:SetText(LocUtil.GetLocalizeResStr(81403))
  self.coauthorWidgetList = self:InitScrollBox(self.UIRoot.LoopScrollBox_AutherList)
  if self:ShowDebugPanel() and self.UIRoot.DevDebugPanel then
    self.UIRoot.DevDebugPanel:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    self.UIRoot.MultiLineEditableText_0:SetText(json.encode(self.modInfo))
  end
  local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
  local logic_moment = require("client.slua.logic.moment.logic_moment")
  local CanOpenMoment = logic_moment.IsCanOpenSelfMoment(false)
  self.UIRoot.CanvasPanel_ShareFriendCircle:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  if not PublishRegionMacros.IsBlueholeFamily() then
    if not CanOpenMoment then
      self.UIRoot.CanvasPanel_ShareFriendCircle:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    else
      self.UIRoot.CanvasPanel_ShareFriendCircle:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    end
  end
  local LogicUgcFilterTag = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUgcFilterTag)
  LogicUgcFilterTag:ClearFilterAllTags(2)
  LogicUgcFilterTag.SelectMainTag = nil
  local modSetting = self.modInfo and self.modInfo.setting or {}
  self.bHasOldTagsOnEnter = false
  if LobbySystem.CheckOpen(BP_ENUM_UGC_OLDTAG_FILTER) then
    self.bHasOldTagsOnEnter = LogicUgcFilterTag:CheckOldTag(modSetting.tag_v2 or {})
    if self.bHasOldTagsOnEnter then
      self:OnModifyTags(nil, nil, {}, {})
    end
  end
  if LobbySystem.CheckOpen(BP_ENUM_UGC_OLDTAG_FILTER) and not self.bHasOldTagsOnEnter and modSetting.subfeature_tag and next(modSetting.subfeature_tag) then
    self:OnModifyTags(nil, nil, modSetting.tag_v2 or {}, {})
  end
  local bIsChange, NewTags, AutoTagChangeList = LogicUgcFilterTag:CheckAutoTagChange(modSetting.tag_v2 or {}, modSetting.features_2_tags or {})
  if bIsChange then
    self:OnModifyTags(nil, nil, NewTags, nil)
    UIManager.ShowUI(UIManager.UI_Config.UGC_LabelChange_Popup_UIBP, AutoTagChangeList)
  end
  local Logic_UGC_Season_Template = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_season_template)
  local logic_ugc_album_theme = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_album_theme)
  self:OnAlbumDataAndSelectAlbumID()
  if not self:IsUpdateMod() then
    self.CurSelectSeasonActID = Logic_UGC_Season_Template.curSelectActivityID
  end
  self.CurSelectAlbumThemeID = self.Album_theme_id or logic_ugc_album_theme.SelectAlbumThemeID
  if not self.CurSelectAlbumThemeID or self:CheckPlayerAlbumIsBan(DataMgr.roleData.uid, self.CurSelectAlbumThemeID) then
    self.UIRoot.WidgetSwitcher_SpecialEdition:SetActiveWidgetIndex(0)
  else
    self:OnSelectAlbumUI(nil, nil, self.CurSelectAlbumThemeID)
  end
  self:UpdateAICoverUI()
  self.UIRoot.TextBlock_AICover:SetText(LocUtil.GetLocalizeResStr(1050097))
  self.UIRoot.TextBlock_28:SetText(LocUtil.GetLocalizeResStr(81403))
  self:InitOriginModInfo()
  local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
  if PublishRegionMacros.IsBlueholeFamily() then
    self:SetWidgetVisible(self.UIRoot.Canvas_Panel_SpecialEdition, false)
  end
end

function UI_UGC_Mine_Edit_Normal_Work:RegistEvents()
  UI_UGC_Mine_Edit_Normal_Work.__super.RegistEvents(self)
  self.ComboBox_Update:SetSelectOptionCallback(self.OnSelectUpdateType, self)
  self.ComboBox_Update:SetRefreshOptionCallback(self.OnRefreshUpdateTypeItem, self)
  self.coverWidgetList:SetRefreshItemCallback(self.OnRefreshCover, self)
  self.coverWidgetList:AddItemWidgetChildEvent("Button_AddCover", "OnClicked", self.OnClickAddCover, self)
  self.coverWidgetList:AddItemWidgetChildEvent("Button_DeleteCover", "OnClicked", self.OnClickDeleteCover, self)
  self.coverWidgetList:AddItemWidgetChildEvent("Button_Edit02", "OnClicked", self.OnClickOpenAIImageUI, self)
  self.coauthorWidgetList:SetRefreshItemCallback(self.OnRefreshAuthor, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Close2, self.OnClickClose, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Close3, self.OnClickClose, self)
  self:AddOnClickedEventByControl(self.UIRoot.Tab_1.Button_Tab, self.OnClickEditTab, self, E_EditTab.Tab1)
  self:AddOnClickedEventByControl(self.UIRoot.Tab_2.Button_Tab, self.OnClickEditTab, self, E_EditTab.Tab2)
  self:AddOnClickedEventByControl(self.UIRoot.Tab_3.Button_Tab, self.OnClickEditTab, self, E_EditTab.Tab3)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Public, self.OnClickGotoPublish, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Preview, self.OnClickPreview, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Edit, self.OnClickEdit, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Duplicate, self.OnClickDuplicate, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Delete, self.OnClickDelete, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_EditTag, self.OnClickEditTag, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Archive, self.OnClickArchive, self)
  self:AddOnClickedEventByControl(self.UIRoot.UGC_RelationMod_Item.Button_Show, self.OnClickJumpMod, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_BecomeAuthor, self.OnClickBecomeAuthor, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_ViewMore, self.OnClickViewMore, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_ShareCreateMod, self.OnClickShareCreateMod, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_ShareFriendCircle, self.OnNotifyPublish, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Help, self.OnClickHelp, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_2, self.OnClickPrivateRule, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Rule, self.OnClickRule, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_CoAuther, self.OnClickCoAuthor, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_VotedTag, self.OnClickButtonVotedTag, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_PCAdvancedEditor, self.OnClickProEditor, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_AITips, self.OnClickGotoProEditor, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_GoToPCEditor, self.OnClickGotoProEditor, self)
  self:AddControlEventByControl(self.UIRoot.EditableText_Name, "OnTextCommitted", self.OnChangeName, self)
  self:AddControlEventByControl(self.UIRoot.EditableText_Name, "OnTextChanged", self.OnNameTextChanged, self)
  self:AddControlEventByControl(self.UIRoot.MultiLineEditableText_Desc, "OnTextCommitted", self.OnChangeDesc, self)
  self:AddControlEventByControl(self.UIRoot.MultiLineEditableText_Desc, "OnTextChanged", self.OnDescTextChanged, self)
  self:AddControlEventByControl(self.UIRoot.MultiLineEditableText_Update, "OnTextCommitted", self.OnChangeUpdate, self)
  self:AddControlEventByControl(self.UIRoot.MultiLineEditableText_Update, "OnTextChanged", self.OnUpdateTextChanged, self)
  if self.UIRoot.Button_View then
    self:AddOnClickedEventByControl(self.UIRoot.Button_View, self.OnClickOriginModReport, self)
  end
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_MODIFY_MOD, self.OnModifyMod, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_DUPLICATE_MOD, self.OnDuplicateMod, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_DELETE_MOD, self.OnDeleteMod, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_MODIFY_TAGS, self.OnModifyTags, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_UPDATE_AUTHOR, self.OnUpdateAuthor, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_ADDCOVER, self.OnSelectPhoto, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_EDITMATCH_SELECTCHANGE, self.OnEditMatchInfoChange, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_PUBLISH_MOD, self.OnPublishMod, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_GET_MOD_BATCH, self.OnGetModBatchRsp, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_COAUTHOR_SELECTED_UPDATE, self.OnCoauthorSelected, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_SHOW_GUEST, self.OnJumpGuestPanel, self)
  self:AddCommonEvent(EVENTTYPE_MOMENT, EVENTID_MOMENT_GET_WOWSQUARE_MESSAGES, self.OnSendSquare, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_SELECT_SEASONACTID, self.OnSelectSeasonAct, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_ALBUM_THEME_REFRESH, self.OnRefreshAlbumUI, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_SELECT_ALBUM_THEME_ID, self.OnSelectAlbumUI, self)
  self:AddOnCheckStateChangedEventByControl(self.UIRoot.ResetVarCheckBox, self.OnResetVarCheckStateChange, self)
  self:AddOnCheckStateChangedEventByControl(self.UIRoot.ResetLeaderboardCheckBox, self.OnResetLeaderboardCheckStateChange, self)
  self:AddOnCheckStateChangedEventByControl(self.UIRoot.CheckBox_Feedback, self.OnResetPlayerAcceptFeedback, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Event, self.OnClickEvent, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_EventName, self.OnClickEventName, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_To_Event, self.OnClickEventTips, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_GETSEASON_CFG, self.OnGetSeasonCfg, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_WOW_PASS_INFO_UPDATE, self.OnWowPassInfoUpdate, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Check, self.OnClickAICoverCheck, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_AIQues, self.OnClickAICoverQues, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_SpecialEdition, self.OnClickAlbumTheme, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_SpecialEditionName, self.OnClickAlbumTheme, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_PUBCD_REMAIN_CHANGED, self.OnRefreshPubCD, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_EDIT_SHOT_CRASH_SAVED, self.OnEditShotCrashSaved, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_GET_SAVE_SLOT_FULL_META_RSP, self.OnGetSaveSlotFullMetaRsp, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Pub, self.OnClickPub, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Private, self.OnClickPrivate, self)
  self:AddCommonEvent(EVENTTYPE_PUFFER, EVENTID_UGC_CLICK_DOWNLOAD, self.OnClickDownload, self)
end

function UI_UGC_Mine_Edit_Normal_Work:OnPostInitialize()
  UI_UGC_Mine_Edit_Normal_Work.__super.OnPostInitialize(self)
  if not self.modInfo then
    log_warning(bWriteLog and "[edward] UI_UGC_Mine_Edit_Normal_Work:OnPostInitialize, no modeInfo, slot = " .. tostring(self.nSlot))
    self:CloseSelf()
    return
  end
  self:RefreshExpiredTimeStatus()
  self:InitInfo()
  self:InitTags(C_TagWidgetName)
  self:InitCovers()
  self:CheckCanPublish()
  self:UpdateAuthorInfo()
  self:CheckShowDownloader()
  self:InitCoAuthorList()
  self:InitUpdateOptionPanel()
  self:RefreshOldTagGuideVisible()
  self:PlayUserWidgetAnimation(self.UIRoot.Auto_Fadein, 0, 1, 0, 1)
  local logic_ugc_newbie_guide = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_newbie_guide)
  logic_ugc_newbie_guide:OnUIOpened(self)
  local Logic_UGC_SeasonTemplate = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_season_template)
  Logic_UGC_SeasonTemplate:ReqSeasonActivityData()
  local logic_ugc_album_theme = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_album_theme)
  logic_ugc_album_theme:send_ugc_get_all_spec_theme_list_req()
  self:UpdateDuplicate()
  self:UpdatePubState()
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  LogicUGCCRUD:ReqGetEditShotSimpleMetaList(self.nSlot)
  self:RefreshArchiveRedDot()
  self:InitEditTabText()
  self:SwitchEditTab(self.curEditTab)
end

function UI_UGC_Mine_Edit_Normal_Work:OnShow()
  self.UIRoot.Canvas_Panel_AITips:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  self.UIRoot.Button_PCAdvancedEditor:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  local Util_UGC = require("client.slua.logic.ugc.util_ugc")
  if Util_UGC and Util_UGC.IsEditorProMap(self.modInfo) then
    self.UIRoot.CanvasPanel_PCAdvancedEditor:SetWidgetVisibility(UEnums.ESlateVisibility.Visible)
    self.UIRoot.TextBlock_21:SetText(LocUtil.LocalizeResFormat(4600158))
    self.UIRoot.TextBlock_22:SetText(LocUtil.LocalizeResFormat(4600159))
  else
    self.UIRoot.CanvasPanel_PCAdvancedEditor:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
  self:UpdateOriginModInfo()
end

function UI_UGC_Mine_Edit_Normal_Work:OnClose()
  self:CancelArchiveDownloadIntent()
  self.archive_downloader_ui = nil
  self.downloader_ui = nil
  local LogicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
  if LogicUGC.modJumpCacheData then
    if type(LogicUGC.modJumpCacheData) == "table" then
      if UIManager.IsUIShow(UIManager.UI_Config.UGCDetailMainPanel) then
        UIManager.CloseUI(UIManager.UI_Config.UGCDetailMainPanel)
      end
      UIManager.ShowUI(UIManager.UI_Config.UGCDetailMainPanel, Config_UGC.Config_UGC_MinePubDetailTabs, LogicUGC.modJumpCacheData)
    end
    LogicUGC:CacheModJumpData()
  end
  local LogicUgcFilterTag = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUgcFilterTag)
  LogicUgcFilterTag:ClearFilterAllTags(2)
  LogicUgcFilterTag.SelectMainTag = nil
  self:CloseDiagnosisGuide()
  self:RemoveAllGameTimer()
  local Logic_UGC_SeasonTemplate = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_season_template)
  Logic_UGC_SeasonTemplate:ResetSelectActivityID()
  local logic_ugc_album_theme = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_album_theme)
  logic_ugc_album_theme:ResetSelectAlbumThemeID()
  EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_OPEN_MODDETAIL, false)
end

function UI_UGC_Mine_Edit_Normal_Work:CheckRequiredFields()
  local unfillCount = 0
  local reasonTips
  local name = self.LocName or ""
  if name == "" then
    reasonTips = 4600263
    unfillCount = unfillCount + 1
  end
  local desc = self.LocDesc or ""
  if desc == "" then
    reasonTips = 4600264
    unfillCount = unfillCount + 1
  elseif string.sub(desc, 1, 1) == " " then
    return false, 511012
  end
  if self:IsUpdateMod() then
    local update_log = self.UIRoot.MultiLineEditableText_Update:GetText() or ""
    if update_log == "" then
      reasonTips = 4600265
      unfillCount = unfillCount + 1
    end
  end
  local tagList = self.LocTag_v2
  if not tagList or #tagList <= 0 then
    reasonTips = 4600266
    unfillCount = unfillCount + 1
  end
  if reasonTips then
    if 1 < unfillCount then
      reasonTips = 49386
    end
    return false, reasonTips
  end
  return true, nil
end

function UI_UGC_Mine_Edit_Normal_Work:CheckCanPublish()
  self.cantPublishReasonTips = nil
  print(bWriteLog and "[edward] UI_UGC_Mine_Edit_Normal_Work:CheckCanPublish, TestTagData = ", Config_UGC.TestTagData)
  local LogicUGCAuthor = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor)
  if LogicUGCAuthor:IsBanned(false) then
    self.cantPublishReasonTips = 511041
    return
  end
  if Config_UGC.TestTagData == 2 then
    self:SetPublishBtnShowState(true)
    return
  end
  if self.bDelayPublish and self.DelayPublishTimeStamp and type(self.DelayPublishTimeStamp) == "number" then
    local formattedDate = os.date("%Y-%m-%d %H:%M:%S", self.DelayPublishTimeStamp)
    self.cantPublishReasonTips = LocUtil.LocalizeResFormat(8600013, formattedDate)
    self:SetPublishBtnShowState(false)
    return
  end
  local bPassed, reasonTips = self:CheckRequiredFields()
  if not bPassed then
    self.cantPublishReasonTips = reasonTips
    self:SetPublishBtnShowState(false)
    return
  end
  if self.modInfo.base.verify_number > 0 then
    self.cantPublishReasonTips = 49390
    self:SetPublishBtnShowState(false)
    return
  end
  if self.modInfo.setting.invalid_res_ref == true then
    self.cantPublishReasonTips = 8880484
    self:SetPublishBtnShowState(false)
    return
  end
  self:SetPublishBtnShowState(true)
end

function UI_UGC_Mine_Edit_Normal_Work:SetPublishBtnShowState(isEnable)
  if self.releaseItemUI then
    self.releaseItemUI:SetUpdateButtonGrayState(isEnable)
  end
end

function UI_UGC_Mine_Edit_Normal_Work:UpdateAuthorInfo()
  local LogicUGCAuthor = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor)
  self.IsAuthor = LogicUGCAuthor:NewCheckPlayerIsAuthor(DataMgr.roleData.uid)
  local LogicUGCCenter = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_center)
  local IsShowLv6Guide = LogicUGCCenter:GetShowLv6Guide()
  log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:UpdateAuthorInfo IsShowLv6Guide = " .. tostring(IsShowLv6Guide))
  if self.IsAuthor or IsShowLv6Guide then
    self.UIRoot.WidgetSwitcher_Author:SetActiveWidgetIndex(0)
  else
    self.UIRoot.WidgetSwitcher_Author:SetActiveWidgetIndex(1)
  end
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickEditTab(tabIndex)
  self:PlayAudio(sound_config.tab_v1)
  if self.curEditTab == tabIndex then
    return
  end
  self:SwitchEditTab(tabIndex)
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickClose()
  self:PlayAudio(sound_config.click_v1)
  self:CloseSelf()
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickPreview()
  self:PlayAudio(sound_config.click_v1)
  local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
  UGCTLogReport:ReportDelay(TLogEventDefine.UGC_MOD_Preview_ButtonClick)
  UIManager.ShowUI(UIManager.UI_Config.UGC_Center_Preview_Popup_UIBP, self.modInfo)
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickPublish(bForceNewRelease)
  self:PlayAudio(sound_config.click_v1)
  local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
  UGCTLogReport:ReportDelay(TLogEventDefine.UGC_MOD_Publish_ButtonClick)
  local Util_UGC = require("client.slua.logic.ugc.util_ugc")
  if Util_UGC.NeedShowUpdateTips(self.modInfo) then
    return
  end
  if self.cantPublishReasonTips then
    ShowNotice(self.cantPublishReasonTips)
    return
  end
  if Share_friendCircle == 1 then
    local logic_moment_proto = require("client.slua.logic.moment.logic_moment_proto")
    EventSystem:postEvent(EVENTTYPE_MOMENT, EVENTID_MOMENT_GET_WOWSQUARE_MESSAGES, true)
  else
    EventSystem:postEvent(EVENTTYPE_MOMENT, EVENTID_MOMENT_GET_WOWSQUARE_MESSAGES, nil)
  end
  if not bForceNewRelease and self:IsUpdateMod() then
    self:ShowTrailTips()
  else
    self:OnClickNewRelease()
  end
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickNewRelease()
  if self.modInfo.base.main_tag_check_proba and self.modInfo.base.main_tag_check_proba < 0.3 then
    local title = LocUtil.GetLocalizeResStr(101001)
    local content = LocUtil.GetLocalizeResStr(8800074)
    local okTxt = LocUtil.GetLocalizeResStr(8800075)
    local cancelTxt = LocUtil.GetLocalizeResStr(8800076)
    local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
    CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_TWO, title, content, function()
      self:PublishMod(self.is_wow_moment)
    end, nil, okTxt, cancelTxt)
  else
    self:PublishMod(self.is_wow_moment)
  end
end

function UI_UGC_Mine_Edit_Normal_Work:PublishMod(is_wow_moment)
  print(bWriteLog and "[UGC] UI_UGC_Mine_Edit_Normal_Work:PublishMod")
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  local title = LocUtil.GetLocalizeResStr(101001)
  local extraData = self:GetCommonMsgBoxExtraData()
  local publishFunc = function()
    local Util_UGC = require("client.slua.logic.ugc.util_ugc")
    local bTrailPlayedOk = Util_UGC.CheckIsTrailMod(self.modInfo) and Util_UGC.GetEditModHasPlayedCompleted(self.modInfo) == 1
    local contentId = bTrailPlayedOk and 8501073 or 70006
    CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_FOUR, title, LocUtil.GetLocalizeStrConcatenation(contentId), function(isCheck)
      if isCheck then
        self.CurSelectSeasonActID = self.act and self.act.activity_info and self.act.activity_info.game_manage_id or nil
      end
      local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
      local bPrivate = LogicUGCCRUD:CheckEditModIsPrivate(self.modInfo)
      local LogicUGCAuthor = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor)
      if LogicUGCAuthor:CheckPlayerAlbumIsBan(DataMgr.roleData.uid, self.CurSelectAlbumThemeID) then
        self.CurSelectAlbumThemeID = nil
      end
      local ext_info = {
        activity_event_id = self.CurSelectSeasonActID,
        spec_theme_id = self.CurSelectAlbumThemeID,
        feedback_enable = self.AcceptFeedback,
        diag_score = self.diagScore
      }
      LogicUGCCRUD:ReqPublishMod(self.nSlot, nil, is_wow_moment, ext_info, bPrivate)
      local str = string.format("uid=%d&activity_event_id=%s", tonumber(DataMgr.roleData.uid), tostring(ext_info.activity_event_id))
      local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
      UGCTLogReport:ReportDelay(TLogEventDefine.UGC_MOD_Publish_Release_ButtonClick, nil, str)
      EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_OPEN_MODDETAIL, false)
    end, function()
      self:CloseSelf()
    end, nil, nil, extraData)
  end
  local Util_UGC = require("client.slua.logic.ugc.util_ugc")
  if not Util_UGC.CheckIsTrailMod(self.modInfo) then
    log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnClickPublish not trail")
    local content = LocUtil.GetLocalizeResStr(70006)
    CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_FOUR, title, content, publishFunc)
  elseif Util_UGC.GetEditModHasPlayedCompleted(self.modInfo) == 1 then
    local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
    UGCTLogReport:ReportDelay(TLogEventDefine.UGC_NewPub_HasPlayedCompleted)
    publishFunc()
  else
    self:ShowTrailModPubMsgBox(publishFunc, 1)
  end
end

function UI_UGC_Mine_Edit_Normal_Work:GetCommonMsgBoxExtraData()
  local show_ugc_season_checkbox = true
  if self.CurSelectSeasonActID then
    if self:IsUpdateMod() then
      local valid = self:GetCreationPeriodSeasonCfg(true)
      local act = valid[self.CurSelectSeasonActID]
      if act then
        show_ugc_season_checkbox = false
      end
    else
      show_ugc_season_checkbox = false
    end
  end
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local bPrivate = LogicUGCCRUD:CheckEditModIsPrivate(self.modInfo)
  if bPrivate then
    show_ugc_season_checkbox = false
  end
  local extraData = {
    showUIKey = "com_msg_small_box_slua"
  }
  if show_ugc_season_checkbox then
    local Logic_UGC_SeasonTemplate = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_season_template)
    self.act = Logic_UGC_SeasonTemplate:GetEligibleAct(self.valid_act, self.modInfo)
    if self.act then
      extraData.isShowCheckBox = true
      extraData.checkBoxText = LocUtil.LocalizeResFormat(1050195, self.act.title or "")
      extraData.isUGCSeasonCheckBox = true
      extraData.checkBoxTipsText = LocUtil.LocalizeResFormat(527009, self.act.activity_info and self.act.activity_info.bonus_amount or 0)
      
      function extraData.clickUGCSeasonCallback()
        local act_id = self.act.activity_info and self.act.activity_info.game_manage_id or 0
        local url = "game://?module=" .. BP_ENUM_MODULE_UGC_SEASON_TEMPLATE .. "&id=" .. act_id
        GlobalData.JumpUrl(url)
      end
    end
  end
  return extraData
end

function UI_UGC_Mine_Edit_Normal_Work:ShowTrailTips()
  local LogicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
  local modInfo = LogicUGC:GetModByAllCache(self.modInfo.base.mod_id_rela)
  if modInfo then
    self:OnClickPublishConfirm()
    return
  end
end

function UI_UGC_Mine_Edit_Normal_Work:OnSelectUpdateType(widget, data)
  self:PlayAudio(sound_config.click_v1)
  self.updateType = data and data.value or 1
  local updateTypeTLogMap = {
    [1] = TLogEventDefine.UGC_Click_UpdateType_BugFix,
    [2] = TLogEventDefine.UGC_Click_UpdateType_NewPlay,
    [3] = TLogEventDefine.UGC_Click_UpdateType_NewLevel,
    [4] = TLogEventDefine.UGC_Click_UpdateType_NewBoss,
    [5] = TLogEventDefine.UGC_Click_UpdateType_LimitedEvent,
    [6] = TLogEventDefine.UGC_Click_UpdateType_ExperienceOptimize,
    [7] = TLogEventDefine.UGC_Click_UpdateType_Other
  }
  local tlogId = updateTypeTLogMap[self.updateType]
  if tlogId then
    local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
    UGCTLogReport:ReportDelay(tlogId)
  end
end

function UI_UGC_Mine_Edit_Normal_Work:OnRefreshUpdateTypeItem(widget, data, index, selectIndex)
  if data then
    widget.TextBlock_ItemName:SetText(data.text or "")
  end
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickPublishConfirm()
  local updateLog = self.UIRoot.MultiLineEditableText_Update:GetText()
  if updateLog == "" then
    ShowNotice(70085)
    return
  end
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  local updateFunc = function()
    local extraData1 = self:GetCommonMsgBoxExtraData()
    local title1 = LocUtil.GetLocalizeResStr(101001)
    local content = LocUtil.GetLocalizeResStr(8600049)
    if self:IsQuickAuditMod() then
      content = LocUtil.GetLocalizeResStr(655730)
    end
    CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_FOUR, title1, content, function(isCheck)
      if isCheck then
        self.CurSelectSeasonActID = self.act and self.act.activity_info and self.act.activity_info.game_manage_id or nil
      end
      EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_OPEN_MODDETAIL, false)
      if self.CurSelectSeasonActID then
        ShowNotice(1050285)
      else
        local LogicUGCAuthor = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor)
        if LogicUGCAuthor:CheckPlayerAlbumIsBan(DataMgr.roleData.uid, self.CurSelectAlbumThemeID) then
          self.CurSelectAlbumThemeID = nil
        end
        local bPrivate = LogicUGCCRUD:CheckEditModIsPrivate(self.modInfo)
        if bPrivate then
          self.CurSelectSeasonActID = nil
          self.CurSelectAlbumThemeID = nil
        end
        local ext_info = {
          activity_event_id = self.CurSelectSeasonActID,
          spec_theme_id = self.CurSelectAlbumThemeID,
          feedback_enable = self.AcceptFeedback,
          diag_score = self.diagScore
        }
        LogicUGCCRUD:ReqPublishMod(self.nSlot, nil, self.is_wow_moment, ext_info, bPrivate)
        local str = string.format("uid=%d&activity_event_id=%s", tonumber(DataMgr.roleData.uid), tostring(ext_info.activity_event_id))
        local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
        UGCTLogReport:ReportDelay(TLogEventDefine.UGC_MOD_Publish_Release_ButtonClick, nil, str)
      end
    end, function(isCheck)
      if isCheck then
        self.CurSelectSeasonActID = self.act and self.act.activity_info and self.act.activity_info.game_manage_id or nil
      end
      local LogicUGCAuthor = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor)
      if LogicUGCAuthor:CheckPlayerAlbumIsBan(DataMgr.roleData.uid, self.CurSelectAlbumThemeID) then
        self.CurSelectAlbumThemeID = nil
      end
      local ext_info = {
        activity_event_id = self.CurSelectSeasonActID,
        spec_theme_id = self.CurSelectAlbumThemeID,
        feedback_enable = self.AcceptFeedback,
        diag_score = self.diagScore,
        update_type = self.updateType
      }
      local str = string.format("uid=%d&activity_event_id=%s", tonumber(DataMgr.roleData.uid), tostring(ext_info.activity_event_id))
      local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
      UGCTLogReport:ReportDelay(TLogEventDefine.UGC_MOD_Update_Release_ButtonClick, nil, str)
      local relateModID = self.modInfo.base.mod_id_rela
      local LogicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
      local relateModInfo = LogicUGC:GetModByAllCache(relateModID)
      local oldName = relateModInfo.pub_mod_meta.setting.name
      local newName = self.modInfo.setting.name or ""
      local bPrivate = LogicUGCCRUD:CheckEditModIsPrivate(self.modInfo)
      if newName == oldName then
        LogicUGCCRUD:ReqUpdateMod(self.nSlot, nil, updateLog, self.bUpdateResetLeaderboard, self.bUpdateResetVar, self.is_wow_moment, ext_info, bPrivate)
      else
        local title = LocUtil.GetLocalizeResStr(101001)
        local extraData = {
          isShowCheckBox = true,
          checkBoxText = LocUtil.GetLocalizeResStr(70083)
        }
        local NameFunc = function(bCheck)
          if bCheck then
            LogicUGCCRUD:ReqUpdateMod(self.nSlot, oldName, updateLog, self.bUpdateResetLeaderboard, self.bUpdateResetVar, self.is_wow_moment, ext_info, bPrivate)
          else
            LogicUGCCRUD:ReqUpdateMod(self.nSlot, nil, updateLog, self.bUpdateResetLeaderboard, self.bUpdateResetVar, self.is_wow_moment, ext_info, bPrivate)
          end
        end
        local Util_UGC = require("client.slua.logic.ugc.util_ugc")
        local bTrailPlayedOk = Util_UGC.CheckIsTrailMod(self.modInfo) and Util_UGC.GetEditModHasPlayedCompleted(self.modInfo) == 1
        local content1Id = bTrailPlayedOk and 8501075 or 70082
        local content1 = LocUtil.LocalizeFormatConcatenation(content1Id, oldName)
        CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_FOUR, title, content1, NameFunc, nil, nil, nil, extraData)
      end
    end, LocUtil.GetLocalizeResStr(8600026), LocUtil.GetLocalizeResStr(8600027), extraData1)
  end
  local Util_UGC = require("client.slua.logic.ugc.util_ugc")
  local isTrailMod = Util_UGC.CheckIsTrailMod(self.modInfo)
  if isTrailMod and Util_UGC.GetEditModHasPlayedCompleted(self.modInfo) == 1 then
    local mod_id = self.modInfo.base.mod_id or 0
    local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
    UGCTLogReport:ReportDelay(TLogEventDefine.UGC_Update_HasPlayedCompleted, mod_id)
    updateFunc()
  elseif isTrailMod then
    self:ShowTrailModPubMsgBox(updateFunc, 2)
  else
    updateFunc()
  end
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickEdit()
  self:PlayAudio(sound_config.click_v1)
  local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
  UGCTLogReport:ReportDelay(TLogEventDefine.UGC_MOD_Editor_ButtonClick)
  local LogicUGCAuthor = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor)
  if LogicUGCAuthor:IsBanned(true) then
    return
  end
  log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnClickEdit")
  local LoadingSystem = require("client.slua.logic.loading.logic_loading")
  if LoadingSystem.IsShowing() then
    log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnClickEditt LoadingSystem IsShowing")
    return
  end
  local Util_UGC = require("client.slua.logic.ugc.util_ugc")
  if Util_UGC.NeedShowUpdateTips(self.modInfo) then
    return
  end
  self:CancelArchiveDownloadIntent(true)
  local func = function(bOk)
    if not bOk then
      return
    end
    local LogicUGCMatch = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch)
    if LogicUGCMatch.bUseDirectEdit then
      self:SingleEditFunc(true)
    else
      LogicUGCMatch:ReqEditModMatch(self.nSlot)
    end
  end
  if not PufferDownloader.CheckAllMapPak(nil, func) then
    return
  end
  func(true)
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickArchive()
  self:PlayAudio(sound_config.click_v1)
  log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnClickArchive nSlot = " .. tostring(self.nSlot))
  local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
  UGCTLogReport:ReportDelay(TLogEventDefine.UGC_MOD_Archive_ButtonClick)
  local LogicUGCAuthor = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor)
  if LogicUGCAuthor:IsBanned(true) then
    return
  end
  local LogicUGCMultiLevel = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_ugc_multi_level)
  if LogicUGCMultiLevel and LogicUGCMultiLevel:IsMultiLevelByModInfo(self.modInfo) then
    log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnClickArchive multi level mod not support archive")
    ShowNotice(8889406)
    return
  end
  local LogicUGCMultiLevel = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_ugc_multi_level)
  if LogicUGCMultiLevel and LogicUGCMultiLevel:IsMultiLevelByModInfo(self.modInfo) then
    log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnClickArchive multi level mod not support archive")
    ShowNotice(8889406)
    return
  end
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local saveSlotList = LogicUGCCRUD:GetSaveSlotList(self.nSlot)
  local resCheckFunc = function(save_type, save_slot)
    return self:CheckResAndTryDownload(save_type, save_slot)
  end
  UIManager.ShowUI(UIManager.UI_Config.UGC_Lobby_Detail_Archive_Popup_UIBP, self.nSlot, saveSlotList, resCheckFunc)
  LogicUGCCRUD:ClearCrashSaved(self.nSlot)
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickDuplicate()
  self:PlayAudio(sound_config.click_v1)
  local LogicUGCAuthor = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor)
  if LogicUGCAuthor:IsBanned(true) then
    return
  end
  local Util_UGC = require("client.slua.logic.ugc.util_ugc")
  if Util_UGC.NeedShowUpdateTips(self.modInfo) then
    return
  end
  if LobbySystem.isInMatch then
    ShowNotice(110017)
    return
  end
  UIManager.ShowUI(UIManager.UI_Config.ugc_duplicate_mod, false, self.modInfo)
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickDelete()
  self:PlayAudio(sound_config.click_v1)
  local LogicUGCAuthor = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor)
  if LogicUGCAuthor:IsBanned(true) then
    return
  end
  local title = LocUtil.GetLocalizeResStr(101001)
  local content = LocUtil.GetLocalizeResStr(70007)
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_TWO, title, content, function()
    local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
    LogicUGCCRUD:ReqDeleteMod(self.nSlot)
    self:CloseSelf()
  end)
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickEditTag()
  self:PlayAudio(sound_config.click_v1)
  self:HideOldTagGuideAndRecord()
  local LogicUGCAuthor = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor)
  if LogicUGCAuthor:IsBanned(true) then
    return
  end
  if not self.modInfo then
    log_error(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnClickEditTag not modInfo")
    return
  end
  local LogicUgcFilterTag = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUgcFilterTag)
  LogicUgcFilterTag:ClearFilterAllTags(1)
  LogicUgcFilterTag:ClearFilterAllTags(2)
  UIManager.ShowUI(UIManager.UI_Config.UGC_NewSearchFilter_UIBP, Config_UGC.Config_Open_Filter.OpenFilter_LabelingFilter_Self or 2, self.modInfo.setting.tag_v2, nil, self.modInfo.setting.features_2_tags)
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickJumpMod()
  self:PlayAudio(sound_config.click_v1)
  if not (self.modInfo and self.modInfo.base) or not self.modInfo.base.mod_id_rela then
    log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnClickJumpMod no mod_id_rela")
    return
  end
  local LogicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
  local relatedModInfo = LogicUGC:GetModByAllCache(self.modInfo.base.mod_id_rela)
  if not relatedModInfo or not relatedModInfo.pub_mod_meta then
    log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnClickJumpMod no relatedModInfo")
    return
  end
  self:CloseSelf()
  LogicUGC:CacheModJumpData(self.nSlot)
  local modInfo = relatedModInfo.pub_mod_meta
  UIManager.ShowUI(UIManager.UI_Config.UGCDetailMainPanel, Config_UGC.Config_UGC_MinePubDetailTabs, modInfo)
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickBecomeAuthor()
  self:PlayAudio(sound_config.click_v1)
  local LogicUGCCommunity = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCommunityManager)
  LogicUGCCommunity:JumpToAuthorCertification()
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickViewMore()
  self:PlayAudio(sound_config.click_v1)
  local reason = self.modInfo.base.state_reason
  if reason <= 0 then
    return
  end
  local reasonStr = ""
  local data = Config_UGC.GetModReasonConfigByID(reason)
  if data ~= nil then
    reasonStr = data.Desc
  end
  local title = LocUtil.LocalizeResFormat(70097, self.modInfo.setting.name or "")
  local content = LocUtil.LocalizeResFormat(70098, self.modInfo.setting.name or "", reasonStr)
  local extraData = {
    showUIKey = "ugc_mine_edit_reason_detail",
    showSlotId = nil
  }
  log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnClickViewMore verify_number = " .. self.modInfo.base.verify_number)
  if self.modInfo.base.verify_number == 1 then
    extraData.showSlotId = self.nSlot
    extraData.updateType = self.updateType
  end
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_FOUR, title, content, nil, nil, nil, nil, extraData)
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickShareCreateMod()
  self:PlayAudio(sound_config.click_v1)
  if self:IsHasPlanphAsset() then
    ShowNotice(99010151)
    return
  end
  local LogicUGCAuthor = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor)
  if LogicUGCAuthor:IsBanned(true) then
    return
  end
  local state = 1
  if self.modInfo.setting.share_switch and self.modInfo.setting.share_switch == 1 then
    state = 0
  end
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local modifyMeta = LogicUGCCRUD:NewModifyMeta()
  modifyMeta.share_switch = state
  LogicUGCCRUD:ReqModifyModMeta(self.nSlot, modifyMeta)
end

function UI_UGC_Mine_Edit_Normal_Work:OnNotifyPublish()
  self:PlayAudio(sound_config.click_v1)
  local state = Share_friendCircle == 1 and 0 or 1
  if state == 1 then
    self.UIRoot.WidgetSwitcher_ShareFriendCircle:SetActiveWidgetIndex(1)
  else
    self.UIRoot.WidgetSwitcher_ShareFriendCircle:SetActiveWidgetIndex(0)
  end
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local modifyMeta = LogicUGCCRUD:NewModifyMeta()
  Share_friendCircle = state
end

function UI_UGC_Mine_Edit_Normal_Work:OnResetPlayerAcceptFeedback(isCheck)
  self:PlayAudio(sound_config.click_v1)
  self.AcceptFeedback = isCheck
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local modifyMeta = LogicUGCCRUD:NewModifyMeta()
  modifyMeta.feedback_switch = self.AcceptFeedback and 1 or 0
  LogicUGCCRUD:ReqModifyModMeta(self.nSlot, modifyMeta)
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickHelp()
  self:PlayAudio(sound_config.click_v1)
  local FirstTrialTimeCfg = CDataTable.GetTableData("UGCParamConfig", "FirstTrialTime")
  local FirstTrialTime = FirstTrialTimeCfg and FirstTrialTimeCfg.Value
  local ReviewTimeCfg = CDataTable.GetTableData("UGCParamConfig", "ReviewTime")
  local ReviewTime = ReviewTimeCfg and ReviewTimeCfg.Value
  local title = LocUtil.GetLocalizeResStr(49496)
  local content = LocUtil.LocalizeFormatConcatenation(512220, FirstTrialTime, ReviewTime)
  UIManager.ShowUI(UIManager.UI_Config.HelpTip, 0, title, content)
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickRule()
  self:PlayAudio(sound_config.click_v1)
  local title = LocUtil.GetLocalizeResStr(64222)
  local content = LocUtil.LocalizeFormatConcatenation(64221)
  UIManager.ShowUI(UIManager.UI_Config.HelpTip, 0, title, content)
end

function UI_UGC_Mine_Edit_Normal_Work:InitUpdateOptionPanel()
  local bIsUpdate = self:IsUpdateMod()
  log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:InitUpdateOptionPanel bIsUpdate:" .. tostring(bIsUpdate))
  self.UIRoot.ResetLeaderboardTitle:SetText(LocUtil.GetLocalizeResStr(8502078))
  self.UIRoot.ResetVarTitle:SetText(LocUtil.GetLocalizeResStr(8502079))
  if bIsUpdate then
    local LogicUGCModRank = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCModRank)
    if LogicUGCModRank:CheckUGCRankOpen(self.modInfo) then
      self.UIRoot.ResetLeaderboardPanel:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    else
      self.UIRoot.ResetLeaderboardPanel:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      self.bUpdateResetLeaderboard = 0
    end
    local LogicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
    if LogicUGC:CheckCustomVarCloudEnable(self.modInfo) then
      self.UIRoot.ResetVarPanel:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    else
      self.UIRoot.ResetVarPanel:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      self.bUpdateResetVar = 0
    end
    self:_RefreshUpdateOptionPanel()
  else
    self.UIRoot.ResetLeaderboardPanel:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    self.UIRoot.ResetVarPanel:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    self.UIRoot.ResetLeaderboardCheckBox:SetIsChecked(false)
    self.UIRoot.ResetVarCheckBox:SetIsChecked(false)
    self.UIRoot.CheckBox_Feedback:SetIsChecked(self.AcceptFeedback)
    self.bUpdateResetLeaderboard = 0
    self.bUpdateResetVar = 0
  end
end

function UI_UGC_Mine_Edit_Normal_Work:_RefreshUpdateOptionPanel()
  self.UIRoot.ResetLeaderboardCheckBox:SetIsChecked(self.bUpdateResetLeaderboard == 1)
  self.UIRoot.ResetVarCheckBox:SetIsChecked(self.bUpdateResetVar == 1)
  self.UIRoot.CheckBox_Feedback:SetIsChecked(self.AcceptFeedback)
end

function UI_UGC_Mine_Edit_Normal_Work:IsUpdateMod()
  local relateModID
  if self.modInfo ~= nil and self.modInfo.base ~= nil and self.modInfo.base.mod_id_rela ~= nil then
    relateModID = self.modInfo.base.mod_id_rela
  end
  if relateModID and relateModID ~= 0 then
    return true
  end
  return false
end

function UI_UGC_Mine_Edit_Normal_Work:IsQuickAuditMod()
  if self.modInfo and self.modInfo.base and self.modInfo.base.quick_audit then
    return true
  end
  return false
end

function UI_UGC_Mine_Edit_Normal_Work:InitCoAuthorList()
  if self.modInfo then
    local TableUtil = require("common.table_util")
    self.coauthorList = TableUtil.CopyTable(self.modInfo.setting.coauthor_records)
    self.selectedCoauthorList = TableUtil.CopyTable(self.modInfo.setting.coauthor_ids)
    self.UID2Profiles = {}
    if #self.coauthorList > 0 then
      self.UIRoot.CanvasPanel_Coauthor:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      self:RefreshSelectedAuthor()
      if self.bOpenCoAuthor then
        self:AddGameTimer(0.3, false, function()
          if self and self.UIRoot and slua.isValid(self.UIRoot) then
            self:OnClickCoAuthor(true)
          end
        end)
      end
    else
      self.UIRoot.CanvasPanel_Coauthor:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    end
  end
end

function UI_UGC_Mine_Edit_Normal_Work:OnCoauthorSelected(_, __, selectedUIDs)
  self.selectedCoauthorList = selectedUIDs
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local modifyMeta = LogicUGCCRUD:NewModifyMeta()
  modifyMeta.coauthor_ids = self.selectedCoauthorList
  LogicUGCCRUD:ReqModifyModMeta(self.nSlot, modifyMeta)
  self:RefreshSelectedAuthor()
end

function UI_UGC_Mine_Edit_Normal_Work:RefreshSelectedAuthor()
  local bRequireGetprofile = false
  for _, uid in pairs(self.selectedCoauthorList) do
    if self.UID2Profiles[uid] == nil then
      bRequireGetprofile = true
      break
    end
  end
  if bRequireGetprofile then
    local logic_profile_get_wrap = require("client.slua.logic.user.profile.logic_profile_get_wrap")
    logic_profile_get_wrap.GetNormalProfiles(self.selectedCoauthorList, function(profileList)
      for i, profile in pairs(profileList) do
        self.UID2Profiles[profile.uid] = profile
      end
      self.coauthorWidgetList:SetData(self.selectedCoauthorList)
    end, Enum_PROFILE_REPORT_CFG.UGC)
  else
    self.coauthorWidgetList:SetData(self.selectedCoauthorList)
  end
end

function UI_UGC_Mine_Edit_Normal_Work:RefreshDelayPublishStatus()
  self.bDelayPublish = false
  local LogicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
  if LogicUGC then
    local delayTime = LogicUGC:GetDelayPublishTime(self.modInfo)
    if delayTime then
      self.bDelayPublish = true
      self.DelayPublishTimeStamp = delayTime
    end
  end
end

function UI_UGC_Mine_Edit_Normal_Work:RefreshExpiredTimeStatus()
  self.bExpiredAssetExisted = false
  local LogicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
  if LogicUGC then
    local bHasExpiredResource, delayTime = LogicUGC:GetExpiredTime(self.modInfo)
    if bHasExpiredResource then
      self.bExpiredAssetExisted = true
    end
  end
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickCoAuthor(bBanAudio)
  print(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnClickCoAuthor")
  if not bBanAudio then
    print(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnClickCoAuthor PlayAudio")
    self:PlayAudio(sound_config.click_v1)
  end
  local TableUtil = require("common.table_util")
  if #self.coauthorList > 0 then
    UIManager.ShowUI(UIManager.UI_Config.ugc_mine_edit_coauthor_select, self.coauthorList, TableUtil.CopyTable(self.selectedCoauthorList))
    EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_OPEN_COAUTHOR_PANEL, true)
  end
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickButtonVotedTag()
  self:PlayAudio(sound_config.click_v1)
  local Logic_UGC_Tag = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_tag)
  local logic_ugc_player_vote_tag = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_player_vote_tag)
  local sortTagList = {}
  local LogicUgcFilterTag = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUgcFilterTag)
  sortTagList = LogicUgcFilterTag:GetIDtoTags(self.modInfo.setting.tag_v2, 1) or {}
  UIManager.ShowUI(UIManager.UI_Config.UGC_AIOptimizeTag_Popup_UIBP, sortTagList)
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickProEditor()
  print(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnClickProEditor")
  local visibility = self.UIRoot.Canvas_Panel_AITips:GetVisibility()
  if visibility == UEnums.ESlateVisibility.Collapsed or visibility == UEnums.ESlateVisibility.Hidden then
    self.UIRoot.Canvas_Panel_AITips:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  else
    self.UIRoot.Canvas_Panel_AITips:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
  self:PlayAudio(sound_config.click_v1)
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickGotoProEditor()
  print(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnClickGotoProEditor")
  local Util_UGC = require("client.slua.logic.ugc.util_ugc")
  Util_UGC.GotoEditorPro()
  self:PlayAudio(sound_config.click_v1)
end

function UI_UGC_Mine_Edit_Normal_Work:OnRefreshAuthor(widget, index)
  print(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnRefreshAuthor")
  local itemData = self.coauthorWidgetList:GetItemData(index)
  local Uid = itemData
  local Profile = self.UID2Profiles[Uid]
  if Profile then
    widget:InitView(1, Profile.uid, Profile.picUrl, Profile.sex, Profile.cur_avatar_box_id, nil, false, "")
    widget:SetButtonEnabled(false)
    widget:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  end
end

function UI_UGC_Mine_Edit_Normal_Work:OnChangeName(name)
  if not (self and self.modInfo) or not self.UIRoot then
    log("UgcMineEditNormalWorkPanel:OnChangeName called on a destroyed or invalid UI instance.")
    return
  end
  local originName = self.modInfo.setting.name or ""
  if name == originName then
    return
  end
  local Util_UGC = require("client.slua.logic.ugc.util_ugc")
  Util_UGC.CheckNameValid(name)
  name = Util_UGC.NormalizeName(name)
  self.UIRoot.EditableText_Name:SetText(name)
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local modifyMeta = LogicUGCCRUD:NewModifyMeta()
  modifyMeta.name = name
  self.LocName = name
  self:CheckCanPublish()
  LogicUGCCRUD:ReqModifyModMeta(self.nSlot, modifyMeta)
end

function UI_UGC_Mine_Edit_Normal_Work:OnChangeDesc(desc)
  if not (self and self.modInfo) or not self.UIRoot then
    log("UgcMineEditNormalWorkPanel:OnChangeDesc called on a destroyed or invalid UI instance.")
    return
  end
  local originDesc = self.modInfo.setting.desc or ""
  if desc == originDesc then
    return
  end
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local modifyMeta = LogicUGCCRUD:NewModifyMeta()
  local Util_UGC = require("client.slua.logic.ugc.util_ugc")
  modifyMeta.desc = Util_UGC.NormalizeDesc(desc)
  self.LocDesc = modifyMeta.desc
  self:CheckCanPublish()
  LogicUGCCRUD:ReqModifyModMeta(self.nSlot, modifyMeta)
end

function UI_UGC_Mine_Edit_Normal_Work:OnChangeUpdate(log)
  self:CheckCanPublish()
  local Util_UGC = require("client.slua.logic.ugc.util_ugc")
  local normalizedLog = Util_UGC.NormalizeDesc(log)
  self.LocUpdateLog = normalizedLog
  self.UIRoot.MultiLineEditableText_Update:SetText(normalizedLog)
  if normalizedLog == "" then
    return
  end
  local LogicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
  LogicUGC:ReqTextFilter(normalizedLog)
end

function UI_UGC_Mine_Edit_Normal_Work:OnNameTextChanged(text)
  local Logic_UGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
  local ModNameMaxLen = Logic_UGC:GetModNameMaxLen()
  self:OnInputTextChanged(self.UIRoot.TextBlock_NameCurrentLen, text, ModNameMaxLen)
end

function UI_UGC_Mine_Edit_Normal_Work:OnDescTextChanged(text)
  local Logic_UGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
  local ModDescMaxLen = Logic_UGC:GetModDescMaxLen()
  self:OnInputTextChanged(self.UIRoot.TextBlock_DescCurrentLen, text, ModDescMaxLen)
end

function UI_UGC_Mine_Edit_Normal_Work:OnUpdateTextChanged(text)
  local Logic_UGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
  local ModDescMaxLen = Logic_UGC:GetModDescMaxLen()
  self:OnInputTextChanged(self.UIRoot.TextBlock_UpdateCurrentLen, text, ModDescMaxLen)
end

function UI_UGC_Mine_Edit_Normal_Work:OnResetVarCheckStateChange(isCheck)
  self:PlayAudio(sound_config.click_v1)
  if isCheck then
    local checkContent = LocUtil.GetLocalizeResStr(8502082)
    local title = LocUtil.GetLocalizeResStr(101001)
    local content = LocUtil.LocalizeFormatConcatenation(8502081, checkContent)
    local okStr = LocUtil.GetLocalizeResStr(65487)
    local cancelStr = LocUtil.GetLocalizeResStr(77102)
    local confirmFun = function()
      self.bUpdateResetVar = 1
      self:_RefreshUpdateOptionPanel()
    end
    local cancelFun = function()
      self.bUpdateResetVar = 0
      self:_RefreshUpdateOptionPanel()
    end
    UIManager.ShowUI(UIManager.UI_Config.ugc_input_check_popup, title, content, checkContent, confirmFun, cancelFun, okStr, cancelStr)
  else
    self.bUpdateResetVar = 0
    self:_RefreshUpdateOptionPanel()
  end
end

function UI_UGC_Mine_Edit_Normal_Work:OnResetLeaderboardCheckStateChange(isCheck)
  self:PlayAudio(sound_config.click_v1)
  if isCheck then
    local title = LocUtil.GetLocalizeResStr(101001)
    local content = LocUtil.LocalizeFormatConcatenation(8502080)
    local okStr = LocUtil.GetLocalizeResStr(65487)
    local cancelStr = LocUtil.GetLocalizeResStr(77102)
    local confirmFun = function()
      self.bUpdateResetLeaderboard = 1
      self:_RefreshUpdateOptionPanel()
    end
    local cancelFun = function()
      self.bUpdateResetLeaderboard = 0
      self:_RefreshUpdateOptionPanel()
    end
    local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
    CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_TWO, title, content, confirmFun, cancelFun, okStr, cancelStr)
  else
    self.bUpdateResetLeaderboard = 0
    self:_RefreshUpdateOptionPanel()
  end
end

function UI_UGC_Mine_Edit_Normal_Work:OnInputTextChanged(textWidget, text, maxLen)
  if not slua.isValid(textWidget) then
    log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnInputTextChanged no widget")
    return
  end
  local Util_UGC = require("client.slua.logic.ugc.util_ugc")
  local len = Util_UGC.GetTextLengthAndSubStr(text or "")
  textWidget:SetText(len)
  if maxLen < len then
    textWidget:SetColorAndOpacity(FSlateColor(FLinearColor(0.584079, 0.003347, 0.027321, 1)))
  elseif 0 < len and maxLen >= len then
    textWidget:SetColorAndOpacity(FSlateColor(FLinearColor(0, 0, 0, 0.7)))
  else
    textWidget:SetColorAndOpacity(FSlateColor(FLinearColor(0, 0, 0, 0.4)))
  end
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickAddCover(widget, index)
  self:PlayAudio(sound_config.click_v1)
  local itemCount = self.coverWidgetList:GetItemCount()
  if index ~= itemCount then
    return
  end
  UIManager.ShowUI(UIManager.UI_Config.ugc_mine_photo_album_detail_select, self.nSlot, self.modInfo.setting)
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickDeleteCover(widget, index)
  self:PlayAudio(sound_config.click_v1)
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local modifyMeta = LogicUGCCRUD:NewModifyMeta()
  local thumbIndex = self.modInfo.setting.thumb_index
  local viewList = {}
  if self.modInfo.setting.view_pic_list then
    for i = 1, #self.modInfo.setting.view_pic_list do
      if i ~= index then
        table.insert(viewList, self.modInfo.setting.view_pic_list[i])
      end
    end
  end
  if index == 1 then
    if viewList and 0 < #viewList then
      thumbIndex = viewList[1]
    else
      thumbIndex = -1
    end
  end
  modifyMeta.thumb_index = thumbIndex
  modifyMeta.view_pic_list = viewList
  LogicUGCCRUD:ReqModifyModMeta(self.nSlot, modifyMeta)
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickEvent()
  self:PlayAudio(sound_config.click_v1)
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local bPrivate = LogicUGCCRUD:CheckEditModIsPrivate(self.modInfo)
  if bPrivate then
    ShowNotice(LocUtil.GetLocalizeResStr(10120052))
    return
  end
  UIManager.ShowUI(UIManager.UI_Config.UGC_SeasonTag_Popup_UIBP, self.modInfo)
  local TimeUtil = require("client.common.time_util")
  local str = string.format("activity_id=%s&uid=%d&time=%d", tostring(self.CurSelectSeasonActID), tonumber(DataMgr.roleData.uid), TimeUtil.GetServerTimeInSec())
  local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
  UGCTLogReport:ReportDelay(TLogEventDefine.UGC_EventThem_EditNormalPanelOnClick, 0, str)
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickEventName()
  self:PlayAudio(sound_config.click_v1)
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local bPrivate = LogicUGCCRUD:CheckEditModIsPrivate(self.modInfo)
  if bPrivate then
    ShowNotice(LocUtil.GetLocalizeResStr(10120052))
    return
  end
  UIManager.ShowUI(UIManager.UI_Config.UGC_SeasonTag_Popup_UIBP, self.modInfo)
  local TimeUtil = require("client.common.time_util")
  local str = string.format("activity_id=%s&uid=%d&time=%d", tostring(self.CurSelectSeasonActID), tonumber(DataMgr.roleData.uid), TimeUtil.GetServerTimeInSec())
  local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
  UGCTLogReport:ReportDelay(TLogEventDefine.UGC_EventThem_EditNormalPanelOnClick, 0, str)
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickEventTips()
  self:PlayAudio(sound_config.click_v1)
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local bPrivate = LogicUGCCRUD:CheckEditModIsPrivate(self.modInfo)
  if bPrivate then
    ShowNotice(LocUtil.GetLocalizeResStr(10120052))
    return
  end
  UIManager.ShowUI(UIManager.UI_Config.UGC_SeasonTag_Popup_UIBP, self.modInfo, nil, self.show_actID)
  local TimeUtil = require("client.common.time_util")
  local str = string.format("activity_id=%s&uid=%d&time=%d", tostring(self.CurSelectSeasonActID), tonumber(DataMgr.roleData.uid), TimeUtil.GetServerTimeInSec())
  local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
  UGCTLogReport:ReportDelay(TLogEventDefine.UGC_EventThem_EditNormalPanelOnClick, 0, str)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Tips, false)
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickAICoverCheck()
  self:PlayAudio(sound_config.click_v1)
  local UIUtil = require("client.common.ui_util")
  if not UIUtil.CanClickNow(UIUtil.ClickFrequencyLimit.CreateAICover) then
    return
  end
  local thumb_index = self.modInfo and self.modInfo.setting and self.modInfo.setting.thumb_index or -1
  if thumb_index == -1 then
    ShowNotice(1050175)
    return
  end
  if self.use_ai_photo == 0 then
    self.use_ai_photo = 1
  elseif self.use_ai_photo == 1 then
    self.use_ai_photo = 0
  end
  log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnClickAICoverCheck se;f.ai_photo = " .. tostring(self.use_ai_photo))
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local modifyMeta = LogicUGCCRUD:NewModifyMeta()
  modifyMeta.use_ai_photo = self.use_ai_photo
  LogicUGCCRUD:ReqModifyModMeta(self.nSlot, modifyMeta)
  self.bChange = true
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickAICoverQues()
  self:PlayAudio(sound_config.click_v1)
  local title = LocUtil.GetLocalizeResStr(1050098)
  local msg = LocUtil.GetLocalizeStrConcatenation(1050105)
  UIManager.ShowUI(UIManager.UI_Config.HelpTip, 0, title, msg)
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickOpenAIImageUI()
  self:PlayAudio(sound_config.click_v1)
  local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
  if PublishRegionMacros.IsBlueholeFamily() then
    ShowNotice(2008103)
    return
  end
  UIManager.ShowUI(UIManager.UI_Config.UGC_EditAICoverImage_UIBP, self.modInfo, self.nSlot)
  local logic_ugc_WOWPass = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_WOWPass)
  local pass_id = logic_ugc_WOWPass:GetSeasonID() or -1
  local logic_ugc_ai_cover_image = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_ai_cover_image)
  local valid_id = logic_ugc_ai_cover_image:GetAssociateID(self.modInfo)
  local str = string.format("valid_id=%s&uid=%d&pass_id=%d", valid_id, tonumber(DataMgr.roleData.uid), pass_id)
  local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
  UGCTLogReport:ReportDelay(TLogEventDefine.UGC_AICover_Image_Click, 0, str)
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickAlbumTheme()
  self:PlayAudio(sound_config.click_v1)
  log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnClickAlbumTheme")
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local bPrivate = LogicUGCCRUD:CheckEditModIsPrivate(self.modInfo)
  if bPrivate then
    ShowNotice(LocUtil.GetLocalizeResStr(10120053))
    return
  end
  local logic_ugc_album_theme = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_album_theme)
  logic_ugc_album_theme:SetAlbumThemeJustBrowseState(false)
  UIManager.ShowUI(UIManager.UI_Config.UGC_AlbumThemeSelect_Popup_UIBP, self.modInfo, self.CurSelectAlbumThemeID)
end

function UI_UGC_Mine_Edit_Normal_Work:OnModifyMod()
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  self.modInfo = LogicUGCCRUD:GetModeBySlot(self.nSlot)
  local state = self.modInfo.base.state_release or Config_UGC.E_PublishState.Not
  if state ~= Config_UGC.E_PublishState.Not then
    self:CloseSelf()
    return
  end
  self:InitInfo()
  self:InitTags(C_TagWidgetName)
  self:InitCovers()
  self:RefreshDelayPublishStatus()
  self:RefreshExpiredTimeStatus()
  self:CheckCanPublish()
  self:UpdatePubState()
end

function UI_UGC_Mine_Edit_Normal_Work:OnDuplicateMod()
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local bExposure = LogicUGCCRUD:GetExposureCouponState()
  log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnDuplicateMod bExposure:" .. tostring(bExposure))
  if not bExposure then
    self:CloseSelf()
  end
end

function UI_UGC_Mine_Edit_Normal_Work:OnDeleteMod()
  self:CloseSelf()
end

function UI_UGC_Mine_Edit_Normal_Work:OnModifyTags(_, _, tags, subtags)
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local modifyMeta = LogicUGCCRUD:NewModifyMeta()
  modifyMeta.tag_v2 = tags
  if subtags ~= nil then
    modifyMeta.subfeature_tag = subtags
  end
  self.LocTag_v2 = tags
  LogicUGCCRUD:ReqModifyModMeta(self.nSlot, modifyMeta)
end

function UI_UGC_Mine_Edit_Normal_Work:OnUpdateAuthor(_, _, uid)
  self:UpdateAuthorInfo()
end

function UI_UGC_Mine_Edit_Normal_Work:OnSelectPhoto(_, _, slot, index)
  if slot ~= self.nSlot then
    return
  end
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local LogicUGCAuthor = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor)
  local authorLevel = LogicUGCAuthor:GetMineAuthorLevel()
  local numMax = Config_UGC.GetCoverMaxNum(authorLevel)
  if self.modInfo.setting.thumb_index > 0 and self.modInfo.setting.view_pic_list and numMax <= #self.modInfo.setting.view_pic_list then
    return
  end
  local modifyMeta = LogicUGCCRUD:NewModifyMeta()
  local thumbIndex = self.modInfo.setting.thumb_index
  local viewList = {}
  if self.modInfo.setting.thumb_index <= 0 then
    thumbIndex = index
  end
  if self.modInfo.setting.view_pic_list then
    for i = 1, #self.modInfo.setting.view_pic_list do
      table.insert(viewList, self.modInfo.setting.view_pic_list[i])
    end
  end
  table.insert(viewList, index)
  if viewList and viewList[1] and thumbIndex ~= viewList[1] then
    log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnSelectPhoto Correction thumbIndex")
    thumbIndex = viewList[1]
  end
  modifyMeta.thumb_index = thumbIndex
  modifyMeta.view_pic_list = viewList
  LogicUGCCRUD:ReqModifyModMeta(self.nSlot, modifyMeta)
end

function UI_UGC_Mine_Edit_Normal_Work:OnEditMatchInfoChange(_, _, bIsTeamLeader)
  if not bIsTeamLeader then
    self:CloseSelf()
  end
end

function UI_UGC_Mine_Edit_Normal_Work:OnPublishMod()
  local LogicUGCWorkDiagnosis = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_work_diagnosis)
  local modId = self.modInfo and self.modInfo.base and self.modInfo.base.mod_id
  local result = LogicUGCWorkDiagnosis:GetDiagResultByModId(modId)
  if result then
    LogicUGCWorkDiagnosis:ReportDiagScore(result, 1, true)
  end
  self:CloseSelf()
end

function UI_UGC_Mine_Edit_Normal_Work:OnGetModBatchRsp(_, _, ListType, bIsDirty, MetaList, Param, FilterOfflineModList)
  local UGCMacros = require("client.slua.logic.ugc.ugc_macros")
  if not UGCMacros.CheckMetaType(ListType, UGCMacros.ENUM_MODE_TYPE.Pub) then
    return
  end
  local _, RelateMod = next(MetaList)
  local RelateModID = self.modInfo and self.modInfo.base and self.modInfo.base.mod_id_rela
  if RelateModID and RelateMod and RelateMod.pub_mod_meta.mod_id == RelateModID then
    self.CurSelectSeasonActID = RelateMod.pub_mod_meta.activity_event_id
    self:InitRelateMod(RelateMod)
  end
  local _, originMod = next(MetaList)
  if originMod and RelateMod and RelateMod.pub_mod_meta.mod_id == self.originModId then
    self.originModInfo = originMod
    self:UpdateOriginModUI()
  end
end

function UI_UGC_Mine_Edit_Normal_Work:OnRefreshAlbumUI()
  log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnRefreshAlbumUI")
  local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
  if PublishRegionMacros.IsBlueholeFamily() then
    self:SetWidgetVisible(self.UIRoot.Canvas_Panel_SpecialEdition, false)
  else
    self:SetWidgetVisible(self.UIRoot.Canvas_Panel_SpecialEdition, true)
  end
  local logic_ugc_album_theme = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_album_theme)
  local ValidList = logic_ugc_album_theme:GetAlbumThemeLoopData()
  if self:CheckPlayerAlbumIsBan(DataMgr.roleData.uid, self.CurSelectAlbumThemeID) then
    log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnRefreshAlbumUI CheckPlayerAlbumIsBan is true")
    return
  end
  for i, temp in ipairs(ValidList) do
    if self.template_id == temp.template_id then
      self.UIRoot.WidgetSwitcher_SpecialEdition:SetActiveWidgetIndex(1)
      self.UIRoot.TextBlock_SpecialEditionName:SetText(temp.name)
      self.CurSelectAlbumThemeID = temp.id
      break
    end
  end
  log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnRefreshAlbumUI self.CurSelectAlbumThemeID = " .. tostring(self.CurSelectAlbumThemeID))
end

function UI_UGC_Mine_Edit_Normal_Work:OnSelectAlbumUI(_, _, SelectAlbumThemeID)
  log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnSelectAlbumUI SelectAlbumThemeID = " .. tostring(SelectAlbumThemeID))
  local logic_ugc_album_theme = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_album_theme)
  local AlbumThemeData = logic_ugc_album_theme:GetAlbumTheme(SelectAlbumThemeID)
  if not AlbumThemeData then
    log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnSelectAlbumUI AlbumThemeData is nil")
    self.CurSelectAlbumThemeID = nil
    self.UIRoot.WidgetSwitcher_SpecialEdition:SetActiveWidgetIndex(0)
    return
  end
  if self:CheckPlayerAlbumIsBan(DataMgr.roleData.uid, SelectAlbumThemeID) then
    log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnSelectAlbumUI CheckPlayerAlbumIsBan is true")
    return
  end
  self.UIRoot.WidgetSwitcher_SpecialEdition:SetActiveWidgetIndex(1)
  self.UIRoot.TextBlock_SpecialEditionName:SetText(AlbumThemeData.name)
  self.CurSelectAlbumThemeID = SelectAlbumThemeID
end

function UI_UGC_Mine_Edit_Normal_Work:OnEditShotCrashSaved(_, _, main_slot, bCrashSaved)
  log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnEditShotCrashSaved" .. tostring(main_slot))
  if main_slot ~= self.nSlot then
    return
  end
  self:RefreshArchiveRedDot()
end

function UI_UGC_Mine_Edit_Normal_Work:InitEditTabText()
  for _, config in pairs(EditTabConfig) do
    local tabWidget = self.UIRoot[config.tabControl]
    local text = LocUtil.GetLocalizeResStr(config.textID)
    tabWidget.TextBlock_TabText:SetText(text)
    tabWidget.TextBlock_TabText_2:SetText(text)
    tabWidget.TextBlock_Num:SetText(config.ID)
  end
end

function UI_UGC_Mine_Edit_Normal_Work:SwitchEditTab(tabIndex, subTargetID)
  local tabConfig = EditTabConfig[tabIndex]
  if not tabConfig then
    log_warning(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:SwitchEditTab, invalid tabIndex = " .. tostring(tabIndex))
    return
  end
  if tabIndex ~= E_EditTab.Tab1 then
    local bPassed, reasonTips = self:CheckRequiredFields()
    if not bPassed then
      ShowNotice(reasonTips)
      if self.curEditTab ~= E_EditTab.Tab1 then
        self:SwitchEditTab(E_EditTab.Tab1)
      end
      return
    end
  end
  self.jumpSubTargetID = subTargetID or ""
  local preTab = self.curEditTab
  self.curEditTab = tabIndex
  self:RefreshPubBtnInfo()
  local tlogId = EditTabTlogMap[tabIndex]
  if tlogId then
    local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
    UGCTLogReport:ReportDelay(tlogId)
  end
  for curIndex, config in pairs(EditTabConfig) do
    local tabWidget = self.UIRoot[config.tabControl]
    tabWidget.WidgetSwitcher_Select:SetActiveWidgetIndex(curIndex == tabIndex and 0 or 1)
  end
  self.UIRoot.WidgetSwitcher_Content:SetActiveWidgetIndex(tabConfig.contentIndex)
  if tabConfig.tab1Tab2SwitcherIndex then
    self.UIRoot.WidgetSwitcher_Tab1Tab2:SetActiveWidgetIndex(tabConfig.tab1Tab2SwitcherIndex)
  end
  self.UIRoot.ScrollBox_0:ScrollToStart()
  if tabIndex == E_EditTab.Tab3 and preTab ~= E_EditTab.Tab3 then
    self:RunWorkDiagnosis()
  end
  if self.jumpSubTargetID ~= "" then
    self:ShowDiagnosisGuide(self.jumpSubTargetID)
  end
end

function UI_UGC_Mine_Edit_Normal_Work:ShowDiagnosisGuide(subTargetID)
  self:CloseDiagnosisGuide()
  local targetWidgetName = DIAG_GUIDE_TARGET_WIDGET[subTargetID]
  if not targetWidgetName then
    return
  end
  local targetWidget
  if subTargetID == "PubState" then
    if not self.releaseItemUI then
      return
    end
    targetWidget = self.releaseItemUI.UIRoot[targetWidgetName]
  else
    targetWidget = self.UIRoot[targetWidgetName]
  end
  self.diagGuideUI = self:CreateChildWindow(targetWidget, UIManager.UI_Config.UGC_HintTips_UIBP)
end

function UI_UGC_Mine_Edit_Normal_Work:CloseDiagnosisGuide()
  if self.diagGuideUI then
    self.diagGuideUI:CloseSelf()
    self.diagGuideUI = nil
  end
end

function UI_UGC_Mine_Edit_Normal_Work:RunWorkDiagnosis()
  local LogicUGCWorkDiagnosis = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_work_diagnosis)
  local overrides = {
    title = self.UIRoot.EditableText_Name:GetText(),
    desc = self.UIRoot.MultiLineEditableText_Desc:GetText(),
    tagList = self.modInfo and self.modInfo.setting and self.modInfo.setting.tag_v2 or {},
    featureTagList = self.modInfo and self.modInfo.setting and self.modInfo.setting.features_2_tags or {},
    selectedSeasonActID = self.CurSelectSeasonActID,
    specThemeID = self.CurSelectAlbumThemeID
  }
  local result = LogicUGCWorkDiagnosis:RunPreCheck(self.modInfo, overrides)
  if not result then
    log_warning(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:RunWorkDiagnosis, diagnosis result is nil")
    return
  end
  self.diagScore = result.score
  LogicUGCWorkDiagnosis:ReportDiagScore(result, 1)
  local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
  UGCTLogReport:ReportDelay(TLogEventDefine.UGC_WorkDiagnosis_Run, 1)
  self.releaseItemUI:RefreshPromotionReminderList(result)
end

function UI_UGC_Mine_Edit_Normal_Work:InitInfo()
  local root = self.UIRoot
  root.EditableText_Name:SetText(self.modInfo.setting.name or "")
  root.MultiLineEditableText_Desc:SetText(self.modInfo.setting.desc or "")
  self:InitTextLenShow()
  self:InitReason()
  self:InitRelateMod()
  self:InitShareCreate()
  self:InitInvalidResRef(self.modInfo.setting.invalid_res_ref)
end

function UI_UGC_Mine_Edit_Normal_Work:InitTextLenShow()
  local root = self.UIRoot
  local Logic_UGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
  local ModDescMaxLen = Logic_UGC:GetModDescMaxLen()
  root.TextBlock_DescMaxLen:SetText(ModDescMaxLen or 0)
  local ModNameMaxLen = Logic_UGC:GetModNameMaxLen()
  root.TextBlock_NameMaxLen:SetText(ModNameMaxLen or 0)
  root.TextBlock_UpdateMaxLen:SetText(ModDescMaxLen or 0)
  local Util_UGC = require("client.slua.logic.ugc.util_ugc")
  local nameStr = root.EditableText_Name:GetText() or ""
  local nameLen = Util_UGC.GetTextLengthAndSubStr(nameStr) or 0
  root.TextBlock_NameCurrentLen:SetText(nameLen)
  local descStr = root.MultiLineEditableText_Desc:GetText() or ""
  local descLen = Util_UGC.GetTextLengthAndSubStr(descStr) or 0
  root.TextBlock_DescCurrentLen:SetText(descLen)
  local shouldShow = false
  if self.modInfo.base.mod_id_rela then
    local LogicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
    local relateModInfo = LogicUGC:GetModByAllCache(self.modInfo.base.mod_id_rela)
    local currentUID = self.modInfo.base and self.modInfo.base.uid or 0
    if relateModInfo and relateModInfo.pub_mod_meta and relateModInfo.pub_mod_meta.base and relateModInfo.pub_mod_meta.base.uid == currentUID then
      shouldShow = true
    end
  end
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_VersionUpdate, shouldShow)
end

function UI_UGC_Mine_Edit_Normal_Work:InitRelateMod(ModInfo)
  local Root = self.UIRoot
  if ModInfo then
    Root.UGC_RelationMod_Item:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    Root.CanvasPanel_Update:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    Root.MultiLineEditableText_Update:SetText(self.LocUpdateLog or "")
    Root.TextBlock_UpdateCurrentLen:SetText("0")
    Root.TextBlock_UpdateCurrentLen:SetColorAndOpacity(FSlateColor(FLinearColor(0, 0, 0, 0.4)))
    self.releaseItemUI:SetUpdateButtonText(true)
    self:SetWidgetVisible(Root.CanvasPanel_VotedTag, true, true)
    local modMeta = ModInfo.pub_mod_meta
    local RelateRoot = Root.UGC_RelationMod_Item
    local Util_UGC = require("client.slua.logic.ugc.util_ugc")
    Util_UGC.SetCoverImage(self, RelateRoot.Image_Mod, modMeta, false, true, nil, nil)
    RelateRoot.TextBlock_Name:SetText(LocUtil.LocalizeResFormat(70090, modMeta.setting.name or ""))
    RelateRoot.TextBlock_ModCode:SetText(LocUtil.LocalizeResFormat(70000, Util_UGC.ModIDTransformToShow(modMeta.mod_id)))
    if self.bIsFromRelate then
      RelateRoot.Button_Show:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    else
      RelateRoot.Button_Show:SetWidgetVisibility(UEnums.ESlateVisibility.Visible)
    end
    self:RefreshSeasonTagUI()
  else
    local Logic_UGC_Season_Template = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_season_template)
    self.CurSelectSeasonActID = Logic_UGC_Season_Template.curSelectActivityID
    Root.UGC_RelationMod_Item:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    Root.CanvasPanel_Update:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    self:SetWidgetVisible(Root.CanvasPanel_VotedTag, false, true)
    self.releaseItemUI:SetUpdateButtonText(false)
    local RelateModID = self.modInfo and self.modInfo.base and self.modInfo.base.mod_id_rela
    if RelateModID and RelateModID ~= 0 then
      local LogicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
      LogicUGC:BatchGetModInfo({RelateModID}, LogicUGC.C_ModListTypes.Pub, nil, {bSimple = true})
    end
    self:RefreshSeasonTagUI()
  end
end

function UI_UGC_Mine_Edit_Normal_Work:InitReason()
  local reason = self.modInfo.base.state_reason
  if reason and 0 < reason then
    self.UIRoot.CanvasPanel_Reason:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    self:SetWidgetVisible(self.UIRoot.Button_ViewMore, true, true)
    local data = Config_UGC.GetModReasonConfigByID(reason)
    if data ~= nil then
      self.UIRoot.TextBlock_Reason:SetText(data.Desc)
      self.UIRoot.TextBlock_Reason:SetColorAndOpacity(FSlateColor(FLinearColor(0.698, 0.141, 0, 1)))
      self.UIRoot.Image_170:SetColorAndOpacity(FLinearColor(0.698, 0.141, 0, 1))
    end
  else
    self.UIRoot.CanvasPanel_Reason:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
end

function UI_UGC_Mine_Edit_Normal_Work:IsHasPlanphAsset()
  return self.modInfo and self.modInfo.setting.has_planph_asset == true
end

function UI_UGC_Mine_Edit_Normal_Work:InitShareCreate()
  if self:IsHasPlanphAsset() then
    self.UIRoot.TextBlock_ShareCreateMod:SetActiveColorIndex(1)
    if self.modInfo.setting.share_switch == 1 then
      log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:InitShareCreate - force reset share_switch=0 due to has_planph_asset, slot=" .. tostring(self.nSlot))
      local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
      local modifyMeta = LogicUGCCRUD:NewModifyMeta()
      modifyMeta.share_switch = 0
      LogicUGCCRUD:ReqModifyModMeta(self.nSlot, modifyMeta)
      self.modInfo.setting.share_switch = 0
    end
  else
    self.UIRoot.TextBlock_ShareCreateMod:SetActiveColorIndex(0)
  end
  local state = self.modInfo.setting.share_switch or 0
  if state == 1 then
    self.UIRoot.WidgetSwitcher_Share:SetActiveWidgetIndex(1)
  else
    self.UIRoot.WidgetSwitcher_Share:SetActiveWidgetIndex(0)
  end
end

function UI_UGC_Mine_Edit_Normal_Work:InitTags(widgetName)
  if not self.modInfo then
    return
  end
  local sortTagList = {}
  local LogicUgcFilterTag = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUgcFilterTag)
  sortTagList = LogicUgcFilterTag:GetIDtoTags(self.modInfo.setting.tag_v2, 1) or {}
  LogicUgcFilterTag:SortTagListForDisplay(sortTagList)
  local root = self.UIRoot
  for i = 1, Config_UGC.TagMaxNum do
    local tagWidget = root[widgetName .. "_" .. i]
    if tagWidget then
      local tagID = sortTagList[i]
      if tagID then
        tagWidget:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
        self:InitTag(tagWidget, tagID)
      else
        tagWidget:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      end
    end
  end
  self:AddTimerOnce(1, function()
    EventSystem:postEvent(EVENTTYPE_NEWBIE_GUIDE, EVENTID_NEWBIE_UI_OPEN, "UGCNewFilterTag")
  end)
end

function UI_UGC_Mine_Edit_Normal_Work:InitTag(widget, tag)
  if not widget then
    log_warning(bWriteLog and "[edward] UI_UGC_ModItem_Base:InitTag widget is nil")
    return
  end
  if not tag then
    log_warning(bWriteLog and "[edward] UI_UGC_ModItem_Base:InitTag config is nil tag. tagID = nil")
    widget:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    return
  end
  widget.TextBlock_Name:SetText(tag.Name)
  local LobbySocialSystem = require("client.slua.logic.lobby.Left.logic_lobby_social")
  local Util_UGC = require("client.slua.logic.ugc.util_ugc")
  local selfprofile = LobbySocialSystem.GetSelfProfile()
  local logic_ugc_WOWPass = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_WOWPass)
  local IsBuy = logic_ugc_WOWPass:IsBuyElite()
  if IsBuy or Util_UGC.WoWPassActive(selfprofile) then
    widget.WidgetSwitcher_Color:SetActiveWidgetIndex(2)
  elseif tag.PrimaryType and tag.PrimaryType ~= 0 and widget.WidgetSwitcher_Color then
    widget.WidgetSwitcher_Color:SetActiveWidgetIndex(0)
  else
    widget.WidgetSwitcher_Color:SetActiveWidgetIndex(1)
  end
end

function UI_UGC_Mine_Edit_Normal_Work:InitCovers()
  local coverList = {}
  local Util_UGC = require("client.slua.logic.ugc.util_ugc")
  local thumb_index = self.modInfo and self.modInfo.setting and self.modInfo.setting.thumb_index or -1
  local newThumbIndex = -1
  local url
  if self.modInfo.setting.view_pic_list then
    for i = 1, #self.modInfo.setting.view_pic_list do
      if thumb_index == self.modInfo.setting.view_pic_list[i] then
        newThumbIndex = i
      end
      url = Util_UGC.GetUGCViewUrl(self.modInfo.setting, i, false)
      if url ~= "" then
        table.insert(coverList, url)
      end
    end
  end
  if newThumbIndex ~= -1 then
    local temp = coverList[1]
    coverList[1] = coverList[newThumbIndex]
    coverList[newThumbIndex] = temp
  end
  local LogicUGCAuthor = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor)
  local authorLevel = LogicUGCAuthor:GetMineAuthorLevel()
  local maxNum = Config_UGC.GetCoverMaxNum(authorLevel)
  if maxNum > #coverList then
    table.insert(coverList, "")
  end
  self.coverWidgetList:SetData(coverList)
  self:UpdateAICoverUI()
  self.coverWidgetList:RefreshAllItems()
end

function UI_UGC_Mine_Edit_Normal_Work:OnRefreshCover(widget, index)
  local itemData = self.coverWidgetList:GetItemData(index)
  if itemData == "" then
    widget.WidgetSwitcher_Cover:SetActiveWidgetIndex(0)
    self:SetWidgetVisible(widget.WidgetSwitcher_Tag, false)
  else
    widget.WidgetSwitcher_Cover:SetActiveWidgetIndex(1)
    local image_download_mgr = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.image_download_mgr)
    local DiskCacheTypeEnum = image_download_mgr:GetDiskCacheTypeEnum()
    local Util_UGC = require("client.slua.logic.ugc.util_ugc")
    Util_UGC.SetUGCImage(self, widget.Image_Cover, itemData, true, nil, nil, DiskCacheTypeEnum.NeverDelete)
    widget.WidgetSwitcher_1:SetActiveWidgetIndex(0)
    self:SetWidgetVisible(widget.CanvasPanel_CoverTag, false)
    if index == 1 then
      self:SetWidgetVisible(widget.CanvasPanel_CoverTag, true)
      if self.use_ai_photo == 1 then
        widget.WidgetSwitcher_1:SetActiveWidgetIndex(1)
      end
      widget.TextBlock_Flag:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      if self.bChange and widget.Anim_LightSweep then
        self:PlayWidgetAnimation(widget, widget.Anim_LightSweep, 0, 1, 0, 1)
        self.bChange = false
      end
    else
      widget.TextBlock_Flag:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    end
    widget.TextBlock_Flag:SetText(LocUtil.GetLocalizeResStr(1050129))
    widget.TextBlock_Flag02:SetText(LocUtil.GetLocalizeResStr(4303050))
    self:SetWidgetVisible(widget.WidgetSwitcher_Tag, true)
    if index == 1 then
      widget.WidgetSwitcher_Tag:SetActiveWidgetIndex(0)
    else
      self:SetWidgetVisible(widget.WidgetSwitcher_Tag, false)
    end
  end
end

function UI_UGC_Mine_Edit_Normal_Work:ShowTrailModPubMsgBox(publishFunc, type)
  if not publishFunc then
    log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:ShowTrailModPubMsgBox no func")
    return
  end
  local Util_UGC = require("client.slua.logic.ugc.util_ugc")
  local title = LocUtil.GetLocalizeResStr(101001)
  local hasPlayedCompleted = Util_UGC.GetEditModHasPlayedCompleted(self.modInfo)
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  if 0 < hasPlayedCompleted then
    if hasPlayedCompleted == 1 then
      local content = LocUtil.GetLocalizeStrConcatenation(8501073)
      CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_FOUR, title, content, publishFunc)
      if type == 1 then
        local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
        UGCTLogReport:ReportDelay(TLogEventDefine.UGC_NewPub_HasPlayedCompleted)
      elseif type == 2 then
        local mod_id = self.modInfo.base.mod_id or 0
        local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
        UGCTLogReport:ReportDelay(TLogEventDefine.UGC_Update_HasPlayedCompleted, mod_id)
      end
    else
      local content = LocUtil.GetLocalizeStrConcatenation(8600163)
      CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_FOUR, title, content, publishFunc)
    end
  else
    local min_start_player = Util_UGC.GetMinPlayerCount(self.modInfo)
    log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:ShowTrailModPubMsgBox min_start_player = " .. min_start_player)
    if min_start_player == 1 then
      local content = LocUtil.GetLocalizeResStr(8801024)
      local buttonPublish = LocUtil.GetLocalizeResStr(8501071)
      local buttonPlay = LocUtil.GetLocalizeResStr(8973137)
      CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_FOUR, title, content, function()
        log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:ShowTrailModPubMsgBox EnterTrailPlay")
        self:EnterTrailPlay()
      end, publishFunc, buttonPlay, buttonPublish)
    elseif 2 <= min_start_player and min_start_player <= 8 then
      if IsWoWEditor then
        publishFunc()
      else
        local content = LocUtil.GetLocalizeResStr(8801025)
        local buttonPublish = LocUtil.GetLocalizeResStr(8501071)
        local buttonPlay = LocUtil.GetLocalizeResStr(19920003)
        CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_FOUR, title, content, function()
          self:CloseSelf()
          local LogicTeamUpSideBar = require("client.slua.logic.lobby.logic_teamup_side_bar")
          LogicTeamUpSideBar.ShowTeamUpSideBar(LogicTeamUpSideBar.ENUM_OPEN_FROM.UGCPubMod, LogicTeamUpSideBar.ENUM_TAB.ENUM_FRIEND_TAG)
          local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
          UGCTLogReport:ReportDelay(TLogEventDefine.UGC_Click_WoWTeam)
        end, publishFunc, buttonPlay, buttonPublish)
      end
    elseif 8 < min_start_player then
      local content = LocUtil.GetLocalizeResStr(8801026)
      local buttonPublish = LocUtil.GetLocalizeResStr(8501071)
      local buttonPlay = LocUtil.GetLocalizeResStr(110035)
      CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_FOUR, title, content, nil, publishFunc, buttonPlay, buttonPublish)
    end
  end
end

function UI_UGC_Mine_Edit_Normal_Work:EnterTrailPlay()
  log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:EnterTrailPlay")
  self:CancelArchiveDownloadIntent(true)
  local func = function(bOk)
    if not bOk then
      return
    end
    local LogicUGCMatch = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch)
    if LogicUGCMatch.bUseDirectEdit then
      self:SingleEditFunc(true)
    else
      LogicUGCMatch:ReqEditModMatch(self.nSlot)
    end
  end
  if not PufferDownloader.CheckAllMapPak(nil, func) then
    return
  end
  local PufferConst = require("client.slua.logic.download.puffer_const")
  local ResManager = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager)
  local State = ResManager:GetResState(ResManager.DownloaderType.MyWork, self.modInfo)
  if State ~= PufferConst.ENUM_DownloadState.Done then
    if self.downloader_ui and self.downloader_ui.UIRoot.OnClickDownloadButton then
      self.downloader_ui.UIRoot:OnClickDownloadButton()
    end
    return
  end
  func(true)
end

function UI_UGC_Mine_Edit_Normal_Work:HideArchiveDownloader()
  if self.archive_downloader_ui and self.archive_downloader_ui.UIRoot then
    self.archive_downloader_ui.UIRoot:CheckRemoveLoaderTimer()
  end
  if self.UIRoot.CanvasPanel_Download_2 then
    self.UIRoot.CanvasPanel_Download_2:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
end

function UI_UGC_Mine_Edit_Normal_Work:HideWorkDownloader()
  if self.downloader_ui and self.downloader_ui.UIRoot then
    self.downloader_ui.UIRoot:CheckRemoveLoaderTimer()
  end
  if self.UIRoot.CanvasPanel_Download then
    self.UIRoot.CanvasPanel_Download:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
end

function UI_UGC_Mine_Edit_Normal_Work:CheckShowDownloader()
  if self:CheckShowArchiveDownloader() then
    return
  end
  self:HideArchiveDownloader()
  if self.UIRoot.CanvasPanel_Download then
    self.UIRoot.CanvasPanel_Download:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  end
  local resManager = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager)
  local common_download_handler = require("client.slua.common.common_download_handler")
  local config_ugc = require("client.slua.logic.ugc.config_ugc")
  self.downloader_ui = common_download_handler.CreateUGCDownloader(resManager.DownloadUIType.EditModBtn, resManager.DownloaderType.MyWork, self.modInfo, self.UIRoot.CanvasPanel_Download, self.UIRoot.WidgetSwitcher_ResState, self, {
    Source = config_ugc.EnumDownLoadSource.UgcMineEditNormalWorkPanel,
    UGCDownloadConfirmThreshold = 50,
    LinearColor = FLinearColor(0, 0, 0, 1)
  })
end

function UI_UGC_Mine_Edit_Normal_Work:CheckShowArchiveDownloader()
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local DownloadSaveSlot = LogicUGCCRUD:GetDownloadingSaveSlot(self.nSlot)
  if not DownloadSaveSlot then
    return false
  end
  local save_type = DownloadSaveSlot.save_type
  local save_slot = DownloadSaveSlot.save_slot
  local PufferConst = require("client.slua.logic.download.puffer_const")
  local ResManager = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager)
  local ArchiveModInfo = LogicUGCCRUD:BuildArchiveResModInfo(self.nSlot, save_type, save_slot)
  local State = ArchiveModInfo and ResManager:GetResState(ResManager.DownloaderType.MyWork, ArchiveModInfo, false) or nil
  if not ArchiveModInfo or State == PufferConst.ENUM_DownloadState.Done then
    LogicUGCCRUD:ClearDownloadingSaveSlot(self.nSlot)
    return false
  end
  log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:CheckShowArchiveDownloader save_type = " .. tostring(save_type) .. " save_slot = " .. tostring(save_slot) .. " State = " .. tostring(State))
  local bDownloading = State == PufferConst.ENUM_DownloadState.Download or State == PufferConst.ENUM_DownloadState.Wait
  self:StartArchiveDownload(ArchiveModInfo, save_type, save_slot, self.archiveDownloadToken, bDownloading)
  return true
end

function UI_UGC_Mine_Edit_Normal_Work:CancelArchiveDownloadIntent(bTerminateSession)
  self.archiveDownloadToken = self.archiveDownloadToken + 1
  self.nSelectSaveType = nil
  self.nSelectSaveSlot = nil
  if self.archive_downloader_ui and self.archive_downloader_ui.UIRoot then
    self.archive_downloader_ui.UIRoot:CheckRemoveLoaderTimer()
  end
  if not bTerminateSession then
    return
  end
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local bArchiveShowing = LogicUGCCRUD:GetDownloadingSaveSlot(self.nSlot) ~= nil
  LogicUGCCRUD:ClearDownloadingSaveSlot(self.nSlot)
  if bArchiveShowing then
    self:CheckShowDownloader()
  end
end

function UI_UGC_Mine_Edit_Normal_Work:StartArchiveDownload(ArchiveModInfo, save_type, save_slot, DownloadToken, bDownloading)
  log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:StartArchiveDownload")
  local common_download_handler = require("client.slua.common.common_download_handler")
  local ResManager = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager)
  local config_ugc = require("client.slua.logic.ugc.config_ugc")
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local MainSlot = self.nSlot
  self:HideWorkDownloader()
  self.archive_downloader_ui = common_download_handler.CreateUGCDownloader(ResManager.DownloadUIType.EditModBtn, ResManager.DownloaderType.MyWork, ArchiveModInfo, self.UIRoot.CanvasPanel_Download_2, nil, self, {
    Source = config_ugc.EnumDownLoadSource.UgcMineEditNormalWorkPanel,
    UGCDownloadConfirmThreshold = 50,
    LinearColor = FLinearColor(0, 0, 0, 1),
    clickCallback = function(state)
      local DownloaderRoot = self.archive_downloader_ui and self.archive_downloader_ui.UIRoot
      if DownloaderRoot then
        DownloaderRoot:UpdateImageState(state)
        DownloaderRoot:CheckAddLoadTimer()
      end
    end,
    EndDownloadCallback = function()
      if self.archiveDownloadToken ~= DownloadToken or self.nSlot ~= MainSlot then
        self:CheckShowDownloader()
        return
      end
      self:StartLoadArchive(save_type, save_slot)
    end
  })
  if not self.archive_downloader_ui or not self.archive_downloader_ui.UIRoot then
    log_error(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:StartArchiveDownload create downloader failed")
    LogicUGCCRUD:ClearDownloadingSaveSlot(self.nSlot)
    self:CheckShowDownloader()
    return
  end
  if self.UIRoot.WidgetSwitcher_ResState then
    self.UIRoot.WidgetSwitcher_ResState:SetActiveWidgetIndex(1)
  end
  LogicUGCCRUD:SetDownloadingSaveSlot(self.nSlot, save_type, save_slot)
  if not bDownloading then
    self.archive_downloader_ui.UIRoot:OnClickDownloadButton()
  end
end

function UI_UGC_Mine_Edit_Normal_Work:CheckResAndTryDownload(save_type, save_slot)
  if not save_type then
    log_error(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:CheckResAndTryDownload save_type is nil")
    return true
  end
  local PufferConst = require("client.slua.logic.download.puffer_const")
  local ResManager = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager)
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  self:CancelArchiveDownloadIntent()
  local DownloadToken = self.archiveDownloadToken
  local ArchiveModInfo = LogicUGCCRUD:BuildArchiveResModInfo(self.nSlot, save_type, save_slot)
  if not ArchiveModInfo then
    log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:CheckResAndTryDownload save meta not ready, save_type = " .. tostring(save_type) .. " save_slot = " .. tostring(save_slot))
    self.nSelectSaveType = save_type
    self.nSelectSaveSlot = save_slot or 0
    LogicUGCCRUD:ReqGetEditShotFullMeta(self.nSlot, save_type, save_slot)
    ShowNotice(78459)
    return true
  end
  local State = ResManager:GetResState(ResManager.DownloaderType.MyWork, ArchiveModInfo, false)
  log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:CheckResAndTryDownload save_type = " .. tostring(save_type) .. " save_slot = " .. tostring(save_slot) .. " State = " .. tostring(State))
  if State == PufferConst.ENUM_DownloadState.Done then
    return false
  end
  local bDownloading = State == PufferConst.ENUM_DownloadState.Download or State == PufferConst.ENUM_DownloadState.Wait
  self:StartArchiveDownload(ArchiveModInfo, save_type, save_slot, DownloadToken, bDownloading)
  ShowNotice(4302053)
  return true
end

function UI_UGC_Mine_Edit_Normal_Work:OnGetSaveSlotFullMetaRsp(_, _, main_slot, save_type, save_slot)
  if main_slot ~= self.nSlot or save_type ~= self.nSelectSaveType or (save_slot or 0) ~= self.nSelectSaveSlot then
    return
  end
  log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnGetSaveSlotFullMetaRsp save_type = " .. tostring(save_type) .. " save_slot = " .. tostring(save_slot))
  if self:CheckResAndTryDownload(save_type, save_slot) then
    return
  end
  self:StartLoadArchive(save_type, save_slot)
end

function UI_UGC_Mine_Edit_Normal_Work:StartLoadArchive(save_type, save_slot)
  log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:StartLoadArchive nSlot = " .. tostring(self.nSlot) .. " save_type = " .. tostring(save_type) .. " save_slot = " .. tostring(save_slot))
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  LogicUGCCRUD:ClearDownloadingSaveSlot(self.nSlot)
  LogicUGCCRUD:ReqStartEditGame(self.nSlot, true, false, nil, false, save_type, save_slot)
end

function UI_UGC_Mine_Edit_Normal_Work:SingleEditFunc(isTrailPlay)
  self:CancelArchiveDownloadIntent(true)
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local TeamUpNewSystem = require("client.slua.logic.teamup.logic_team_up")
  if TeamUpNewSystem.IsInTeam() then
    LogicUGCCRUD:EnterTeamCreate(self.nSlot, self.modInfo.base.template_id)
  else
    LogicUGCCRUD:ReqStartEditGame(self.nSlot, true, isTrailPlay)
  end
end

function UI_UGC_Mine_Edit_Normal_Work:CreateTeamMod()
  self:CancelArchiveDownloadIntent(true)
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  LogicUGCCRUD:ReqStartEditGame(self.nSlot, false)
end

function UI_UGC_Mine_Edit_Normal_Work:OnJumpGuestPanel()
  self:CloseSelf()
end

function UI_UGC_Mine_Edit_Normal_Work:OnSendSquare(_, _, is_wow_moment)
  self.is_wow_moment = is_wow_moment
end

function UI_UGC_Mine_Edit_Normal_Work:OnSelectSeasonAct(_, _, m_selectAct_id)
  log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnSelectSeasonAct m_selectAct_id = " .. tostring(m_selectAct_id))
  local Logic_UGC_SeasonTemplate = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_season_template)
  local act_data = Logic_UGC_SeasonTemplate:GetActivityCfg(m_selectAct_id)
  if not act_data or not next(act_data) then
    log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnSelectSeasonAct act_data is nil")
    return
  end
  self.UIRoot.WidgetSwitcher_Event:SetActiveWidgetIndex(1)
  self.UIRoot.TextBlock_EventName:SetText(act_data.title)
  self.CurSelectSeasonActID = m_selectAct_id
end

function UI_UGC_Mine_Edit_Normal_Work:OnGetSeasonCfg()
  self:RefreshSeasonTagUI()
end

function UI_UGC_Mine_Edit_Normal_Work:OnWowPassInfoUpdate()
  self:InitTags(C_TagWidgetName)
end

function UI_UGC_Mine_Edit_Normal_Work:RefreshSeasonTagUI()
  local BUpdateMod = self:IsUpdateMod()
  log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:RefreshSeasonTagUI BUpdateMod = " .. tostring(BUpdateMod))
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Event, false)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Tips, false)
  local Logic_UGC_SeasonTemplate = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_season_template)
  local valid = self:GetCreationPeriodSeasonCfg(BUpdateMod)
  self.valid_act = valid
  local TableUtil = require("common.table_util")
  log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:RefreshSeasonTagUI TableUtil.CountTable(valid) = " .. TableUtil.CountTable(valid))
  local hasValidSeason = TableUtil.CountTable(valid) > 0
  if BUpdateMod then
    if self.CurSelectSeasonActID then
      local act_data = Logic_UGC_SeasonTemplate:GetActivityCfg(self.CurSelectSeasonActID)
      if not act_data or not next(act_data) then
        log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:RefreshSeasonTagUI act_data is nil self.CurSelectSeasonActID = " .. tostring(self.CurSelectSeasonActID))
        self:SetWidgetVisible(self.UIRoot.CanvasPanel_Event, false)
        if hasValidSeason then
          self.UIRoot.WidgetSwitcher_Event:SetActiveWidgetIndex(0)
          self:SetWidgetVisible(self.UIRoot.CanvasPanel_Event, true)
        end
      else
        self.UIRoot.WidgetSwitcher_Event:SetActiveWidgetIndex(1)
        self.UIRoot.TextBlock_EventName:SetText(act_data.title)
        self:SetWidgetVisible(self.UIRoot.CanvasPanel_Event, true)
      end
    elseif hasValidSeason then
      self.UIRoot.WidgetSwitcher_Event:SetActiveWidgetIndex(0)
      self:SetWidgetVisible(self.UIRoot.CanvasPanel_Event, true)
    else
      self:SetWidgetVisible(self.UIRoot.CanvasPanel_Event, false)
    end
  else
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_Event, hasValidSeason)
    if hasValidSeason then
      self.UIRoot.WidgetSwitcher_Event:SetActiveWidgetIndex(0)
    end
  end
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Tips, hasValidSeason)
  if hasValidSeason then
    local show_act = valid[self.show_actID]
    local bonus_amount = show_act and show_act.activity_info and show_act.activity_info.bonus_amount or 0
    local act_name = show_act and show_act.title or ""
    self.UIRoot.UTRichTextBlock_Tips:SetText(LocUtil.LocalizeResFormat(1050196, bonus_amount, act_name))
  end
end

function UI_UGC_Mine_Edit_Normal_Work:GetCreationPeriodSeasonCfg(BUpdateMod)
  local Logic_UGC_SeasonTemplate = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_season_template)
  local season_cfgs = Logic_UGC_SeasonTemplate:GetValidSeasonCfgData(BUpdateMod)
  local TimeUtil = require("client.common.time_util")
  local serverTime = TimeUtil.GetServerTimeInSec()
  self.show_actID = -1
  local valid = {}
  for i, act_cfg in pairs(season_cfgs) do
    local CreationPeriod
    local stepPeriod = act_cfg.activity_info and act_cfg.activity_info.time_line or {}
    for j, k in pairs(stepPeriod) do
      if k.type == config_ugc_season_template.C_EnumStep.CreationPeriod then
        CreationPeriod = k
        break
      end
    end
    local start_time = CreationPeriod and CreationPeriod.period[1]
    local end_time = CreationPeriod and CreationPeriod.period[2]
    local nActID = act_cfg.activity_info and act_cfg.activity_info.game_manage_id
    log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:GetCreationPeriodSeasonCfg start_time = " .. tostring(start_time) .. " end_time = " .. tostring(end_time) .. " serverTime = " .. serverTime .. " v.nActID = " .. tostring(nActID))
    if start_time and end_time and type(start_time) == "number" and type(end_time) == "number" and serverTime >= start_time and serverTime <= end_time then
      if self.show_actID == -1 then
        self.show_actID = nActID
      end
      valid[nActID] = act_cfg
    end
  end
  return valid
end

function UI_UGC_Mine_Edit_Normal_Work:UpdateAICoverUI()
  local logic_ugc_ai_cover_image = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_ai_cover_image)
  local bOpenAICoverImage = logic_ugc_ai_cover_image:CheckAICoverImageOpen()
  self:SetWidgetVisible(self.UIRoot.HorizontalBox_AICover, bOpenAICoverImage)
  local use_ai_photo = self.modInfo and self.modInfo.setting and self.modInfo.setting.use_ai_photo or 0
  local thumb_index = self.modInfo and self.modInfo.setting and self.modInfo.setting.thumb_index or -1
  local idx = 0
  if use_ai_photo == 1 and thumb_index ~= -1 then
    idx = 1
  end
  self.UIRoot.WidgetSwitcher_AIState:SetActiveWidgetIndex(idx)
end

function UI_UGC_Mine_Edit_Normal_Work:UpdateDuplicate()
  local bInvalidResRef = self.modInfo.setting.invalid_res_ref == true
  self:SetWidgetVisible(self.UIRoot.Button_Duplicate, not bInvalidResRef, true)
end

function UI_UGC_Mine_Edit_Normal_Work:JumpBack(uiData)
  log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:JumpBack")
  local Logic_UGC_SeasonTemplate = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_season_template)
  local bJump = Logic_UGC_SeasonTemplate:GetEventSelectPopupUIState()
  if bJump then
    UIManager.ShowUI(UIManager.UI_Config.UGC_SeasonTag_Popup_UIBP, self.modInfo, nil, self.show_actID)
    Logic_UGC_SeasonTemplate:SetEventSelectPopupUIState(false)
  end
end

function UI_UGC_Mine_Edit_Normal_Work:GetDataForJumpBack()
  return {
    ctorData = {
      [1] = self.nSlot,
      [2] = self.bIsFromRelate
    }
  }
end

function UI_UGC_Mine_Edit_Normal_Work:InitInvalidResRef(invalid_res_ref)
  self:SetWidgetVisible(self.UIRoot.HorizontalBox_Illegal, invalid_res_ref == true, false)
  if invalid_res_ref then
    self.UIRoot.TextBlock_Warn:SetText(LocUtil.GetLocalizeResStr(8880484))
    self:SetWidgetVisible(self.UIRoot.UTRichTextBlock_ReviewTime, false)
  end
end

function UI_UGC_Mine_Edit_Normal_Work:OnRefreshPubCD(_, _, cd)
  local reason = self.modInfo.base.state_reason
  if reason and 0 < reason then
    log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnRefreshPubCD has reason mod_id = " .. tostring(self.modInfo.base.mod_id))
    return
  end
  if cd == -1 then
    self:InitReason()
  else
    self.UIRoot.CanvasPanel_Reason:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    self:SetWidgetVisible(self.UIRoot.Button_ViewMore, false, true)
    local TimeUtil = require("client.common.time_util")
    local time = TimeUtil.FormatCountDownTime_D_or_HMS(cd)
    self.UIRoot.TextBlock_Reason:SetColorAndOpacity(FSlateColor(FLinearColor(0.58, 0, 0, 1)))
    self.UIRoot.TextBlock_Reason:SetText(LocUtil.GetLocalizeResStr(78431))
    self.UIRoot.Image_170:SetColorAndOpacity(FLinearColor(0.58, 0, 0, 1))
  end
end

function UI_UGC_Mine_Edit_Normal_Work:UpdatePubState()
  self.UIRoot.TextBlock_23:SetText(LocUtil.GetLocalizeResStr(10120049))
  self.UIRoot.TextBlock_25:SetText(LocUtil.GetLocalizeResStr(10120050))
  self.UIRoot.TextBlock_27:SetText(LocUtil.GetLocalizeResStr(10120051))
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local bPrivate = LogicUGCCRUD:CheckEditModIsPrivate(self.modInfo)
  self.UIRoot.WidgetSwitcher_Publish:SetActiveWidgetIndex(bPrivate and 0 or 1)
  self.UIRoot.WidgetSwitcher_Private:SetActiveWidgetIndex(bPrivate and 1 or 0)
  if bPrivate then
    self.UIRoot.WidgetSwitcher_SpecialEdition:SetActiveWidgetIndex(0)
  end
  self:SetWidgetVisible(self.UIRoot.Image_37, bPrivate, false)
  self:SetWidgetVisible(self.UIRoot.Image_SpcialEditionGray, bPrivate, true)
  self.releaseItemUI:UpdatePubState(bPrivate)
  local curPublishState = self.modInfo and self.modInfo.setting and self.modInfo.setting.publish_state
  if self._lastPublishState ~= nil and self._lastPublishState ~= curPublishState then
    self:RunWorkDiagnosis()
  end
  self._lastPublishState = curPublishState
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickPub()
  self:PlayAudio(sound_config.click_v1)
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local bPrivate = LogicUGCCRUD:CheckEditModIsPrivate(self.modInfo)
  if not bPrivate then
    return
  end
  local UIUtil = require("client.common.ui_util")
  if not self.BTabSwitch and not UIUtil.CanClickNow(UIUtil.ClickFrequencyLimit.UGCPublishStateChange1) then
    return
  end
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local modifyMeta = LogicUGCCRUD:NewModifyMeta()
  modifyMeta.publish_state = 1
  LogicUGCCRUD:ReqModifyModMeta(self.nSlot, modifyMeta)
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickPrivate()
  self:PlayAudio(sound_config.click_v1)
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local bPrivate = LogicUGCCRUD:CheckEditModIsPrivate(self.modInfo)
  if bPrivate then
    return
  end
  local UIUtil = require("client.common.ui_util")
  if not self.BTabSwitch and not UIUtil.CanClickNow(UIUtil.ClickFrequencyLimit.UGCPublishStateChange2) then
    return
  end
  log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnClickPrivate self.CurSelectAlbumThemeID = " .. tostring(self.CurSelectAlbumThemeID) .. ", self.CurSelectSeasonActID = " .. tostring(self.CurSelectSeasonActID))
  if self.CurSelectAlbumThemeID or self.CurSelectSeasonActID then
    self.CurSelectAlbumThemeID = nil
    local logic_ugc_album_theme = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_album_theme)
    logic_ugc_album_theme:ResetSelectAlbumThemeID()
    ShowNotice(814218)
  end
  local modifyMeta = LogicUGCCRUD:NewModifyMeta()
  modifyMeta.publish_state = 2
  LogicUGCCRUD:ReqModifyModMeta(self.nSlot, modifyMeta)
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickPrivateRule()
  self:PlayAudio(sound_config.click_v1)
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_FIVE, LocUtil.GetLocalizeResStr(10120047), LocUtil.GetLocalizeResStr(10120048), nil, nil, nil, nil, {
    showUIKey = "Com_MsgBox_Middle_Slua_UIBP"
  })
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickDownload(_, _, itemData, source)
  if not itemData then
    return
  end
  local config_ugc = require("client.slua.logic.ugc.config_ugc")
  if not source or source ~= config_ugc.EnumDownLoadSource.UgcMineEditNormalWorkPanel then
    return
  end
  if itemData.base and itemData.base.save_type then
    return
  end
  local download_slot = itemData.base.slot
  if not download_slot or tonumber(download_slot) ~= tonumber(self.modInfo.base.slot) then
    log(bWriteLog and "UGC_Mine_Edit_Work_Item:OnClickDownload: download_slot = " .. download_slot .. ", self.modInfo.base.slot = " .. self.modInfo.base.slot)
    return
  end
  local LogicUGCTemplate = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCTemplate)
  local PufferConst = require("client.slua.logic.download.puffer_const")
  local LogicUGCResManager = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager)
  local state = LogicUGCResManager:GetResState(LogicUGCResManager.DownloaderType.MyWork, self.modInfo)
  if state ~= PufferConst.ENUM_DownloadState.Done then
    self:CancelArchiveDownloadIntent(true)
  end
  if state == PufferConst.ENUM_DownloadState.Download then
    LogicUGCTemplate:OnAddDownloadSlot(_, _, self.modInfo.base.slot)
  elseif state == PufferConst.ENUM_DownloadState.Not or state == PufferConst.ENUM_DownloadState.Pause then
    LogicUGCTemplate:RemoveDownloadSlot(self.modInfo.base.slot)
  end
  EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_NOTIFY_EDITITEM_DOWNLOAD_STATE_CHANGE)
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickOriginModReport()
  self:PlayAudio(sound_config.click_v1)
  UIManager.ShowUI(UIManager.UI_Config.UgcLobbyOriginModReport, self.modInfo)
end

function UI_UGC_Mine_Edit_Normal_Work:InitOriginModInfo()
  self.UIRoot.TextBlock_From:SetText(LocUtil.LocalizeResFormat(74033, ""))
  self.UIRoot.TextBlock_Report:SetText(LocUtil.GetLocalizeResStr(638))
end

function UI_UGC_Mine_Edit_Normal_Work:UpdateOriginModInfo()
  self.UIRoot.CanvasPanel_Mod:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  if self.modInfo and self.modInfo.base and self.modInfo.base.first_mod_id and IsWoWEditor then
    self:RequestOriginModInfo(self.modInfo.base.first_mod_id)
  end
end

function UI_UGC_Mine_Edit_Normal_Work:RequestOriginModInfo(modId)
  if not modId or modId <= 0 then
    return
  end
  self.originModId = modId
  local LogicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
  LogicUGC:BatchGetModInfo({modId}, LogicUGC.C_ModListTypes.Pub, nil, {Param = modId})
end

function UI_UGC_Mine_Edit_Normal_Work:UpdateOriginModUI()
  if not self.originModInfo then
    return
  end
  local UGCMacros = require("client.slua.logic.ugc.ugc_macros")
  if IsWoWEditor then
    self.UIRoot.CanvasPanel_Mod:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    local baseInfo = self.originModInfo.pub_mod_meta or {}
    self.UIRoot.TextBlock_ModName:SetText(baseInfo.setting.name)
    self.UIRoot.TextBlock_ModAuthor:SetText(baseInfo.setting.desc)
    local Util_UGC = require("client.slua.logic.ugc.util_ugc")
    Util_UGC.SetCoverImage(self, self.UIRoot.Image_Mod, baseInfo, false, true, nil, nil)
  else
    self.UIRoot.CanvasPanel_Mod:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
end

function UI_UGC_Mine_Edit_Normal_Work:RefreshArchiveRedDot()
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local bCrashSaved = LogicUGCCRUD:HasCrashSaved(self.nSlot)
  log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:RefreshArchiveRedDot nSlot = " .. tostring(self.nSlot) .. " bCrashSaved = " .. tostring(bCrashSaved))
  self:SetWidgetVisible(self.UIRoot.Image_ArchiveRedPooint, bCrashSaved)
end

function UI_UGC_Mine_Edit_Normal_Work:OnAlbumDataAndSelectAlbumID()
  log(bWriteLog and "UI_UGC_Mine_Edit_Normal_Work:OnAlbumDataAndSelectAlbumID")
  local logic_ugc_album_theme = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_album_theme)
  local AlbumThemeData = logic_ugc_album_theme:GetAlbumThemeDataByTemplateID(self.template_id)
  if not AlbumThemeData or not next(AlbumThemeData) then
    return
  end
  logic_ugc_album_theme:SetSelectAlbumThemeID(AlbumThemeData.id)
end

function UI_UGC_Mine_Edit_Normal_Work:CheckPlayerAlbumIsBan(uid, Album_theme_id)
  local LogicUGCAuthor = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor)
  local logic_ugc_album_theme = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_album_theme)
  if LogicUGCAuthor:CheckPlayerAlbumIsBan(uid, Album_theme_id) then
    logic_ugc_album_theme:SetAlbumThemeTemporarilySelectID()
    return true
  end
  return false
end

function UI_UGC_Mine_Edit_Normal_Work:RefreshPubBtnInfo()
  if self.curEditTab == E_EditTab.Tab1 then
    self.UIRoot.TextBlock_Public:SetText(LocUtil.GetLocalizeResStr(8801623))
    self.UIRoot.UTRichTextBlock_ReviewTime:SetText(LocUtil.LocalizeResFormat(18962, LocUtil.GetLocalizeResStr(11993), LocUtil.GetLocalizeResStr(9413)))
  elseif self.curEditTab == E_EditTab.Tab2 then
    self.UIRoot.TextBlock_Public:SetText(LocUtil.GetLocalizeResStr(8801623))
    self.UIRoot.UTRichTextBlock_ReviewTime:SetText(LocUtil.LocalizeResFormat(18962, LocUtil.GetLocalizeResStr(11993), LocUtil.GetLocalizeResStr(65156)))
  elseif self.curEditTab == E_EditTab.Tab3 then
    self.UIRoot.TextBlock_Public:SetText(LocUtil.GetLocalizeResStr(65156))
  end
end

function UI_UGC_Mine_Edit_Normal_Work:OnClickGotoPublish()
  self:PlayAudio(sound_config.click_v1)
  self:SwitchEditTab(self.curEditTab + 1)
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
local CUI_UGC_Mine_Edit_Normal_Work = class(ui_base, nil, UI_UGC_Mine_Edit_Normal_Work)
return CUI_UGC_Mine_Edit_Normal_Work
