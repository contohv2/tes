-- 设置已启用自动解析化
-- TELEGRAM:@RJTOOL @BYRJ6
-- 解包层数: 0；移除诱饵行: 0；还原字符串: 0

local UGC_Center_Release_Item_UIBP = {}

function UGC_Center_Release_Item_UIBP:ctor()
  self.headItemList = {}
  self.advancedDiagnosticsUI = nil
end

function UGC_Center_Release_Item_UIBP:OnInitialize()
  UGC_Center_Release_Item_UIBP.__super.OnInitialize(self)
  self:InitText()
end

function UGC_Center_Release_Item_UIBP:RegistEvents()
  UGC_Center_Release_Item_UIBP.__super.RegistEvents(self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Update, self.OnClickPublish, self, false)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Release, self.OnClickPublish, self, true)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Help_3, self.OnClickHelp, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Help_1, self.OnClickPrivateRule, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Public, self.OnClickPub, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Private, self.OnClickPrivate, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Diagnosis, self.OnClickDiagnosis, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_LLM_DIAG_RSP, self.OnLlmDiagRsp, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_LLM_DIAG_STAT_RSP, self.OnLlmDiagRsp, self)
end

function UGC_Center_Release_Item_UIBP:OnPostInitialize()
  UGC_Center_Release_Item_UIBP.__super.OnPostInitialize(self)
  self:RefreshDiagCount()
  self:RefreshDiagnosisButtonVisibility()
  local LogicUGCLLMDiag = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_llm_diag)
  LogicUGCLLMDiag:RequestDiagStatIfNeeded()
  self:InitReason()
end

function UGC_Center_Release_Item_UIBP:OnClose()
  self:ClearHeadList()
  UGC_Center_Release_Item_UIBP.__super.OnClose(self)
end

function UGC_Center_Release_Item_UIBP:OnClickPublish(bForceNewRelease)
  self:PlayAudio(sound_config.click_v1)
  local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
  if bForceNewRelease then
    UGCTLogReport:ReportDelay(TLogEventDefine.UGC_Click_ReleaseItem_NewRelease_Button)
  else
    UGCTLogReport:ReportDelay(TLogEventDefine.UGC_Click_ReleaseItem_Update_Button)
  end
  local parentUI = self:GetParentUI()
  if not parentUI then
    log_error("[UGC_Center_Release_Item_UIBP] OnClickPublish parentUI is nil")
    return
  end
  parentUI:OnClickPublish(bForceNewRelease)
end

function UGC_Center_Release_Item_UIBP:OnClickHelp()
  self:PlayAudio(sound_config.click_v1)
  local FirstTrialTimeCfg = CDataTable.GetTableData("UGCParamConfig", "FirstTrialTime")
  local FirstTrialTime = FirstTrialTimeCfg and FirstTrialTimeCfg.Value
  local ReviewTimeCfg = CDataTable.GetTableData("UGCParamConfig", "ReviewTime")
  local ReviewTime = ReviewTimeCfg and ReviewTimeCfg.Value
  local title = LocUtil.GetLocalizeResStr(49496)
  local content = LocUtil.LocalizeFormatConcatenation(512220, FirstTrialTime, ReviewTime)
  UIManager.ShowUI(UIManager.UI_Config.HelpTip, 0, title, content)
end

function UGC_Center_Release_Item_UIBP:OnClickPrivateRule()
  self:PlayAudio(sound_config.click_v1)
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_FIVE, LocUtil.GetLocalizeResStr(10120047), LocUtil.GetLocalizeResStr(10120048), nil, nil, nil, nil, {
    showUIKey = "Com_MsgBox_Middle_Slua_UIBP"
  })
end

function UGC_Center_Release_Item_UIBP:OnClickPub()
  local parentUI = self:GetParentUI()
  if parentUI then
    parentUI:OnClickPub()
  end
end

function UGC_Center_Release_Item_UIBP:OnClickPrivate()
  local parentUI = self:GetParentUI()
  if parentUI then
    parentUI:OnClickPrivate()
  end
end

function UGC_Center_Release_Item_UIBP:HandleDiagnosisJumpToTab(tabIndex, subTargetID)
  local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
  UGCTLogReport:ReportDelay(TLogEventDefine.UGC_Click_ReleaseItem_Enhance_Button)
  local parentUI = self:GetParentUI()
  if parentUI and parentUI.SwitchEditTab then
    parentUI:SwitchEditTab(tabIndex, subTargetID)
  end
end

function UGC_Center_Release_Item_UIBP:HandleDiagnosisJumpToEditor()
  local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
  UGCTLogReport:ReportDelay(TLogEventDefine.UGC_Click_ReleaseItem_Enhance_Button)
  local parentUI = self:GetParentUI()
  if not parentUI or not parentUI.OnClickEdit then
    return
  end
  local workName = parentUI.modInfo and parentUI.modInfo.setting and parentUI.modInfo.setting.name or ""
  local title = LocUtil.GetLocalizeResStr(101001)
  local content = LocUtil.LocalizeResFormat(10120145, workName)
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_TWO, title, content, function()
    local PufferConst = require("client.slua.logic.download.puffer_const")
    local ResManager = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager)
    local resState = ResManager:GetResState(ResManager.DownloaderType.MyWork, parentUI.modInfo)
    if resState == PufferConst.ENUM_DownloadState.Done then
      parentUI:OnClickEdit()
    elseif resState == PufferConst.ENUM_DownloadState.Download then
      ShowNotice(4302053)
    elseif parentUI.downloader_ui and parentUI.downloader_ui.UIRoot.OnClickDownloadButton then
      parentUI.downloader_ui.UIRoot:OnClickDownloadButton()
    end
  end, nil, nil, nil, nil)
end

function UGC_Center_Release_Item_UIBP:OnClickDiagnosis()
  self:PlayAudio(sound_config.click_v1)
  local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
  UGCTLogReport:ReportDelay(TLogEventDefine.UGC_Click_ReleaseItem_Diagnosis_Button)
  local bRequiredFieldsOk = self:CheckRequiredFields()
  if not bRequiredFieldsOk then
    ShowNotice(4600188)
    return
  end
  local UIUtil = require("client.common.ui_util")
  if not UIUtil.CanClickNow(UIUtil.ClickFrequencyLimit.UGCLLMDiag) then
    return
  end
  local parentUI = self:GetParentUI()
  if not parentUI or not parentUI.nSlot then
    return
  end
  local LogicUGCLLMDiag = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_llm_diag)
  local _, dailyLimit = LogicUGCLLMDiag:GetDailyRemaining()
  local title = LocUtil.GetLocalizeResStr(101001)
  local content = LocUtil.LocalizeFormatConcatenation(4600262, tostring(dailyLimit))
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_TWO, title, content, function()
    if not slua.isValid(self.UIRoot) then
      return
    end
    LogicUGCLLMDiag:RequestDiag(parentUI.nSlot)
    if self.advancedDiagnosticsUI then
      self.advancedDiagnosticsUI:RefreshDiagState(LogicUGCLLMDiag.DiagState.Loading, nil)
    end
    self.UIRoot.ScrollBox_Release:ScrollToEnd()
  end, nil, nil, nil, nil)
end

function UGC_Center_Release_Item_UIBP:OnLlmDiagRsp()
  self:RefreshDiagCount()
end

function UGC_Center_Release_Item_UIBP:InitText()
  self.UIRoot.TextBlock_Release:SetText(LocUtil.GetLocalizeResStr(4600196))
  self.UIRoot.TextBlock_ReleaseStatua:SetText(LocUtil.GetLocalizeResStr(4600180))
  self.UIRoot.TextBlock_Public_01:SetText(LocUtil.GetLocalizeResStr(4600012))
  self.UIRoot.TextBlock_Public_02:SetText(LocUtil.GetLocalizeResStr(4600012))
  self.UIRoot.TextBlock_Private_01:SetText(LocUtil.GetLocalizeResStr(4600011))
  self.UIRoot.TextBlock_Private_02:SetText(LocUtil.GetLocalizeResStr(4600011))
end

function UGC_Center_Release_Item_UIBP:SetUpdateButtonText(bIsUpdate)
  self.UIRoot.TextBlock_Update:SetText(LocUtil.GetLocalizeResStr(bIsUpdate and 70025 or 70024))
  self.UIRoot.Button_Release:SetWidgetVisibility(bIsUpdate and UEnums.ESlateVisibility.Visible or UEnums.ESlateVisibility.Collapsed)
end

function UGC_Center_Release_Item_UIBP:SetUpdateButtonGrayState(bEnable)
  self.UIRoot.Button_Update:SetColorAndOpacity(FLinearColor(1, 1, 1, bEnable and 1 or 0.5))
  self.UIRoot.Button_Release:SetColorAndOpacity(FLinearColor(1, 1, 1, bEnable and 1 or 0.5))
end

function UGC_Center_Release_Item_UIBP:UpdatePubState(bPrivate)
  self.UIRoot.WidgetSwitcher_Public:SetActiveWidgetIndex(bPrivate and 1 or 0)
  self.UIRoot.WidgetSwitcher_Private:SetActiveWidgetIndex(bPrivate and 0 or 1)
end

function UGC_Center_Release_Item_UIBP:ClearHeadList()
  for _, item in ipairs(self.headItemList) do
    item:Close()
  end
  self.headItemList = {}
  if self.advancedDiagnosticsUI then
    self.advancedDiagnosticsUI:Close()
    self.advancedDiagnosticsUI = nil
  end
  self.UIRoot.VerticalBox_Content:ClearChildren()
end

function UGC_Center_Release_Item_UIBP:CreateAdvancedDiagnosticsUI()
  self.advancedDiagnosticsUI = self:CreateChildWindow(self.UIRoot.VerticalBox_Content, UIManager.UI_Config.UGC_AdvancedDiagnostics_Item_UIBP)
  local parentUI = self:GetParentUI()
  local slot = parentUI and parentUI.nSlot or 0
  self.advancedDiagnosticsUI:SetSlot(slot)
end

function UGC_Center_Release_Item_UIBP:RefreshDiagCount()
  local LogicUGCLLMDiag = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_llm_diag)
  local remaining, dailyLimit = LogicUGCLLMDiag:GetDailyRemaining()
  if remaining == nil then
    remaining = dailyLimit
  end
  local text = LocUtil.LocalizeResFormat(4600178, tostring(remaining), tostring(dailyLimit))
  local parentUI = self:GetParentUI()
  if parentUI and parentUI.nSlot then
    local _, diagState = LogicUGCLLMDiag:GetCache(parentUI.nSlot)
    if diagState == LogicUGCLLMDiag.DiagState.Cached then
      text = LocUtil.LocalizeResFormat(4600193, tostring(remaining), tostring(dailyLimit))
    end
  end
  self.UIRoot.UTRichTextBlock_Diagnosis_Vel_1:SetText(text)
  local bRequiredFieldsOk = self:CheckRequiredFields()
  local switcherIndex = not (remaining ~= 0 and bRequiredFieldsOk) and 1 or 0
  self.UIRoot.WidgetSwitcher_Diagnosis:SetActiveWidgetIndex(switcherIndex)
end

function UGC_Center_Release_Item_UIBP:CheckRequiredFields()
  local parentUI = self:GetParentUI()
  if not parentUI then
    return nil
  end
  local name = parentUI.LocName or ""
  local desc = parentUI.LocDesc or ""
  local tagList = parentUI.LocTag_v2
  local viewPicList = parentUI.modInfo and parentUI.modInfo.setting and parentUI.modInfo.setting.view_pic_list
  local bNameOk = name ~= ""
  local bDescOk = desc ~= "" and string.sub(desc, 1, 1) ~= " "
  local bTagOk = tagList and 0 < #tagList
  local bCoverOk = viewPicList and 0 < #viewPicList
  return bNameOk and bDescOk and bTagOk and bCoverOk
end

function UGC_Center_Release_Item_UIBP:RefreshPromotionReminderList(diagnosisResult)
  self:ClearHeadList()
  if not diagnosisResult or not diagnosisResult.triggeredItems then
    return
  end
  local parentUI = self:GetParentUI()
  local priorityGroups = {}
  for _, item in ipairs(diagnosisResult.triggeredItems) do
    local priority = item.Priority or 2
    if not priorityGroups[priority] then
      priorityGroups[priority] = {}
    end
    table.insert(priorityGroups[priority], item)
  end
  local p0Count = priorityGroups[0] and #priorityGroups[0] or 0
  local p1Count = priorityGroups[1] and #priorityGroups[1] or 0
  local p2Count = priorityGroups[2] and #priorityGroups[2] or 0
  self:RefreshScore(diagnosisResult.score or 0)
  self:RefreshComment(p0Count, p1Count, p2Count)
  local headGroups = {
    {
      priorities = {0, 1},
      titleLocID = 4600194,
      bgColorIndex = 1
    },
    {
      priorities = {2},
      titleLocID = 4600195,
      bgColorIndex = 0
    }
  }
  for _, group in ipairs(headGroups) do
    local groupItems = {}
    for _, priority in ipairs(group.priorities) do
      local items = priorityGroups[priority]
      if items then
        for _, item in ipairs(items) do
          table.insert(groupItems, item)
        end
      end
    end
    table.sort(groupItems, function(a, b)
      local priorityA = a.Priority or 2
      local priorityB = b.Priority or 2
      if priorityA ~= priorityB then
        return priorityA < priorityB
      end
      return (a.ID or 0) < (b.ID or 0)
    end)
    if 0 < #groupItems then
      local headItem = self:CreateChildWindow(self.UIRoot.VerticalBox_Content, UIManager.UI_Config.UGC_PromotionReminder_Item_Head_UIBP)
      headItem.createTime = parentUI.modInfo and parentUI.modInfo.base and parentUI.modInfo.base.create_time
      headItem.UIRoot.TextBlock_Title:SetText(LocUtil.LocalizeResFormat(group.titleLocID, #groupItems))
      headItem.UIRoot.Image_BG:SetActiveColorIndex(group.bgColorIndex)
      headItem:RefreshList(groupItems)
      table.insert(self.headItemList, headItem)
    end
  end
  self:CreateAdvancedDiagnosticsUI()
end

function UGC_Center_Release_Item_UIBP:RefreshScore(score)
  self.UIRoot.TextBlock_Value:SetText(tostring(score))
  local ratingIndex, animName
  if score <= 30 then
    ratingIndex = 3
    animName = "Anim_Red"
  elseif score <= 60 then
    ratingIndex = 2
    animName = "Anim_Orange"
  elseif score <= 80 then
    ratingIndex = 1
    animName = "Anim_Yellow"
  else
    ratingIndex = 0
    animName = "Anim_Green"
  end
  self.UIRoot.TextBlock_Value:SetActiveColorIndex(ratingIndex)
  local PROGRESS_ANIM_DURATION = 2
  local percent = score / 100
  if self.UIRoot[animName] then
    self.UIRoot:PlayAnimationTo(self.UIRoot[animName], 0, percent * PROGRESS_ANIM_DURATION, 1, 0, 1)
  end
end

function UGC_Center_Release_Item_UIBP:RefreshComment(p0Count, p1Count, p2Count)
  local titleLocID, descLocID, descParam
  if 0 < p0Count then
    titleLocID = 4600170
    descLocID = 4600171
    descParam = p0Count
  elseif 0 < p1Count then
    titleLocID = 4600172
    descLocID = 4600173
    descParam = p1Count
  elseif 0 < p2Count then
    titleLocID = 4600174
    descLocID = 4600175
    descParam = p2Count
  else
    titleLocID = 4600176
    descLocID = 4600177
  end
  self.UIRoot.UTRichTextBlock_Comment:SetText(LocUtil.GetLocalizeResStr(titleLocID))
  self.UIRoot.TextBlock_Comment_01:SetText(LocUtil.LocalizeResFormat(descLocID, descParam))
end

function UGC_Center_Release_Item_UIBP:RefreshDiagnosisButtonVisibility()
  local LogicUGCLLMDiag = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_llm_diag)
  local authorLevelThreshold = LogicUGCLLMDiag:GetAuthorLevelThreshold()
  local LogicUGCAuthor = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor)
  local curAuthorLevel = LogicUGCAuthor:GetMineAuthorLevel()
  local bLevelOk = authorLevelThreshold <= curAuthorLevel
  local bSwitchOpen = LobbySystem.CheckOpen(92135)
  local bVisible = bLevelOk and bSwitchOpen
  self.UIRoot.Button_Diagnosis:SetWidgetVisibility(bVisible and UEnums.ESlateVisibility.Visible or UEnums.ESlateVisibility.Collapsed)
end

function UGC_Center_Release_Item_UIBP:InitReason()
  local parentUI = self:GetParentUI()
  if not parentUI then
    return nil
  end
  local reason = parentUI.modInfo.base.state_reason
  if reason and 0 < reason then
    self:SetWidgetVisible(self.UIRoot.UTRichTextBlock_ReviewTime, false)
    return
  end
  if self:IsModQuickCensor() then
    self.UIRoot.UTRichTextBlock_ReviewTime:SetText(LocUtil.GetLocalizeResStr(792483))
  else
    self.UIRoot.UTRichTextBlock_ReviewTime:SetText(LocUtil.GetLocalizeResStr(48622))
  end
  self:SetWidgetVisible(self.UIRoot.UTRichTextBlock_ReviewTime, true)
end

function UGC_Center_Release_Item_UIBP:IsModQuickCensor()
  local parentUI = self:GetParentUI()
  if not parentUI then
    return false
  end
  if parentUI.modInfo and parentUI.modInfo.base and parentUI.modInfo.base.quick_audit then
    return true
  end
  return false
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
local CUGC_Center_Release_Item_UIBP = class(ui_base, nil, UGC_Center_Release_Item_UIBP)
return CUGC_Center_Release_Item_UIBP
